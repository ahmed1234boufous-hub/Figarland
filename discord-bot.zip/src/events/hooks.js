'use strict';

/** Thin bridge: forward gateway events to module hooks via the registry. */

function bridge(name, ...argNames) {
  return {
    name,
    async execute(ctx, ...args) {
      await ctx.registry.invokeHook(name, ctx, ...args);
    },
    _args: argNames,
  };
}

module.exports = [
  bridge('guildMemberAdd'),
  bridge('guildMemberRemove'),
  bridge('messageCreate'),
  bridge('messageDelete'),
  bridge('messageUpdate'),
  bridge('messageReactionAdd'),
  bridge('messageReactionRemove'),
  bridge('voiceStateUpdate'),
  bridge('guildBanAdd'),
  bridge('channelDelete'),
  bridge('roleDelete'),
  bridge('webhookCreate'),
  bridge('guildMemberUpdate'),
  bridge('guildCreate'),
];
