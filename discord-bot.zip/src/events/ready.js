'use strict';

const { REST, Routes, PermissionFlagsBits } = require('discord.js');
const db = require('../core/db');
const settings = require('../core/settings');
const logger = require('../core/logger');
const config = require('../config');

/**
 * ready.js — post-login bootstrap:
 *  0. register global slash commands (no `npm run deploy` needed)
 *  1. register per-guild dashboard commands (instant, per-guild scope)
 *  2. start background scheduler jobs
 *  3. preserve per-guild custom commands across guild command overwrites
 */
module.exports = {
  name: 'clientReady',
  once: true,
  async execute(ctx) {
    ctx.logger.info(`Logged in as ${ctx.client.user.tag} — serving ${ctx.client.guilds.cache.size} guild(s)`);

    // 0. Global command registration on every boot. Idempotent bulk PUT —
    //    safe to repeat; keeps browser-only deploys (Railway + GitHub web
    //    upload) fully self-configuring. Set AUTO_REGISTER_COMMANDS=false
    //    to manage registration manually via `npm run deploy`.
    if ((process.env.AUTO_REGISTER_COMMANDS ?? 'true') !== 'false') {
      try {
        const { buildGlobalPayloads } = require('../core/commandPayload');
        const payloads = buildGlobalPayloads(ctx.registry);
        const rest = new REST({ version: '10' }).setToken(config.token);
        await rest.put(Routes.applicationCommands(ctx.client.application.id), { body: payloads });
        ctx.logger.info(`Registered ${payloads.length} global slash command(s) — they may take up to a minute to appear everywhere.`);
      } catch (err) {
        logger.warn(`Global command registration failed (bot still running): ${err?.message || err}`);
      }
    } else {
      ctx.logger.info('AUTO_REGISTER_COMMANDS=false — skipping global command registration.');
    }

    // Build the dashboard command payloads once.
    const dashDefs = ctx.registry
      .getModules()
      .filter((m) => m.dashboardCommandName)
      .map((m) => ({
        name: m.dashboardCommandName,
        description: `Open the ${m.name} dashboard`.slice(0, 100),
        defaultMemberPermissions: PermissionFlagsBits.Administrator.toString(),
        dmPermission: false,
      }));

    for (const guild of ctx.client.guilds.cache.values()) {
      try {
        // eslint-disable-next-line no-await-in-loop
        const existing = await guild.commands.fetch();
        // Keep custom commands created via /custom create (they are guild commands too).
        const customs = await db.customCommand.findMany({ where: { guildId: guild.id, enabled: true } });
        const customDefs = existing
          .filter((c) => customs.some((k) => k.name === c.name))
          .map((c) => ({ name: c.name, description: c.description || 'Custom server command', dmPermission: false }));

        const expected = [...dashDefs, ...customDefs];
        const sameSet =
          existing.size === expected.length &&
          expected.every((d) => existing.some((e) => e.name === d.name));

        if (!sameSet) {
          // eslint-disable-next-line no-await-in-loop
          await guild.commands.set(expected);
          ctx.logger.info(`Registered ${expected.length} guild command(s) in ${guild.name}`);
        }
      } catch (err) {
        logger.warn(`Could not register guild commands in ${guild.name}: ${err?.message || err}`);
      }
    }

    ctx.inviteCache = new Map(); // guildId → Map(inviteCode → uses)
    for (const guild of ctx.client.guilds.cache.values()) {
      try {
        // eslint-disable-next-line no-await-in-loop
        const invites = await guild.invites.fetch();
        ctx.inviteCache.set(guild.id, new Map(invites.map((i) => [i.code, i.uses || 0])));
      } catch {
        /* missing permissions — invite tracking unavailable in this guild */
      }
    }

    ctx.scheduler.start(ctx);
  },
};
