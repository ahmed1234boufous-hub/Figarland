'use strict';

const { MessageFlags } = require('discord.js');
const settings = require('../core/settings');
const permissions = require('../core/permissions');
const cooldown = require('../core/cooldown');
const responses = require('../core/responses');
const dashboards = require('../core/dashboards');
const globalDashboard = require('../core/globalDashboard');
const db = require('../core/db');
const logger = require('../core/logger');

/**
 * interactionCreate.js — single entry point for all interactions:
 *  • slash commands        → module commands, module dashboards, /dashboard, custom commands
 *  • buttons / select menus→ dash:* router or module componentHandlers
 *  • modals                → dashm:* router or module modalHandlers
 */

async function handleCommand(ctx, interaction) {
  const name = interaction.commandName;

  // Global dashboard index
  if (name === 'dashboard') return globalDashboard.execute(ctx, interaction);

  // Module dashboard commands (registered per guild)
  if (name.endsWith('-dashboard')) {
    const mod = ctx.registry.getModules().find((m) => m.dashboardCommandName === name);
    if (!mod) return;
    return dashboards.open(interaction, ctx, mod.key);
  }

  // Module commands
  const cmdDef = ctx.registry.getCommandByName(name);
  if (cmdDef) {
    const modCfg = await settings.getModuleConfig(interaction.guildId, cmdDef.moduleKey);
    if (!modCfg.enabled) {
      return responses.replyError(interaction, 'This module is currently disabled. An administrator can enable it in the module dashboard.');
    }
    const cmdCfg = await settings.getCommandConfig(interaction.guildId, cmdDef.moduleKey, name);
    const access = permissions.checkCommandAccess(interaction, cmdDef, cmdCfg);
    if (!access.ok) return responses.replyError(interaction, access.reason);

    const cd = cooldown.check(`${interaction.guildId}:${interaction.user.id}:${name}`, cmdCfg.cooldown);
    if (!cd.ok) return responses.replyError(interaction, `⏳ Slow down — try again in **${cd.remaining}s**.`);

    try {
      return await cmdDef.run(ctx, interaction, cmdCfg);
    } catch (err) {
      logger.error(`[cmd:${name}]`, err?.stack || err);
      return responses.replyError(interaction, 'Something went wrong while running this command. The error has been logged.');
    }
  }

  // Per-guild custom commands (/custom create)
  const custom = await db.customCommand.findUnique({ where: { guildId_name: { guildId: interaction.guildId, name } } });
  if (custom && custom.enabled) {
    const cc = {
      enabled: custom.enabled,
      cooldown: custom.cooldown,
      allowedRoles: JSON.parse(custom.allowedRoleIdsJson || '[]'),
      blockedRoles: [],
      allowedChannels: [],
      blockedChannels: [],
      requirePerms: [],
      responses: { success: { text: '', ephemeral: false, embed: null }, error: { text: '', ephemeral: true, embed: null }, info: { text: '', ephemeral: true, embed: null } },
      settings: {},
    };
    const access = permissions.checkCommandAccess(interaction, { name, requiredPerms: [] }, cc);
    if (!access.ok) return responses.replyError(interaction, access.reason);
    const cd = cooldown.check(`${interaction.guildId}:${interaction.user.id}:custom:${name}`, custom.cooldown);
    if (!cd.ok) return responses.replyError(interaction, `⏳ Slow down — try again in **${cd.remaining}s**.`);
    try {
      const customCmdModule = ctx.registry.getModule('customcommands');
      if (customCmdModule?.executeCustom) return await customCmdModule.executeCustom(ctx, interaction, custom);
    } catch (err) {
      logger.error('[custom-cmd]', err?.stack || err);
      return responses.replyError(interaction, 'Something went wrong while running this custom command.');
    }
  }
}

async function handleComponent(ctx, interaction) {
  if (interaction.customId.startsWith('dash:')) return dashboards.routeComponent(interaction, ctx);
  const handler = ctx.registry.findComponentHandler(interaction.customId);
  if (handler) {
    try {
      return await handler.handler(ctx, interaction, interaction.customId.slice(handler.prefix.length));
    } catch (err) {
      logger.error(`[component:${handler.prefix}]`, err?.stack || err);
      return responses.replyError(interaction, 'That interaction failed. The error has been logged.');
    }
  }
}

async function handleModal(ctx, interaction) {
  if (interaction.customId.startsWith('dashm:')) return dashboards.handleModal(interaction, ctx);
  const handler = ctx.registry.findModalHandler(interaction.customId);
  if (handler) {
    try {
      return await handler.handler(ctx, interaction, interaction.customId.slice(handler.prefix.length));
    } catch (err) {
      logger.error(`[modal:${handler.prefix}]`, err?.stack || err);
      return responses.replyError(interaction, 'That form could not be processed. The error has been logged.');
    }
  }
}

module.exports = {
  name: 'interactionCreate',
  async execute(ctx, interaction) {
    try {
      if (interaction.isChatInputCommand()) return await handleCommand(ctx, interaction);
      if (interaction.isModalSubmit()) return await handleModal(ctx, interaction);
      if (interaction.isButton() || interaction.isAnySelectMenu()) return await handleComponent(ctx, interaction);
    } catch (err) {
      logger.error('[interaction]', err?.stack || err);
      try {
        if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
          await interaction.reply({ content: 'Something went wrong.', flags: MessageFlags.Ephemeral });
        }
      } catch {
        /* ignore */
      }
    }
  },
};
