'use strict';

/**
 * modules.js — shared module loader used by both the bot runtime (index.js)
 * and the command deployment script. Keeps registration in one place.
 */

const registry = require('./core/registry');

const MODULE_PATHS = [
  './modules/moderation',
  './modules/welcome',
  './modules/security',
  './modules/automod',
  './modules/tickets',
  './modules/leveling',
  './modules/giveaways',
  './modules/roles',
  './modules/logging',
  './modules/economy',
  './modules/suggestions',
  './modules/utility',
  './modules/customcommands',
  './modules/community',
];

function loadAll() {
  for (const p of MODULE_PATHS) registry.registerModule(require(p));
  return registry;
}

module.exports = { loadAll };
