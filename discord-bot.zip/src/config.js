'use strict';
require('dotenv').config();
const path = require('path');

/**
 * Resolve relative SQLite `file:` URLs against prisma/schema.prisma so that
 * the runtime and the Prisma CLI (`prisma db push`) always land on the same
 * database file, no matter which directory the bot is started from.
 */
function resolveDatabaseUrl(url) {
  const match = url && /^file:(?!\/\/)(.*)$/.exec(url);
  if (!match) return url;
  const rel = match[1];
  if (path.isAbsolute(rel)) return url;
  return `file:${path.join(__dirname, '..', 'prisma', rel)}`;
}

function required(name) {
  const v = process.env[name];
  if (!v) {
    // Do not crash at import time — index.js checks these before login.
    return undefined;
  }
  return v;
}

module.exports = {
  get token() { return required('DISCORD_TOKEN'); },
  get clientId() { return required('CLIENT_ID'); },
  databaseUrl: resolveDatabaseUrl(process.env.DATABASE_URL || 'file:./data/bot.db'),
  embedColor: parseInt((process.env.EMBED_COLOR || '5865F2').replace('#', ''), 16) || 0x5865F2,
  errorColor: 0xED4245,
  successColor: 0x57F287,
  warnColor: 0xFEE75C,
  logLevel: (process.env.LOG_LEVEL || 'info').toLowerCase(),
  // Max messages fetched for transcripts / purge safety valves
  maxTranscriptMessages: 1000,
};
