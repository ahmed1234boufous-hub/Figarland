'use strict';

/**
 * index.js — entry point. Loads config, builds the shared context, registers
 * all modules, wires events and starts the Discord client.
 */

const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const config = require('./config');
const logger = require('./core/logger');
const db = require('./core/db');
const settings = require('./core/settings');
const permissions = require('./core/permissions');
const cooldown = require('./core/cooldown');
const audit = require('./core/audit');
const placeholders = require('./core/placeholders');
const embeds = require('./core/embeds');
const responses = require('./core/responses');
const registry = require('./core/registry');
const dashboards = require('./core/dashboards');
const scheduler = require('./core/scheduler');

// ── Register modules ─────────────────────────────────────────────────────────
require('./modules').loadAll();
registry.registerModule(require('./core/globalDashboard'));

// Register scheduler jobs from all modules
for (const mod of registry.getModules()) {
  for (const job of mod.schedulerJobs || []) scheduler.register({ ...job, moduleKey: mod.key });
}

// ── Shared context ───────────────────────────────────────────────────────────
const ctx = {
  client: null,
  config,
  db,
  logger,
  settings,
  permissions,
  cooldown,
  audit,
  placeholders,
  embeds,
  responses,
  registry,
  dashboards,
  scheduler,
  currentGuildId: null,
  inviteCache: new Map(),
};

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction],
});
ctx.client = client;

// ── Wire events ──────────────────────────────────────────────────────────────
const eventFiles = [require('./events/ready'), require('./events/interactionCreate'), ...require('./events/hooks')];
for (const event of eventFiles) {
  if (event.once) client.once(event.name, (...args) => event.execute(ctx, ...args));
  else client.on(event.name, (...args) => event.execute(ctx, ...args));
}

// ── Safety nets ──────────────────────────────────────────────────────────────
process.on('unhandledRejection', (err) => logger.error('[unhandledRejection]', err?.stack || err));
process.on('uncaughtException', (err) => logger.error('[uncaughtException]', err?.stack || err));

// ── Boot ─────────────────────────────────────────────────────────────────────
async function main() {
  if (!config.token || !config.clientId) {
    logger.error('Missing DISCORD_TOKEN or CLIENT_ID. Copy .env.example to .env and fill it in.');
    process.exit(1);
  }
  await db.$queryRaw`SELECT 1`;
  logger.info('Database connection OK');
  await client.login(config.token);
}

main().catch(async (err) => {
  logger.error('Fatal startup error:', err?.stack || err);
  await db.$disconnect().catch(() => {});
  process.exit(1);
});
