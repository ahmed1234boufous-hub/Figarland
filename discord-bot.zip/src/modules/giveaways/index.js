'use strict';

const { commands } = require('./commands');
const components = require('./components');
const dashboard = require('./dashboard');
const service = require('./service');

/**
 * giveaways — hosted giveaways with entry requirements, pauses, rerolls and
 * an automatic end/draw scheduler.
 *
 * Component prefix: 'gw:' (gw:join:<giveawayId>).
 */

module.exports = {
  key: 'giveaways',
  name: 'Giveaways',
  emoji: '🎉',
  dashboardCommandName: 'giveaway-dashboard',

  settingsSchema: [
    { key: 'winnerDm', label: 'DM winners', type: 'boolean', desc: 'Send winners a direct message when the draw happens.' },
  ],

  defaults: {
    enabled: true,
    settings: {
      winnerDm: true,
    },
    commands: {
      giveaway: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
    },
  },

  commands,

  dashboard,

  componentHandlers: { 'gw:': components.handleComponent },

  schedulerJobs: [
    {
      name: 'giveaways-end',
      intervalMs: 30000,
      run: (ctx) => service.runEndScan(ctx),
    },
  ],
};
