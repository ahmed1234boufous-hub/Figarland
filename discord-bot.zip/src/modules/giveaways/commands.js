'use strict';

const { ApplicationCommandOptionType, PermissionFlagsBits, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const db = require('../../core/db');
const settings = require('../../core/settings');
const audit = require('../../core/audit');
const config = require('../../config');
const { respond, replyError, replySimple } = require('../../core/responses');
const service = require('./service');

const SUB = ApplicationCommandOptionType.Subcommand;
const STR = ApplicationCommandOptionType.String;
const INT = ApplicationCommandOptionType.Integer;
const ROLE = ApplicationCommandOptionType.Role;

/** Host or administrators may manage a giveaway. */
function canManage(interaction, gw) {
  if (interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) return true;
  return gw?.hostedBy === interaction.user.id;
}

async function giveawayGuard(interaction, id, { mustExist = true } = {}) {
  const gw = await db.giveaway.findUnique({ where: { id } }).catch(() => null);
  if (!gw || gw.guildId !== interaction.guildId) {
    if (mustExist) await replyError(interaction, `Giveaway \`#${id}\` does not exist in this server.`);
    return null;
  }
  return gw;
}

const commands = [
  {
    name: 'giveaway',
    description: 'Run and manage giveaways in this server.',
    cooldown: 3,
    options: [
      {
        name: 'create',
        description: 'Start a new giveaway in this channel',
        type: SUB,
        options: [
          { name: 'prize', description: 'What winners receive', type: STR, required: true, maxLength: 200 },
          { name: 'duration', description: 'How long it runs, e.g. 30m, 2h or 3d', type: STR, required: true, maxLength: 10 },
          { name: 'winners', description: 'Number of winners (1-20)', type: INT, required: true, minValue: 1, maxValue: 20 },
          { name: 'required_role', description: 'Role entrants must have', type: ROLE, required: false },
          { name: 'min_level', description: 'Minimum leveling level to enter', type: INT, required: false, minValue: 0, maxValue: 500 },
          { name: 'min_account_age_days', description: 'Minimum Discord account age in days', type: INT, required: false, minValue: 0, maxValue: 3650 },
        ],
      },
      { name: 'end', description: 'End a giveaway now and draw the winners', type: SUB, options: [{ name: 'id', description: 'Giveaway ID (see /giveaway list)', type: INT, required: true, minValue: 1 }] },
      { name: 'reroll', description: 'Draw one additional winner from the entries', type: SUB, options: [{ name: 'id', description: 'Ended giveaway ID', type: INT, required: true, minValue: 1 }] },
      { name: 'pause', description: 'Pause a giveaway (the draw is skipped while paused)', type: SUB, options: [{ name: 'id', description: 'Giveaway ID', type: INT, required: true, minValue: 1 }] },
      { name: 'resume', description: 'Resume a paused giveaway', type: SUB, options: [{ name: 'id', description: 'Giveaway ID', type: INT, required: true, minValue: 1 }] },
      { name: 'list', description: 'List active, paused and ended giveaways', type: SUB, options: [] },
      { name: 'delete', description: 'Delete a giveaway and remove its message', type: SUB, options: [{ name: 'id', description: 'Giveaway ID', type: INT, required: true, minValue: 1 }] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand(false);
      switch (sub) {
        case 'create':
          return runCreate(ctx, interaction, cmdCfg);
        case 'end':
          return runEnd(ctx, interaction, cmdCfg);
        case 'reroll':
          return runReroll(ctx, interaction, cmdCfg);
        case 'pause':
          return runPauseResume(ctx, interaction, cmdCfg, true);
        case 'resume':
          return runPauseResume(ctx, interaction, cmdCfg, false);
        case 'list':
          return runList(ctx, interaction, cmdCfg);
        case 'delete':
          return runDelete(ctx, interaction, cmdCfg);
        default:
          return replyError(interaction, 'Unknown subcommand.');
      }
    },
  },
];

/** /giveaway create — persist the row and post the announcement embed. */
async function runCreate(ctx, interaction, cmdCfg) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    return replyError(interaction, 'You need the **Manage Server** permission to create giveaways.');
  }
  const prize = interaction.options.getString('prize', true).trim();
  const durationMs = service.parseDuration(interaction.options.getString('duration', true));
  if (!durationMs) {
    return replyError(interaction, 'Invalid duration. Use a value like `30m`, `2h` or `3d` (max 90d).');
  }
  const winnersCount = interaction.options.getInteger('winners', true);
  const role = interaction.options.getRole('required_role');
  const minLevel = interaction.options.getInteger('min_level');
  const minAge = interaction.options.getInteger('min_account_age_days');

  if (role && role.id === interaction.guild.id) {
    return replyError(interaction, 'The @everyone role cannot be used as a requirement — leave the option empty instead.');
  }

  await interaction.deferReply({ flags: 64 });

  const requirement = {
    roleId: role ? role.id : null,
    minLevel: minLevel === null || minLevel === undefined ? null : minLevel,
    minAccountAgeDays: minAge === null || minAge === undefined ? null : minAge,
  };

  const gw = await db.giveaway
    .create({
      data: {
        guildId: interaction.guildId,
        channelId: interaction.channelId,
        messageId: 'pending',
        prize,
        winnersCount,
        endAt: new Date(Date.now() + durationMs),
        hostedBy: interaction.user.id,
        requirementJson: settings.stringify(requirement),
        entriesJson: settings.stringify([]),
        paused: false,
        ended: false,
      },
    })
    .catch(() => null);
  if (!gw) return replyError(interaction, 'Could not save the giveaway — please try again.');

  const embed = service.buildGiveawayEmbed(gw);
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`gw:join:${gw.id}`).setLabel('Join').setEmoji('🎉').setStyle(ButtonStyle.Success),
  );
  const message = await interaction.channel.send({ embeds: [embed], components: [row] }).catch(() => null);
  if (message) {
    await db.giveaway.update({ where: { id: gw.id }, data: { messageId: message.id } }).catch(() => {});
  } else {
    await db.giveaway.delete({ where: { id: gw.id } }).catch(() => {});
    return replyError(interaction, 'I could not post the announcement in this channel — the giveaway was not created.');
  }

  await audit.log(interaction.guildId, interaction.user.id, 'giveaway.create', 'module:giveaways', null, { id: gw.id, prize, winnersCount, requirement });
  return respond(
    interaction,
    cmdCfg.responses.success,
    { prize },
    `🎉 Giveaway \`#${gw.id}\` started for **${prize}** — ends <t:${Math.floor(gw.endAt.getTime() / 1000)}:R>.`,
    { ephemeralDefault: true },
  );
}

/** /giveaway end — early draw, host or admin only. */
async function runEnd(ctx, interaction, cmdCfg) {
  const id = interaction.options.getInteger('id', true);
  const gw = await giveawayGuard(interaction, id);
  if (!gw) return;
  if (!canManage(interaction, gw)) return replyError(interaction, 'Only the giveaway host or administrators can end it early.');
  if (gw.ended) return replyError(interaction, `Giveaway \`#${id}\` has already ended.`);

  await interaction.deferReply({ flags: 64 });
  const winners = await service.drawAndEnd(ctx, interaction.guild, gw);
  await audit.log(interaction.guildId, interaction.user.id, 'giveaway.end', 'module:giveaways', { id, ended: false }, { id, ended: true, winners });
  return respond(
    interaction,
    cmdCfg.responses.success,
    { prize: gw.prize, winners: winners.map((w) => `<@${w}>`).join(' ') || 'nobody' },
    winners.length
      ? `🏁 Giveaway \`#${id}\` (**${gw.prize}**) ended — winner(s): ${winners.map((w) => `<@${w}>`).join(' ')}.`
      : `🏁 Giveaway \`#${id}\` (**${gw.prize}**) ended — no valid entries.`,
    { ephemeralDefault: true },
  );
}

/** /giveaway reroll — one extra winner from remaining valid entries. */
async function runReroll(ctx, interaction, cmdCfg) {
  const id = interaction.options.getInteger('id', true);
  const gw = await giveawayGuard(interaction, id);
  if (!gw) return;
  if (!canManage(interaction, gw)) return replyError(interaction, 'Only the giveaway host or administrators can reroll it.');
  if (!gw.ended) return replyError(interaction, `Giveaway \`#${id}\` has not ended yet — use \`/giveaway end\` first.`);

  await interaction.deferReply({ flags: 64 });
  const winner = await service.reroll(ctx, interaction.guild, gw);
  if (winner) await audit.log(interaction.guildId, interaction.user.id, 'giveaway.reroll', 'module:giveaways', null, { id, winner });
  return respond(
    interaction,
    cmdCfg.responses.success,
    { prize: gw.prize, winners: winner ? `<@${winner}>` : 'nobody' },
    winner
      ? `🔁 Reroll complete — the new winner of **${gw.prize}** is <@${winner}>.`
      : `🔁 Reroll for \`#${id}\`: no eligible entries left.`,
    { ephemeralDefault: true },
  );
}

/** /giveaway pause|resume — flip the paused flag and refresh the footer. */
async function runPauseResume(ctx, interaction, cmdCfg, pause) {
  const id = interaction.options.getInteger('id', true);
  const gw = await giveawayGuard(interaction, id);
  if (!gw) return;
  if (!canManage(interaction, gw)) return replyError(interaction, 'Only the giveaway host or administrators can do that.');
  if (gw.ended) return replyError(interaction, `Giveaway \`#${id}\` has already ended.`);
  if (gw.paused === pause) {
    return replyError(interaction, `Giveaway \`#${id}\` is already ${pause ? 'paused' : 'running'}.`);
  }

  await interaction.deferReply({ flags: 64 });
  await db.giveaway.update({ where: { id: gw.id }, data: { paused: pause } }).catch(() => {});
  await audit.log(interaction.guildId, interaction.user.id, pause ? 'giveaway.pause' : 'giveaway.resume', 'module:giveaways', { id, paused: !pause }, { id, paused: pause });

  const target = await service.fetchMessage(interaction.guild, gw);
  if (target) {
    await target.message
      .edit({ embeds: [service.buildGiveawayEmbed({ ...gw, paused: pause }, { paused: pause })] })
      .catch(() => {});
  }
  return respond(
    interaction,
    cmdCfg.responses.success,
    { prize: gw.prize },
    pause ? `⏸ Giveaway \`#${id}\` (**${gw.prize}**) paused.` : `▶️ Giveaway \`#${id}\` (**${gw.prize}**) resumed.`,
    { ephemeralDefault: true },
  );
}

/** /giveaway list — active / paused / ended with countdowns. */
async function runList(ctx, interaction, cmdCfg) {
  const rows = await db.giveaway
    .findMany({ where: { guildId: interaction.guildId }, orderBy: { id: 'desc' }, take: 50 })
    .catch(() => []);
  if (!rows.length) {
    return respond(interaction, cmdCfg.responses.success, {}, 'No giveaways have been created in this server yet.', { ephemeralDefault: true });
  }

  const now = Date.now();
  const active = [];
  const paused = [];
  const ended = [];
  for (const gw of rows) {
    if (gw.ended) ended.push(gw);
    else if (gw.paused) paused.push(gw);
    else active.push(gw);
  }

  const embed = new EmbedBuilder().setTitle('🎉 Giveaways').setColor(config.embedColor);
  const section = (list, render) => (list.length ? list.slice(0, 10).map(render).join('\n') : 'None');
  embed.addFields(
    {
      name: `🟢 Active (${active.length})`,
      value: section(active, (gw) => `\`#${gw.id}\` **${gw.prize}** — ends <t:${Math.floor(gw.endAt.getTime() / 1000)}:R> • ${service.parseEntries(gw).length} entrie(s)`),
    },
    {
      name: `⏸ Paused (${paused.length})`,
      value: section(paused, (gw) => `\`#${gw.id}\` **${gw.prize}** — waiting to be resumed • ${service.parseEntries(gw).length} entrie(s)`),
    },
    {
      name: `🏁 Ended (${ended.length})`,
      value: section(ended, (gw) => {
        const winners = service.parseWinners(gw);
        return `\`#${gw.id}\` **${gw.prize}** — ${winners.length ? `won by ${winners.map((w) => `<@${w}>`).join(' ')}` : 'no valid entries'}`;
      }),
    },
  );
  return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed], ephemeralDefault: true });
}

/** /giveaway delete — remove the row and try to delete the message. */
async function runDelete(ctx, interaction, cmdCfg) {
  const id = interaction.options.getInteger('id', true);
  const gw = await giveawayGuard(interaction, id);
  if (!gw) return;
  if (!canManage(interaction, gw)) return replyError(interaction, 'Only the giveaway host or administrators can delete it.');

  await db.giveaway.delete({ where: { id: gw.id } }).catch(() => {});
  if (gw.messageId && gw.messageId !== 'pending') {
    const target = await service.fetchMessage(interaction.guild, gw).catch(() => null);
    if (target) await target.message.delete().catch(() => {});
  }
  await audit.log(interaction.guildId, interaction.user.id, 'giveaway.delete', 'module:giveaways', { ...gw }, null);
  return respond(interaction, cmdCfg.responses.success, { prize: gw.prize }, `🗑 Giveaway \`#${id}\` (**${gw.prize}**) deleted.`, { ephemeralDefault: true });
}

module.exports = { commands };
