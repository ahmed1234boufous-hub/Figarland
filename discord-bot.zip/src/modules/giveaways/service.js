'use strict';

const { EmbedBuilder } = require('discord.js');
const db = require('../../core/db');
const settings = require('../../core/settings');
const config = require('../../config');

/**
 * giveaways/service.js — duration parsing, requirement checks, embed builders
 * and the shared end/reroll draw pipeline used by commands, the join button
 * and the scheduler job.
 */

const DURATION_RE = /^(\d+)(m|h|d)$/;
const MAX_DURATION_MS = 90 * 24 * 3600 * 1000;

function parseDuration(raw) {
  const match = DURATION_RE.exec(String(raw || '').trim().toLowerCase());
  if (!match) return null;
  const amount = parseInt(match[1], 10);
  if (!Number.isFinite(amount) || amount <= 0) return null;
  const multiplier = { m: 60 * 1000, h: 3600 * 1000, d: 24 * 3600 * 1000 }[match[2]];
  const ms = amount * multiplier;
  if (ms > MAX_DURATION_MS) return null;
  return ms;
}

function parseRequirement(row) {
  const req = settings.parse(row?.requirementJson, {}) || {};
  return {
    roleId: typeof req.roleId === 'string' ? req.roleId : null,
    minLevel: Number.isFinite(req.minLevel) ? req.minLevel : null,
    minAccountAgeDays: Number.isFinite(req.minAccountAgeDays) ? req.minAccountAgeDays : null,
  };
}

function hasRequirements(req) {
  return Boolean(req.roleId || req.minLevel !== null || req.minAccountAgeDays !== null);
}

function requirementLine(req) {
  if (!hasRequirements(req)) return 'No requirements';
  const parts = [];
  if (req.roleId) parts.push(`Role: <@&${req.roleId}>`);
  if (req.minLevel !== null) parts.push(`Level: ${req.minLevel}+`);
  if (req.minAccountAgeDays !== null) parts.push(`Account age: ${req.minAccountAgeDays}+ day(s)`);
  return parts.join(' • ');
}

/**
 * Check join requirements for a member.
 * @returns {{ ok: boolean, reason?: string }}
 */
async function meetsRequirements(guild, member, req) {
  if (!req) return { ok: true };
  if (req.roleId && !member.roles.cache.has(req.roleId)) {
    return { ok: false, reason: `You need the <@&${req.roleId}> role to enter.` };
  }
  if (req.minLevel !== null) {
    const row = await db.levelUser
      .findUnique({ where: { guildId_userId: { guildId: guild.id, userId: member.id } } })
      .catch(() => null);
    const level = row?.level ?? 0;
    if (level < req.minLevel) {
      return { ok: false, reason: `You need to be **level ${req.minLevel}** or higher to enter (you are level **${level}**).` };
    }
  }
  if (req.minAccountAgeDays !== null) {
    const ageMs = Date.now() - member.user.createdTimestamp;
    if (ageMs < req.minAccountAgeDays * 24 * 3600 * 1000) {
      return { ok: false, reason: `Your account must be at least **${req.minAccountAgeDays} day(s)** old to enter.` };
    }
  }
  return { ok: true };
}

function parseEntries(row) {
  const entries = settings.parse(row?.entriesJson, []) || [];
  return Array.isArray(entries) ? [...new Set(entries.filter((id) => typeof id === 'string'))] : [];
}

function parseWinners(row) {
  const winners = settings.parse(row?.winnersJson, []) || [];
  return Array.isArray(winners) ? winners.filter((id) => typeof id === 'string') : [];
}

function shufflePick(list, count) {
  const arr = [...list];
  for (let i = arr.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr.slice(0, Math.max(0, count));
}

// ─────────────────────────────── Embed builders ──────────────────────────────

function entriesLine(gw, count) {
  return `**Entries:** ${count ?? parseEntries(gw).length}`;
}

function buildGiveawayEmbed(gw, { paused = false } = {}) {
  const req = parseRequirement(gw);
  const embed = new EmbedBuilder()
    .setTitle('🎉 Giveaway')
    .setColor(config.embedColor)
    .setDescription(
      [
        `**${gw.prize}**`,
        '',
        `⏰ Ends: <t:${Math.floor(gw.endAt.getTime() / 1000)}:R>`,
        `🎁 Winners: **${gw.winnersCount}**`,
        `🙋 Hosted by: <@${gw.hostedBy}>`,
        `📋 Requirements: ${requirementLine(req)}`,
        entriesLine(gw),
      ].join('\n'),
    );
  embed.setFooter({ text: paused ? `⏸ Paused • ID ${gw.id}` : `Click the button to enter • ID ${gw.id}` });
  if (paused) embed.setColor(config.warnColor);
  return embed;
}

function buildEndedEmbed(gw, winners) {
  const embed = new EmbedBuilder().setTitle('🎉 GIVEAWAY ENDED').setTimestamp(new Date());
  if (winners.length) {
    embed.setColor(config.successColor).setDescription(
      [`**${gw.prize}**`, '', `🏆 Winner(s): ${winners.map((id) => `<@${id}>`).join(' ')}`, '', 'Congratulations!'].join('\n'),
    );
  } else {
    embed.setColor(config.warnColor).setDescription([`**${gw.prize}**`, '', 'This giveaway ended — no valid entries.'].join('\n'));
  }
  embed.setFooter({ text: `Giveaway ended • ID ${gw.id}` });
  return embed;
}

/** Fetch the announcement message for a giveaway (null when unavailable). */
async function fetchMessage(guild, gw) {
  const channel = guild.channels.cache.get(gw.channelId) || (await guild.channels.fetch(gw.channelId).catch(() => null));
  if (!channel || !channel.isTextBased()) return null;
  const message = await channel.messages.fetch(gw.messageId).catch(() => null);
  if (!message) return null;
  return { channel, message };
}

// ─────────────────────────────── Draw pipeline ───────────────────────────────

/** Re-validate entries at draw time and return the ones that still qualify. */
async function validEntries(guild, gw) {
  const req = parseRequirement(gw);
  const entries = parseEntries(gw);
  const valid = [];
  for (const userId of entries) {
    // eslint-disable-next-line no-await-in-loop
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) continue;
    // eslint-disable-next-line no-await-in-loop
    const check = await meetsRequirements(guild, member, req);
    if (check.ok) valid.push(userId);
  }
  return valid;
}

async function announceWinners(guild, gw, winners) {
  const target = await fetchMessage(guild, gw);
  const channel = target?.channel || guild.channels.cache.get(gw.channelId);
  if (!channel || !channel.isTextBased()) return;
  const embed = new EmbedBuilder()
    .setTitle('🎉 Giveaway ended')
    .setColor(config.successColor)
    .setDescription(`Congratulations ${winners.map((id) => `<@${id}>`).join(' ')} — you won **${gw.prize}**!`);
  await channel.send({ content: winners.map((id) => `<@${id}>`).join(' '), embeds: [embed] }).catch(() => {});
}

async function dmWinners(ctx, guild, gw, winners) {
  const modCfg = await settings.getModuleConfig(guild.id, 'giveaways');
  if (modCfg.settings?.winnerDm === false) return;
  for (const userId of winners) {
    // eslint-disable-next-line no-await-in-loop
    const user = await ctx.client.users.fetch(userId).catch(() => null);
    if (!user) continue;
    // eslint-disable-next-line no-await-in-loop
    await user.send(`🎉 Congratulations! You won **${gw.prize}** in **${guild.name}**!`).catch(() => {});
  }
}

/**
 * End a giveaway: pick winners, persist, edit the announcement message,
 * congratulate in the channel and DM the winners.
 * @returns {string[]} the winning user ids
 */
async function drawAndEnd(ctx, guild, gw) {
  const valid = await validEntries(guild, gw);
  const winners = shufflePick(valid, gw.winnersCount);

  await db.giveaway.update({ where: { id: gw.id }, data: { ended: true, paused: false, winnersJson: settings.stringify(winners) } }).catch(() => {});

  const target = await fetchMessage(guild, gw);
  const embed = buildEndedEmbed(gw, winners);
  if (target) {
    await target.message.edit({ embeds: [embed], components: [] }).catch(() => {});
  } else if (winners.length) {
    const channel = guild.channels.cache.get(gw.channelId);
    if (channel?.isTextBased()) await channel.send({ embeds: [embed] }).catch(() => {});
  }

  if (winners.length) {
    await announceWinners(guild, gw, winners);
    await dmWinners(ctx, guild, gw, winners).catch(() => {});
  }
  return winners;
}

/** Reroll: pick one more winner from entries excluding previous winners. */
async function reroll(ctx, guild, gw) {
  const previous = parseWinners(gw);
  const candidates = (await validEntries(guild, gw)).filter((id) => !previous.includes(id));
  const winner = shufflePick(candidates, 1)[0] || null;
  if (winner) {
    const winners = [...previous, winner];
    await db.giveaway.update({ where: { id: gw.id }, data: { winnersJson: settings.stringify(winners) } }).catch(() => {});
    const target = await fetchMessage(guild, gw);
    if (target) {
      const channel = target.channel;
      await channel
        .send({ content: `🔁 Reroll — the new winner of **${gw.prize}** is <@${winner}>!` })
        .catch(() => {});
      await dmWinners(ctx, guild, gw, [winner]).catch(() => {});
    }
  }
  return winner;
}

/** Scheduler job: end every due, unpaused giveaway. */
async function runEndScan(ctx) {
  const due = await db.giveaway
    .findMany({ where: { ended: false, paused: false, endAt: { lte: new Date() } }, take: 50 })
    .catch(() => []);
  for (const gw of due) {
    try {
      // eslint-disable-next-line no-await-in-loop
      const guild = ctx.client.guilds.cache.get(gw.guildId);
      if (!guild) {
        // eslint-disable-next-line no-await-in-loop
        await db.giveaway.update({ where: { id: gw.id }, data: { ended: true } }).catch(() => {});
        continue;
      }
      // eslint-disable-next-line no-await-in-loop
      await drawAndEnd(ctx, guild, gw);
    } catch (err) {
      ctx.logger.warn('[giveaways-end]', err?.message || err);
    }
  }
}

module.exports = {
  DURATION_RE,
  parseDuration,
  parseRequirement,
  hasRequirements,
  requirementLine,
  meetsRequirements,
  parseEntries,
  parseWinners,
  shufflePick,
  buildGiveawayEmbed,
  buildEndedEmbed,
  fetchMessage,
  validEntries,
  drawAndEnd,
  reroll,
  runEndScan,
  entriesLine,
};
