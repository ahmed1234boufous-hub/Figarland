'use strict';

const db = require('../../core/db');
const service = require('./service');

/** giveaways/dashboard.js — summary lines for the module dashboard overview. */
module.exports = {
  async summaryLines(guild, modCfg) {
    const rows = await db.giveaway.findMany({ where: { guildId: guild.id }, select: { ended: true, paused: true, entriesJson: true, winnersJson: true, endAt: true } }).catch(() => []);
    const active = rows.filter((gw) => !gw.ended && !gw.paused).length;
    const totalEntries = rows.reduce((acc, gw) => acc + service.parseEntries(gw).length, 0);
    const lastEnded = rows
      .filter((gw) => gw.ended && service.parseWinners(gw).length)
      .sort((a, b) => b.endAt.getTime() - a.endAt.getTime())[0];
    const lastWinner = lastEnded ? service.parseWinners(lastEnded)[0] : null;
    return [
      ['Active giveaways', `${active}`],
      ['Total entries', `${totalEntries}`],
      ['Last winner', lastWinner ? `<@${lastWinner}>` : '*(none yet)*'],
    ];
  },
};
