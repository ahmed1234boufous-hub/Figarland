'use strict';

const db = require('../../core/db');
const settings = require('../../core/settings');
const { replyError, replySimple } = require('../../core/responses');
const service = require('./service');

/**
 * giveaways/components.js — the gw:join:<giveawayId> button.
 * Validates state and requirements, toggles the entry and refreshes the
 * announcement embed's entries line.
 */

async function handleComponent(ctx, interaction, rest) {
  const [action, ...payloadParts] = rest.split(':');
  if (action !== 'join') return replyError(interaction, 'Unknown giveaway action.');

  const id = parseInt(payloadParts[0], 10);
  if (!Number.isFinite(id)) return replyError(interaction, 'Invalid giveaway reference.');

  const gw = await db.giveaway.findUnique({ where: { id } }).catch(() => null);
  if (!gw || gw.guildId !== interaction.guildId) return replyError(interaction, 'This giveaway no longer exists.');

  const modCfg = await settings.getModuleConfig(interaction.guildId, 'giveaways');
  if (!modCfg.enabled) return replyError(interaction, 'The giveaway system is currently disabled.');

  const guild = interaction.guild;
  if (!guild) return replyError(interaction, 'Giveaways can only be joined inside a server.');

  await interaction.deferReply({ flags: 64 });

  if (gw.ended) return replyError(interaction, 'This giveaway has already ended.');
  if (gw.paused) return replyError(interaction, 'This giveaway is currently paused.');
  if (interaction.user.bot) return replyError(interaction, 'Bots cannot enter giveaways.');

  const req = service.parseRequirement(gw);
  const check = await service.meetsRequirements(guild, interaction.member, req);
  if (!check.ok) return replyError(interaction, check.reason);

  const entries = service.parseEntries(gw);
  const has = entries.includes(interaction.user.id);
  const nextEntries = has ? entries.filter((entry) => entry !== interaction.user.id) : [...entries, interaction.user.id];

  await db.giveaway.update({ where: { id: gw.id }, data: { entriesJson: settings.stringify(nextEntries) } }).catch(() => {});

  const target = await service.fetchMessage(guild, gw);
  if (target) {
    try {
      await target.message.edit({ embeds: [service.buildGiveawayEmbed({ ...gw, entriesJson: settings.stringify(nextEntries) }, { paused: gw.paused })] });
    } catch {
      /* the announcement may have been deleted — the entry is still stored */
    }
  }

  return replySimple(
    interaction,
    has
      ? `👋 You left the giveaway for **${gw.prize}**.`
      : `✅ You joined the giveaway for **${gw.prize}** — good luck!\nEnds <t:${Math.floor(gw.endAt.getTime() / 1000)}:R>.`,
    { ephemeral: true },
  );
}

module.exports = { handleComponent };
