'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ApplicationCommandOptionType,
  ChannelType,
} = require('discord.js');
const { respond, replyError } = require('../../core/responses');
const settings = require('../../core/settings');
const audit = require('../../core/audit');
const config = require('../../config');
const db = require('../../core/db');
const service = require('./service');

const STR = ApplicationCommandOptionType.String;
const INT = ApplicationCommandOptionType.Integer;
const USER = ApplicationCommandOptionType.User;
const CH = ApplicationCommandOptionType.Channel;
const ROLE = ApplicationCommandOptionType.Role;
const BOOL = ApplicationCommandOptionType.Boolean;

const LB_LABELS = { xp: 'XP', economy: 'Economy', rep: 'Reputation', invites: 'Invites' };

function medal(i) {
  if (i === 0) return '🥇';
  if (i === 1) return '🥈';
  if (i === 2) return '🥉';
  return `**${i + 1}.**`;
}

function trunc(text, n) {
  const s = String(text || '');
  return s.length > n ? `${s.slice(0, n - 1)}…` : s;
}

/** Shared leaderboard renderer (also used by the lvl:lb:* buttons). */
async function buildLeaderboardEmbed(guild, type = 'xp') {
  const board = LB_LABELS[type] ? type : 'xp';
  let title = '📈 XP leaderboard';
  let lines = [];

  if (board === 'economy') {
    const modCfg = await settings.getModuleConfig(guild.id, 'economy');
    const symbol = modCfg.settings?.currencySymbol || '🪙';
    const [byWallet, byBank] = await Promise.all([
      db.economyUser.findMany({ where: { guildId: guild.id }, orderBy: { wallet: 'desc' }, take: 50 }),
      db.economyUser.findMany({ where: { guildId: guild.id }, orderBy: { bank: 'desc' }, take: 50 }),
    ]);
    const merged = [...byWallet, ...byBank].sort((a, b) => b.wallet + b.bank - (a.wallet + a.bank));
    const seen = new Set();
    const top = [];
    for (const r of merged) {
      if (seen.has(r.userId)) continue;
      seen.add(r.userId);
      top.push(r);
      if (top.length >= 10) break;
    }
    title = '💰 Economy leaderboard';
    lines = top.map((r, i) => `${medal(i)} <@${r.userId}> — ${symbol} ${r.wallet + r.bank}`);
  } else if (board === 'rep') {
    const top = await db.repUser.findMany({ where: { guildId: guild.id }, orderBy: { reps: 'desc' }, take: 10 });
    title = '🌟 Reputation leaderboard';
    lines = top.map((r, i) => `${medal(i)} <@${r.userId}> — ${r.reps} rep`);
  } else if (board === 'invites') {
    const [byRegular, byBonus] = await Promise.all([
      db.inviteStat.findMany({ where: { guildId: guild.id }, orderBy: { regular: 'desc' }, take: 50 }),
      db.inviteStat.findMany({ where: { guildId: guild.id }, orderBy: { bonus: 'desc' }, take: 50 }),
    ]);
    const merged = [...byRegular, ...byBonus].sort((a, b) => b.regular + b.bonus - (a.regular + a.bonus));
    const seen = new Set();
    const top = [];
    for (const r of merged) {
      if (seen.has(r.userId)) continue;
      seen.add(r.userId);
      top.push(r);
      if (top.length >= 10) break;
    }
    title = '📩 Invite leaderboard';
    lines = top.map((r, i) => `${medal(i)} <@${r.userId}> — ${r.regular + r.bonus} invite(s)`);
  } else {
    const top = await db.levelUser.findMany({ where: { guildId: guild.id }, orderBy: { totalXp: 'desc' }, take: 10 });
    title = '📈 XP leaderboard';
    lines = top.map((r, i) => `${medal(i)} <@${r.userId}> — level ${r.level} • ${r.totalXp} XP`);
  }

  return new EmbedBuilder()
    .setTitle(title)
    .setColor(config.embedColor)
    .setDescription(lines.join('\n') || 'No data yet — be the first!')
    .setFooter({ text: 'Server rankings • 10 shown' });
}

/** Text-only rank card (the image engine is not installed in this build). */
async function buildRankEmbed(guild, user, member, row) {
  const needed = service.xpNeeded(row.level);
  const rank = await service.getRank(guild.id, row.totalXp);
  const bar = service.progressBar(row.xp, needed, 20);
  return new EmbedBuilder()
    .setTitle(`📈 Rank — ${member?.displayName || user.username}`)
    .setColor(config.embedColor)
    .setThumbnail((member || user).displayAvatarURL({ size: 256, extension: 'png' }))
    .addFields(
      { name: 'Level', value: `${row.level}`, inline: true },
      { name: 'XP', value: `${row.xp} / ${needed}`, inline: true },
      { name: 'Total XP', value: `${row.totalXp}`, inline: true },
      { name: 'Rank', value: `#${rank}`, inline: true },
      { name: 'Voice minutes', value: `${row.voiceMin || 0}`, inline: true },
      { name: 'Progress', value: `${bar}`, inline: false },
    );
}

const commands = [
  {
    name: 'rank',
    description: "Show your XP rank card (or another member's).",
    cooldown: 3,
    options: [{ name: 'user', description: 'Member to inspect (default: you)', type: USER, required: false }],
    async run(ctx, interaction, cmdCfg) {
      const user = interaction.options.getUser('user') || interaction.user;
      const member = interaction.options.getMember('user') || (user.id === interaction.user.id ? interaction.member : null);
      const row = (await service.getRow(interaction.guildId, user.id)) || { xp: 0, level: 0, totalXp: 0, voiceMin: 0 };
      const embed = await buildRankEmbed(interaction.guild, user, member, row);
      const needed = service.xpNeeded(row.level);
      const rank = await service.getRank(interaction.guildId, row.totalXp);
      return respond(
        interaction,
        cmdCfg.responses.success,
        { user: `<@${user.id}>`, level: row.level, xp: row.xp, requiredxp: needed, totalxp: row.totalXp, rank },
        null,
        { embeds: [embed] },
      );
    },
  },
  {
    name: 'leaderboard',
    description: 'Show the server leaderboard (XP, economy, reputation or invites).',
    cooldown: 5,
    options: [
      {
        name: 'type',
        description: 'Which board to show (default: xp)',
        type: STR,
        required: false,
        choices: Object.entries(LB_LABELS).map(([value, name]) => ({ name, value })),
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const type = interaction.options.getString('type') || 'xp';
      const embed = await buildLeaderboardEmbed(interaction.guild, type);
      const row = new ActionRowBuilder().addComponents(
        Object.entries(LB_LABELS).map(([value, name]) =>
          new ButtonBuilder().setCustomId(`lvl:lb:${value}`).setLabel(name).setStyle(value === type ? ButtonStyle.Success : ButtonStyle.Secondary),
        ),
      );
      return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed], components: [row] });
    },
  },
  {
    name: 'level',
    description: "Show a member's level and XP remaining to the next one.",
    cooldown: 3,
    options: [{ name: 'user', description: 'Member to inspect (default: you)', type: USER, required: false }],
    async run(ctx, interaction, cmdCfg) {
      const user = interaction.options.getUser('user') || interaction.user;
      const row = (await service.getRow(interaction.guildId, user.id)) || { xp: 0, level: 0, totalXp: 0, voiceMin: 0 };
      const needed = service.xpNeeded(row.level);
      const embed = new EmbedBuilder()
        .setTitle(`Level — ${user.username}`)
        .setColor(config.embedColor)
        .setDescription(
          `**${user.username}** is on level **${row.level}** with **${row.xp} / ${needed}** XP.\n` +
            `**${Math.max(0, needed - row.xp)}** XP remaining until the next level.`,
        )
        .addFields(
          { name: 'Total XP', value: `${row.totalXp}`, inline: true },
          { name: 'Voice minutes', value: `${row.voiceMin || 0}`, inline: true },
        );
      return respond(
        interaction,
        cmdCfg.responses.success,
        { user: `<@${user.id}>`, level: row.level, xp: row.xp, requiredxp: needed, totalxp: row.totalXp },
        null,
        { embeds: [embed] },
      );
    },
  },
  {
    name: 'xp',
    description: "Manage a member's XP (add, remove or reset).",
    requiredPerms: ['ModerateMembers'],
    cooldown: 3,
    options: [
      {
        name: 'add',
        description: 'Add XP to a member',
        type: 1,
        options: [
          { name: 'user', description: 'Target member', type: USER, required: true },
          { name: 'amount', description: 'Amount of XP to add', type: INT, required: true, minValue: 1, maxValue: 1000000 },
        ],
      },
      {
        name: 'remove',
        description: 'Remove XP from a member',
        type: 1,
        options: [
          { name: 'user', description: 'Target member', type: USER, required: true },
          { name: 'amount', description: 'Amount of XP to remove', type: INT, required: true, minValue: 1, maxValue: 1000000 },
        ],
      },
      {
        name: 'reset',
        description: 'Reset a member back to level 0',
        type: 1,
        options: [{ name: 'user', description: 'Target member', type: USER, required: true }],
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();
      const user = interaction.options.getUser('user', true);

      if (sub === 'add' || sub === 'remove') {
        const amount = interaction.options.getInteger('amount', true);
        const res = sub === 'add' ? await service.applyXp(interaction.guildId, user.id, amount) : await service.removeXp(interaction.guildId, user.id, amount);
        await audit.log(interaction.guildId, interaction.user.id, 'leveling.xp', `user:${user.id}`, res.before, {
          xp: res.row.xp,
          level: res.row.level,
          totalXp: res.row.totalXp,
        });
        const verb = sub === 'add' ? 'Added' : 'Removed';
        return respond(
          interaction,
          cmdCfg.responses.success,
          { target: `<@${user.id}>`, amount },
          `${verb === 'Added' ? '➕' : '➖'} **${verb}** ${amount} XP ${sub === 'add' ? 'to' : 'from'} <@${user.id}> — now level **${res.row.level}** (${res.row.totalXp} total XP).`,
        );
      }

      const res = await service.resetXp(interaction.guildId, user.id);
      await audit.log(interaction.guildId, interaction.user.id, 'leveling.xp', `user:${user.id}`, res.before, { xp: 0, level: 0, totalXp: 0 });
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>`, amount: 0 }, `♻️ Reset <@${user.id}> back to level 0.`);
    },
  },
  {
    name: 'levelrole',
    description: 'Manage roles awarded when members reach a level.',
    requiredPerms: ['ManageRoles'],
    cooldown: 3,
    options: [
      {
        name: 'add',
        description: 'Award a role when members reach a level',
        type: 1,
        options: [
          { name: 'level', description: 'Level that grants the role', type: INT, required: true, minValue: 1, maxValue: 1000 },
          { name: 'role', description: 'Role to award', type: ROLE, required: true },
          { name: 'stack', description: 'Keep this role even when higher rewards replace it', type: BOOL, required: false },
        ],
      },
      {
        name: 'remove',
        description: 'Remove the reward role configured for a level',
        type: 1,
        options: [{ name: 'level', description: 'Level whose reward should be removed', type: INT, required: true, minValue: 1, maxValue: 1000 }],
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();

      if (sub === 'add') {
        const level = interaction.options.getInteger('level', true);
        const role = interaction.options.getRole('role', true);
        const stack = interaction.options.getBoolean('stack') || false;
        if (role.managed) return replyError(interaction, 'That role is managed by an integration and cannot be used as a reward.');
        if (role.position >= interaction.guild.members.me.roles.highest.position) {
          return replyError(interaction, 'That role is above my highest role — I would never be able to assign it.');
        }
        const row = await db.levelRole.create({ data: { guildId: interaction.guildId, level, roleId: role.id, stack } });
        await audit.log(interaction.guildId, interaction.user.id, 'config.levelrole.add', 'leveling:levelrole', null, {
          id: row.id,
          level,
          roleId: role.id,
          stack,
        });
        return respond(
          interaction,
          cmdCfg.responses.success,
          { level, role: `<@&${role.id}>` },
          `✅ Members now receive <@&${role.id}> when they reach level **${level}**${stack ? ' (always stacks)' : ''}.`,
        );
      }

      const level = interaction.options.getInteger('level', true);
      const res = await db.levelRole.deleteMany({ where: { guildId: interaction.guildId, level } });
      if (!res.count) return replyError(interaction, `No reward role is configured for level **${level}**.`);
      await audit.log(interaction.guildId, interaction.user.id, 'config.levelrole.remove', 'leveling:levelrole', { level }, null);
      return respond(interaction, cmdCfg.responses.success, { level, role: '' }, `✅ Removed the reward role for level **${level}** (${res.count} row(s)).`);
    },
  },
  {
    name: 'levelconfig',
    description: 'Configure level-up announcements and XP filters.',
    requiredPerms: ['ManageGuild'],
    cooldown: 3,
    options: [
      {
        name: 'setannounce',
        description: 'Set the level-up announcement channel',
        type: 1,
        options: [{ name: 'channel', description: 'Channel for level-up announcements', type: CH, required: true }],
      },
      {
        name: 'ignorechannel',
        description: 'Add or remove a channel from XP tracking',
        type: 1,
        options: [
          { name: 'channel', description: 'Channel to ignore or unignore', type: CH, required: true },
          {
            name: 'mode',
            description: 'Add or remove',
            type: STR,
            required: true,
            choices: [
              { name: 'add', value: 'add' },
              { name: 'remove', value: 'remove' },
            ],
          },
        ],
      },
      { name: 'show', description: 'Show the current leveling configuration', type: 1, options: [] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();
      const modCfg = await settings.getModuleConfig(interaction.guildId, 'leveling');

      if (sub === 'setannounce') {
        const channel = interaction.options.getChannel('channel', true);
        if (channel.type !== ChannelType.GuildText) return replyError(interaction, 'Pick a regular text channel for announcements.');
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const next = await settings.setModuleSetting(interaction.guildId, 'leveling', 'announceChannel', channel.id);
        await audit.log(interaction.guildId, interaction.user.id, 'config.leveling.announce', 'module:leveling', before, next);
        return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>` }, `✅ Level-up announcements will now be posted in <#${channel.id}>.`);
      }

      if (sub === 'ignorechannel') {
        const channel = interaction.options.getChannel('channel', true);
        const mode = interaction.options.getString('mode', true);
        const list = Array.isArray(modCfg.settings.ignoredChannelIds) ? [...modCfg.settings.ignoredChannelIds] : [];
        if (mode === 'add') {
          if (list.includes(channel.id)) return replyError(interaction, 'That channel is already ignored.');
          list.push(channel.id);
        } else {
          if (!list.includes(channel.id)) return replyError(interaction, 'That channel is not on the ignore list.');
          const idx = list.indexOf(channel.id);
          list.splice(idx, 1);
        }
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const next = await settings.setModuleSetting(interaction.guildId, 'leveling', 'ignoredChannelIds', list);
        await audit.log(interaction.guildId, interaction.user.id, `config.leveling.ignorechannel.${mode}`, 'module:leveling', before, next);
        return respond(
          interaction,
          cmdCfg.responses.success,
          { channel: `<#${channel.id}>` },
          `✅ ${mode === 'add' ? 'Now ignoring' : 'No longer ignoring'} <#${channel.id}> for XP (${list.length} channel(s) ignored).`,
        );
      }

      const s = modCfg.settings;
      const embed = new EmbedBuilder()
        .setTitle('⚙️ Leveling configuration')
        .setColor(config.embedColor)
        .addFields(
          { name: 'XP per message', value: `${s.minXp} – ${s.maxXp}`, inline: true },
          { name: 'Cooldown', value: `${s.cooldownSeconds}s`, inline: true },
          { name: 'Voice XP', value: `${s.voiceXpPerMinute}/min`, inline: true },
          { name: 'Announce channel', value: s.announceChannel ? `<#${s.announceChannel}>` : '*(not set)*', inline: true },
          { name: 'DM level-ups', value: s.dmLevelUp ? 'ON' : 'OFF', inline: true },
          { name: 'Reward roles', value: s.replaceRewards ? 'Replace with highest' : 'Stack all', inline: true },
          { name: 'Announcement template', value: trunc(s.announceMessage || '', 500) },
          {
            name: 'Ignored channels',
            value: Array.isArray(s.ignoredChannelIds) && s.ignoredChannelIds.length ? s.ignoredChannelIds.map((id) => `<#${id}>`).join(' ') : '*(none)*',
          },
          {
            name: 'Ignored roles',
            value: Array.isArray(s.ignoredRoleIds) && s.ignoredRoleIds.length ? s.ignoredRoleIds.map((id) => `<@&${id}>`).join(' ') : '*(none)*',
          },
        )
        .setFooter({ text: 'Edit values in /leveling-dashboard → Advanced' });
      return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
    },
  },
];

module.exports = { commands, buildLeaderboardEmbed, buildRankEmbed };
