'use strict';

const db = require('../../core/db');
const placeholders = require('../../core/placeholders');

/**
 * Leveling service — XP math, level-up plumbing, voice session tracking and
 * reward-role handling. xpNeeded(level) is the XP required WITHIN a level:
 * level 0 -> 100 XP, level 1 -> 150 XP, and so on.
 */

const xpCooldowns = new Map(); // `${guildId}:${userId}` -> unlock timestamp
const voiceJoins = new Map(); // `${guildId}:${userId}` -> voice join timestamp

function xpNeeded(level) {
  return 100 + 50 * Math.max(0, level);
}

/** Re-derive (level, xp-within-level) from a total XP amount. */
function levelsFromTotal(totalXp) {
  let level = 0;
  let remaining = Math.max(0, Math.floor(totalXp || 0));
  while (remaining >= xpNeeded(level)) {
    remaining -= xpNeeded(level);
    level += 1;
    if (level > 100000) break; // safety valve against runaway loops
  }
  return { level, xp: remaining };
}

/** Random integer in [min, max] (inclusive). */
function randInt(min, max) {
  if (!Number.isFinite(min) || !Number.isFinite(max)) return 0;
  const lo = Math.ceil(Math.min(min, max));
  const hi = Math.floor(Math.max(min, max));
  if (hi <= lo) return lo;
  return Math.floor(Math.random() * (hi - lo + 1)) + lo;
}

/** 20-character progress bar using filled and empty blocks. */
function progressBar(current, needed, size = 20) {
  const ratio = needed > 0 ? Math.min(1, Math.max(0, current / needed)) : 0;
  const filled = Math.round(ratio * size);
  return '▰'.repeat(filled) + '▱'.repeat(size - filled);
}

/**
 * Per-user XP cooldown gate (in-memory).
 * Returns true when the user may gain XP now (and arms the cooldown).
 */
function checkXpCooldown(key, seconds) {
  if (!seconds || seconds <= 0) return true;
  const now = Date.now();
  const until = xpCooldowns.get(key) || 0;
  if (until > now) return false;
  xpCooldowns.set(key, now + seconds * 1000);
  return true;
}

// Keep the in-memory maps bounded.
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of xpCooldowns) if (v < now) xpCooldowns.delete(k);
  for (const [k, v] of voiceJoins) if (now - v > 24 * 3600 * 1000) voiceJoins.delete(k);
}, 10 * 60 * 1000).unref();

async function getRow(guildId, userId) {
  return db.levelUser.findUnique({ where: { guildId_userId: { guildId, userId } } });
}

/** Grant XP and walk the level curve. Returns before/after snapshots. */
async function applyXp(guildId, userId, amount) {
  const row = await getRow(guildId, userId);
  const before = row ? { xp: row.xp, level: row.level, totalXp: row.totalXp } : { xp: 0, level: 0, totalXp: 0 };
  const totalXp = Math.max(0, before.totalXp + Math.floor(amount || 0));
  const { level, xp } = levelsFromTotal(totalXp);
  const after = await db.levelUser.upsert({
    where: { guildId_userId: { guildId, userId } },
    create: { guildId, userId, xp, level, totalXp, lastXpAt: new Date() },
    update: { xp, level, totalXp, lastXpAt: new Date() },
  });
  return { row: after, before, oldLevel: before.level, newLevel: level, leveled: level > before.level };
}

/** Remove XP (floors at 0 total) and re-derive level/xp consistently. */
async function removeXp(guildId, userId, amount) {
  const row = await getRow(guildId, userId);
  const before = row ? { xp: row.xp, level: row.level, totalXp: row.totalXp } : { xp: 0, level: 0, totalXp: 0 };
  const totalXp = Math.max(0, before.totalXp - Math.floor(amount || 0));
  const { level, xp } = levelsFromTotal(totalXp);
  const after = await db.levelUser.upsert({
    where: { guildId_userId: { guildId, userId } },
    create: { guildId, userId, xp, level, totalXp },
    update: { xp, level, totalXp },
  });
  return { row: after, before, after: { xp, level, totalXp } };
}

/** Reset a member to level 0 (row is kept for stats/history). */
async function resetXp(guildId, userId) {
  const row = await getRow(guildId, userId);
  const before = row ? { xp: row.xp, level: row.level, totalXp: row.totalXp } : { xp: 0, level: 0, totalXp: 0 };
  const after = await db.levelUser.upsert({
    where: { guildId_userId: { guildId, userId } },
    create: { guildId, userId, xp: 0, level: 0, totalXp: 0 },
    update: { xp: 0, level: 0, totalXp: 0 },
  });
  return { before, after };
}

/** Leaderboard position by total XP: number of users with more XP, plus one. */
async function getRank(guildId, totalXp) {
  const higher = await db.levelUser.count({ where: { guildId, totalXp: { gt: totalXp } } });
  return higher + 1;
}

// ── Voice session tracking ───────────────────────────────────────────────────

/** Returns true when a NEW voice session started for this user. */
function trackVoiceJoin(guildId, userId, oldChannelId, newChannelId) {
  const key = `${guildId}:${userId}`;
  if (newChannelId && !oldChannelId) {
    voiceJoins.set(key, Date.now());
    return true;
  }
  return false;
}

/**
 * Returns elapsed minutes when the user LEFT voice, otherwise null.
 * Moving between channels keeps the original session (no double counting).
 */
function trackVoiceLeave(guildId, userId, oldChannelId, newChannelId) {
  const key = `${guildId}:${userId}`;
  if (oldChannelId && !newChannelId) {
    const joinedAt = voiceJoins.get(key);
    voiceJoins.delete(key);
    if (!joinedAt) return null;
    return Math.max(0, (Date.now() - joinedAt) / 60000);
  }
  return null;
}

/**
 * Level-up side effects: reward roles, channel announcement, optional DM.
 * Every step is best-effort and must never throw.
 */
async function handleLevelUp(ctx, guild, member, oldLevel, newLevel, modCfg) {
  const s = modCfg?.settings || {};

  // Reward roles
  try {
    const rows = await db.levelRole.findMany({ where: { guildId: guild.id } });
    if (rows.length && member) {
      const me = guild.members.me;
      if (s.replaceRewards) {
        // Only the highest earned reward is kept; rows flagged stack survive.
        const eligible = rows.filter((r) => r.level <= newLevel).sort((a, b) => b.level - a.level);
        const keep = eligible[0] || null;
        for (const r of rows) {
          if (keep && r.id === keep.id) continue;
          if (r.stack) continue;
          if (member.roles.cache.has(r.roleId)) {
            await member.roles.remove(r.roleId, 'Level reward replaced').catch(() => {});
          }
        }
        if (keep && !member.roles.cache.has(keep.roleId)) {
          await member.roles.add(keep.roleId, 'Level reward').catch(() => {});
        }
      } else {
        // Stack mode: grant every earned reward the member is missing.
        for (const r of rows) {
          if (r.level > newLevel) continue;
          if (member.roles.cache.has(r.roleId)) continue;
          const role = guild.roles.cache.get(r.roleId);
          if (!role || role.managed) continue;
          if (me && role.position >= me.roles.highest.position) continue;
          await member.roles.add(r.roleId, 'Level reward').catch(() => {});
        }
      }
    }
  } catch {
    /* rewards are best-effort */
  }

  // Announcement + optional DM
  try {
    const vars = {
      member,
      user: member?.user || null,
      guild,
      extra: { level: newLevel, oldlevel: oldLevel },
    };
    const text = placeholders.fill(s.announceMessage || '', vars).trim();
    if (text && s.announceChannel) {
      const channel = guild.channels.cache.get(s.announceChannel);
      if (channel) await channel.send({ content: text.slice(0, 2000) }).catch(() => {});
    }
    if (text && s.dmLevelUp && member) {
      await member.send(text.slice(0, 2000)).catch(() => {});
    }
  } catch {
    /* announcements are best-effort */
  }
}

module.exports = {
  xpNeeded,
  levelsFromTotal,
  randInt,
  progressBar,
  checkXpCooldown,
  getRow,
  applyXp,
  removeXp,
  resetXp,
  getRank,
  trackVoiceJoin,
  trackVoiceLeave,
  handleLevelUp,
};
