'use strict';

const db = require('../../core/db');

module.exports = {
  async summaryLines(guild, modCfg) {
    const [tracked, agg] = await Promise.all([
      db.levelUser.count({ where: { guildId: guild.id } }),
      db.levelUser.aggregate({ _sum: { totalXp: true }, where: { guildId: guild.id } }),
    ]);
    return [
      ['Tracked members', `${tracked}`],
      ['Total XP awarded', `${agg._sum.totalXp || 0}`],
      ['Announce channel', modCfg.settings?.announceChannel ? `<#${modCfg.settings.announceChannel}>` : '*(not set — Advanced)*'],
    ];
  },
};
