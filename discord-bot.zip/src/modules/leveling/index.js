'use strict';

const settings = require('../../core/settings');
const { commands, buildLeaderboardEmbed } = require('./commands');
const service = require('./service');
const dashboard = require('./dashboard');

module.exports = {
  key: 'leveling',
  name: 'Leveling & XP',
  emoji: '📈',
  dashboardCommandName: 'leveling-dashboard',

  settingsSchema: [
    { key: 'minXp', label: 'Min XP per message', type: 'number', desc: 'Lower bound of the random XP gained per message.' },
    { key: 'maxXp', label: 'Max XP per message', type: 'number', desc: 'Upper bound of the random XP gained per message.' },
    { key: 'cooldownSeconds', label: 'XP cooldown (seconds)', type: 'number', desc: 'Per-user cooldown between XP gains from messages.' },
    { key: 'voiceXpPerMinute', label: 'Voice XP per minute', type: 'number', desc: 'XP awarded per full minute spent in voice. 0 = disabled.' },
    { key: 'announceChannel', label: 'Announcement channel', type: 'channel', desc: 'Where level-up announcements are posted (also /levelconfig setannounce).' },
    { key: 'announceMessage', label: 'Level-up message', type: 'textarea', desc: 'Supports {user} {displayname} {level} {oldlevel} {server} {membercount}' },
    { key: 'dmLevelUp', label: 'DM level-ups', type: 'boolean', desc: 'Also send the level-up message as a direct message.' },
    { key: 'replaceRewards', label: 'Replace reward roles', type: 'boolean', desc: 'ON: only the highest earned level role. OFF: stack all earned roles.' },
    { key: 'ignoredRoleIds', label: 'Ignored roles', type: 'roles', desc: 'Members holding these roles do not earn XP.' },
  ],

  defaults: {
    enabled: true,
    settings: {
      minXp: 15,
      maxXp: 25,
      cooldownSeconds: 60,
      voiceXpPerMinute: 0,
      announceChannel: null,
      announceMessage: '🎉 {displayname} just reached **level {level}**!',
      dmLevelUp: false,
      replaceRewards: false,
      ignoredRoleIds: [],
      ignoredChannelIds: [],
      dashboardRoles: [],
    },
    commands: {
      rank: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      leaderboard: { cooldown: 5, responses: { success: { text: '', ephemeral: false } } },
      level: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      xp: { cooldown: 3, responses: { success: { text: '', ephemeral: true } } },
      levelrole: { cooldown: 3, responses: { success: { text: '', ephemeral: true } } },
      levelconfig: { cooldown: 3, responses: { success: { text: '', ephemeral: true } } },
    },
  },

  commands,

  dashboard,

  componentHandlers: {
    'lvl:': async (ctx, interaction, rest) => {
      try {
        const [action, type] = (rest || '').split(':');
        if (action !== 'lb' || !interaction.guild) return;
        const embed = await buildLeaderboardEmbed(interaction.guild, type || 'xp');
        await interaction.update({ embeds: [embed], components: interaction.message.components }).catch(() => {});
      } catch (err) {
        ctx.logger.warn(`[leveling] component failed: ${err?.message || err}`);
      }
    },
  },

  modalHandlers: {},

  hooks: {
    async messageCreate(ctx, message) {
      try {
        if (!message?.guild || !message.author || message.author.bot) return;
        const member = message.member;
        if (!member) return;

        const modCfg = await settings.getModuleConfig(message.guild.id, 'leveling');
        if (!modCfg.enabled) return;
        const s = modCfg.settings;

        const ignoredChannels = Array.isArray(s.ignoredChannelIds) ? s.ignoredChannelIds : [];
        if (ignoredChannels.includes(message.channelId)) return;
        const ignoredRoles = Array.isArray(s.ignoredRoleIds) ? s.ignoredRoleIds : [];
        if (ignoredRoles.length && member.roles.cache.some((r) => ignoredRoles.includes(r.id))) return;

        const cooldownSeconds = Math.max(0, parseInt(s.cooldownSeconds, 10) || 0);
        if (!service.checkXpCooldown(`${message.guild.id}:${message.author.id}`, cooldownSeconds)) return;

        const min = Math.max(0, parseInt(s.minXp, 10) || 0);
        const max = Math.max(min, parseInt(s.maxXp, 10) || min);
        const gain = service.randInt(min, max);
        if (gain <= 0) return;

        const result = await service.applyXp(message.guild.id, message.author.id, gain);
        if (result.leveled) {
          await service.handleLevelUp(ctx, message.guild, member, result.oldLevel, result.newLevel, modCfg);
        }
      } catch {
        /* XP gain must never break message handling */
      }
    },

    async voiceStateUpdate(ctx, oldState, newState) {
      try {
        const userId = newState?.id || oldState?.id;
        const guild = newState?.guild || oldState?.guild;
        if (!userId || !guild) return;

        if (service.trackVoiceJoin(guild.id, userId, oldState?.channelId || null, newState?.channelId || null)) return;
        const minutes = service.trackVoiceLeave(guild.id, userId, oldState?.channelId || null, newState?.channelId || null);
        if (minutes === null) return; // not a leave (mute toggles, moves, ...)

        const modCfg = await settings.getModuleConfig(guild.id, 'leveling');
        if (!modCfg.enabled) return;

        const wholeMinutes = Math.floor(minutes);
        if (wholeMinutes > 0) {
          await updateVoiceMinutes(guild.id, userId, wholeMinutes);
        }

        const perMinute = Number(modCfg.settings.voiceXpPerMinute) || 0;
        const xp = Math.floor(minutes * perMinute);
        if (xp > 0) {
          const member = guild.members.cache.get(userId) || (await guild.members.fetch(userId).catch(() => null));
          if (!member) return;
          const result = await service.applyXp(guild.id, userId, xp);
          if (result.leveled) {
            await service.handleLevelUp(ctx, guild, member, result.oldLevel, result.newLevel, modCfg);
          }
        }
      } catch {
        /* voice XP is best-effort */
      }
    },
  },

  schedulerJobs: [],
};

async function updateVoiceMinutes(guildId, userId, minutes) {
  const db = require('../../core/db');
  await db.levelUser
    .update({
      where: { guildId_userId: { guildId, userId } },
      data: { voiceMin: { increment: minutes } },
    })
    .catch(() => {});
}
