'use strict';

const { EmbedBuilder, ApplicationCommandOptionType } = require('discord.js');
const settings = require('../../core/settings');
const placeholders = require('../../core/placeholders');
const { respond, replyError, replySimple } = require('../../core/responses');
const config = require('../../config');
const audit = require('../../core/audit');
const db = require('../../core/db');

const STR = ApplicationCommandOptionType.String;
const ROLE = ApplicationCommandOptionType.Role;

/**
 * Render the welcome/goodbye payload for a member.
 * The dynamic image engine is not part of this build — messages use text +
 * embeds with full {variable} support (see README → "Adding the image engine").
 */
function render(ctx, guild, member, kind, modCfg) {
  const s = modCfg.settings;
  const template = kind === 'welcome' ? s.welcomeText : s.goodbyeText;
  const vars = { member, user: member.user, guild, extra: {} };
  const text = placeholders.fill(template || '', vars);

  if (s.useEmbed) {
    const embed = new EmbedBuilder()
      .setColor(kind === 'welcome' ? config.successColor : config.errorColor)
      .setDescription(text || (kind === 'welcome' ? `Welcome {user} to **{server}**!` : `**{displayname}** has left **{server}**.`))
      .setAuthor({ name: kind === 'welcome' ? 'New member' : 'Member left', iconURL: guild.iconURL({ size: 128, extension: 'png' }) || undefined })
      .setThumbnail(member.user.displayAvatarURL({ size: 256, extension: 'png' }))
      .addFields(
        { name: 'Member count', value: `${guild.memberCount}`, inline: true },
        { name: 'Account created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
      )
      .setTimestamp();
    return { content: kind === 'welcome' ? `<@${member.id}>` : '', embeds: [embed] };
  }
  return { content: text || (kind === 'welcome' ? `Welcome <@${member.id}> to **${guild.name}**!` : `**${member.displayName}** has left **${guild.name}**.`), embeds: [] };
}

async function sendKind(ctx, guild, member, kind) {
  const modCfg = await settings.getModuleConfig(guild.id, 'welcome');
  if (!modCfg.enabled) return;
  const s = modCfg.settings;
  if (kind === 'welcome' && s.welcomeDisabled) return;
  if (kind === 'goodbye' && s.goodbyeDisabled) return;

  const channelId = kind === 'welcome' ? s.welcomeChannel : s.goodbyeChannel;
  if (!channelId) return;
  const channel = guild.channels.cache.get(channelId);
  if (!channel) return;

  const payload = render(ctx, guild, member, kind, modCfg);
  await channel.send(payload).catch((err) => ctx.logger.warn(`[welcome] send failed: ${err?.message}`));

  if (kind === 'welcome' && s.dmWelcome) {
    const dmTemplate = s.dmWelcomeText || 'Welcome to **{server}**, {displayname}! We are glad to have you.';
    await member.send(placeholders.fill(dmTemplate, { member, user: member.user, guild })).catch(() => {});
  }
}

const commands = [
  {
    name: 'welcome',
    description: 'Configure and preview welcome messages.',
    cooldown: 3,
    options: [
      {
        name: 'action',
        description: 'What to do',
        type: STR,
        required: true,
        choices: [
          { name: 'preview', value: 'preview' },
          { name: 'test', value: 'test' },
          { name: 'disable', value: 'disable' },
          { name: 'enable', value: 'enable' },
          { name: 'reset', value: 'reset' },
          { name: 'setup', value: 'setup' },
          { name: 'image', value: 'image' },
          { name: 'background', value: 'background' },
        ],
      },
    ],
    requiredPerms: ['ManageGuild'],
    async run(ctx, interaction, cmdCfg) {
      const action = interaction.options.getString('action', true);
      const modCfg = await settings.getModuleConfig(interaction.guildId, 'welcome');

      if (action === 'preview') {
        const payload = render(ctx, interaction.guild, interaction.member, 'welcome', modCfg);
        return replySimple(interaction, 'Welcome preview (with your data):', { ephemeral: true, embed: payload.embeds[0] || null }) .then(async (res) => {
          if (!payload.embeds.length && res) await interaction.followUp({ content: payload.content, flags: 64 }).catch(() => {});
          return res;
        });
      }
      if (action === 'test') {
        const payload = render(ctx, interaction.guild, interaction.member, 'welcome', modCfg);
        const channelId = modCfg.settings.welcomeChannel;
        if (!channelId) return replyError(interaction, 'No welcome channel configured — set one in the **/welcome-dashboard → Advanced**.');
        const channel = interaction.guild.channels.cache.get(channelId);
        if (!channel) return replyError(interaction, 'The configured welcome channel no longer exists.');
        await channel.send(payload).catch(() => {});
        return replySimple(interaction, `✅ Test welcome sent to <#${channelId}>.`, { ephemeral: true });
      }
      if (action === 'disable' || action === 'enable') {
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const next = await settings.setModuleSetting(interaction.guildId, 'welcome', 'welcomeDisabled', action === 'disable');
        await audit.log(interaction.guildId, interaction.user.id, `config.welcome.${action}`, 'module:welcome', before, next);
        return replySimple(interaction, `${action === 'disable' ? '🔴 Welcome messages disabled' : '🟢 Welcome messages enabled'} — configuration kept.`, { ephemeral: true });
      }
      if (action === 'reset') {
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const next = await settings.setModuleConfig(interaction.guildId, 'welcome', { settings: (await require('../../core/registry').getModule('welcome')).defaults.settings });
        await audit.log(interaction.guildId, interaction.user.id, 'config.welcome.reset', 'module:welcome', before, next);
        return replySimple(interaction, '♻️ Welcome settings restored to the default template (channel selection kept).', { ephemeral: true });
      }
      if (action === 'setup') {
        return replySimple(
          interaction,
          `👋 **Welcome setup**\n1. Open \`/welcome-dashboard\` (admins + dashboard roles)\n2. **Advanced** → set *Welcome channel*, templates and DM behavior\n3. Use \`/welcome test\` to verify\n\nPlaceholders: \`{user} {displayname} {server} {membercount} {joindate}\` — full list via \`/dashboard variables\`.`,
          { ephemeral: true },
        );
      }
      // image / background
      return replySimple(
        interaction,
        '🖼️ The **dynamic image engine** (generated welcome cards with backgrounds, avatars and text layers) is not installed in this build.\nThis build ships the full text + embed pipeline; the rendering hook is isolated in `src/modules/welcome/index.js → render()` so @napi-rs/canvas can be added without touching the rest of the bot. See README → “Adding the image engine”.',
        { ephemeral: true },
      );
    },
  },
  {
    name: 'goodbye',
    description: 'Configure member departure messages.',
    cooldown: 3,
    requiredPerms: ['ManageGuild'],
    options: [
      {
        name: 'action',
        description: 'What to do',
        type: STR,
        required: true,
        choices: [
          { name: 'preview', value: 'preview' },
          { name: 'disable', value: 'disable' },
          { name: 'enable', value: 'enable' },
          { name: 'setup', value: 'setup' },
        ],
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const action = interaction.options.getString('action', true);
      const modCfg = await settings.getModuleConfig(interaction.guildId, 'welcome');
      if (action === 'preview') {
        const payload = render(ctx, interaction.guild, interaction.member, 'goodbye', modCfg);
        return replySimple(interaction, 'Goodbye preview:', { ephemeral: true, embed: payload.embeds[0] || null });
      }
      if (action === 'disable' || action === 'enable') {
        const next = await settings.setModuleSetting(interaction.guildId, 'welcome', 'goodbyeDisabled', action === 'disable');
        await audit.log(interaction.guildId, interaction.user.id, `config.goodbye.${action}`, 'module:welcome', null, next);
        return replySimple(interaction, `${action === 'disable' ? '🔴 Goodbye messages disabled' : '🟢 Goodbye messages enabled'}.`, { ephemeral: true });
      }
      return replySimple(interaction, '👋 Configure the goodbye channel and template in **/welcome-dashboard → Advanced** (Goodbye channel, Goodbye template).', { ephemeral: true });
    },
  },
  {
    name: 'autorole',
    description: 'Manage roles assigned automatically when a member joins.',
    cooldown: 3,
    requiredPerms: ['ManageRoles'],
    options: [
      {
        name: 'action',
        description: 'What to do',
        type: STR,
        required: true,
        choices: [{ name: 'add', value: 'add' }, { name: 'remove', value: 'remove' }, { name: 'list', value: 'list' }],
      },
      { name: 'role', description: 'Role to add/remove', type: ROLE, required: false },
    ],
    async run(ctx, interaction, cmdCfg) {
      const action = interaction.options.getString('action', true);
      const role = interaction.options.getRole('role');
      const modCfg = await settings.getModuleConfig(interaction.guildId, 'welcome');
      const roles = Array.isArray(modCfg.settings.autoroleRoles) ? modCfg.settings.autoroleRoles : [];

      if (action === 'list') {
        return replySimple(interaction, roles.length ? `Autorole list:\n${roles.map((r) => `• <@&${r}>`).join('\n')}` : 'No autoroles configured. Add one with `/autorole add role:<role>`.', { ephemeral: true });
      }
      if (!role) return replyError(interaction, 'Pick a role with the `role` option.');
      if (action === 'add') {
        if (role.managed) return replyError(interaction, 'That role is managed by an integration and cannot be auto-assigned.');
        if (role.position >= interaction.guild.members.me.roles.highest.position) return replyError(interaction, 'That role is above my highest role — I could not assign it.');
        if (roles.includes(role.id)) return replyError(interaction, 'That role is already on the autorole list.');
        const next = await settings.setModuleSetting(interaction.guildId, 'welcome', 'autoroleRoles', [...roles, role.id]);
        await audit.log(interaction.guildId, interaction.user.id, 'config.autorole.add', 'module:welcome', null, next);
        return replySimple(interaction, `✅ New members now receive <@&${role.id}>.`, { ephemeral: true });
      }
      if (!roles.includes(role.id)) return replyError(interaction, 'That role is not on the autorole list.');
      const next = await settings.setModuleSetting(interaction.guildId, 'welcome', 'autoroleRoles', roles.filter((r) => r !== role.id));
      await audit.log(interaction.guildId, interaction.user.id, 'config.autorole.remove', 'module:welcome', null, next);
      return replySimple(interaction, `✅ <@&${role.id}> removed from the autorole list.`, { ephemeral: true });
    },
  },
];

module.exports = {
  key: 'welcome',
  name: 'Welcome & Goodbye',
  emoji: '👋',
  dashboardCommandName: 'welcome-dashboard',

  settingsSchema: [
    { key: 'welcomeChannel', label: 'Welcome channel', type: 'channel', desc: 'Where welcome messages are posted.' },
    { key: 'welcomeText', label: 'Welcome template', type: 'textarea', desc: 'Supports {user} {displayname} {server} {membercount} …' },
    { key: 'goodbyeChannel', label: 'Goodbye channel', type: 'channel', desc: 'Where goodbye messages are posted.' },
    { key: 'goodbyeText', label: 'Goodbye template', type: 'textarea', desc: 'Supports the same variables.' },
    { key: 'useEmbed', label: 'Use embed style', type: 'boolean', desc: 'Post welcome/goodbye as rich embeds with avatar.' },
    { key: 'dmWelcome', label: 'DM new members', type: 'boolean', desc: 'Send the DM template on join.' },
    { key: 'dmWelcomeText', label: 'DM template', type: 'textarea', desc: 'Direct message sent to new members.' },
    { key: 'welcomeDisabled', label: 'Welcome disabled', type: 'boolean', desc: 'Pause welcome messages without deleting config.' },
    { key: 'goodbyeDisabled', label: 'Goodbye disabled', type: 'boolean', desc: 'Pause goodbye messages without deleting config.' },
    { key: 'autoroleRoles', label: 'Autoroles', type: 'roles', desc: 'Assigned on join — also editable via /autorole.' },
  ],

  defaults: {
    enabled: true,
    settings: {
      welcomeChannel: null,
      welcomeText: '🎉 Welcome {user} to **{server}**! You are member **#{membercount}**.',
      goodbyeChannel: null,
      goodbyeText: '💔 **{displayname}** has left **{server}**. Member count: {membercount}.',
      useEmbed: true,
      dmWelcome: false,
      dmWelcomeText: 'Welcome to **{server}**, {displayname}! We are glad to have you.',
      welcomeDisabled: false,
      goodbyeDisabled: false,
      autoroleRoles: [],
      dashboardRoles: [],
    },
    commands: {
      welcome: { cooldown: 3, responses: {} },
      goodbye: { cooldown: 3, responses: {} },
      autorole: { cooldown: 3, responses: {} },
    },
  },

  commands,

  dashboard: {
    async summaryLines(guild, modCfg) {
      const s = modCfg.settings;
      return [
        ['Welcome channel', s.welcomeChannel ? `<#${s.welcomeChannel}>` : '*(not set)*'],
        ['Goodbye channel', s.goodbyeChannel ? `<#${s.goodbyeChannel}>` : '*(not set)*'],
        ['Autoroles', Array.isArray(s.autoroleRoles) && s.autoroleRoles.length ? `${s.autoroleRoles.length} role(s)` : '*(none)*'],
      ];
    },
    async extraOverviewButtons(guild, modCfg) {
      return [
        { label: 'Preview', emoji: '🖼️', style: 2, action: 'x:preview' },
        { label: modCfg.settings.welcomeDisabled ? 'Welcome: OFF' : 'Welcome: ON', style: modCfg.settings.welcomeDisabled ? 4 : 3, action: 'x:togglewelcome' },
      ];
    },
    async handle({ interaction, ctx, action, helpers }) {
      const modCfg = await settings.getModuleConfig(interaction.guildId, 'welcome');
      if (action === 'preview') {
        const payload = render(ctx, interaction.guild, interaction.member, 'welcome', modCfg);
        return helpers.edit(interaction, { content: 'Preview (with your data):', embeds: payload.embeds, components: (await require('../../core/dashboards').overviewView(ctx, 'welcome')).components });
      }
      if (action === 'togglewelcome') {
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const next = await settings.setModuleSetting(interaction.guildId, 'welcome', 'welcomeDisabled', !modCfg.settings.welcomeDisabled);
        await audit.log(interaction.guildId, interaction.user.id, 'config.welcome.toggle', 'module:welcome', before, next);
        return helpers.edit(interaction, await require('../../core/dashboards').overviewView(ctx, 'welcome'));
      }
    },
  },

  hooks: {
    async guildMemberAdd(ctx, member) {
      // Autoroles (skip bots if configured role-wise — simple: assign anyway)
      const modCfg = await settings.getModuleConfig(member.guild.id, 'welcome');
      if (modCfg.enabled && Array.isArray(modCfg.settings.autoroleRoles) && modCfg.settings.autoroleRoles.length) {
        const me = member.guild.members.me;
        for (const roleId of modCfg.settings.autoroleRoles) {
          const role = member.guild.roles.cache.get(roleId);
          if (!role || role.managed || role.position >= me.roles.highest.position) continue;
          // eslint-disable-next-line no-await-in-loop
          await member.roles.add(roleId, 'Autorole').catch(() => {});
        }
      }
      await sendKind(ctx, member.guild, member, 'welcome');
    },
    async guildMemberRemove(ctx, member) {
      await sendKind(ctx, member.guild, member, 'goodbye');
    },
  },
};
