'use strict';

const {
  ApplicationCommandOptionType,
  ChannelType,
  ActionRowBuilder,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} = require('discord.js');
const { respond } = require('../../core/responses');
const config = require('../../config');
const service = require('./service');

const CH = ApplicationCommandOptionType.Channel;
const INT = ApplicationCommandOptionType.Integer;
const STR = ApplicationCommandOptionType.String;

function buildModal(form) {
  const modal = new ModalBuilder().setCustomId(`cmm:form:${form.id}`).setTitle(`Form: ${form.title}`.slice(0, 45));
  form.questionsJson.forEach((question, i) => {
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId(`q${i}`)
          .setLabel(String(question).slice(0, 45))
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1000),
      ),
    );
  });
  return modal;
}

const command = {
  name: 'form',
  description: 'Build questionnaires that members submit through a popup form.',
  cooldown: 3,
  options: [
    {
      name: 'create',
      description: 'Create a form (Manage Server)',
      type: 1,
      options: [
        { name: 'title', description: 'Form title', type: STR, required: true, maxLength: 100 },
        { name: 'questions', description: '1-5 questions separated by |', type: STR, required: true, maxLength: 1500 },
        { name: 'review_channel', description: 'Where responses are posted', type: CH, required: false, channel_types: [ChannelType.GuildText] },
      ],
    },
    { name: 'list', description: 'List forms', type: 1, options: [] },
    {
      name: 'submit',
      description: 'Fill in a form',
      type: 1,
      options: [{ name: 'form_id', description: 'Form ID (see /form list)', type: INT, required: true, minValue: 1 }],
    },
    {
      name: 'review',
      description: 'Show the latest responses (staff)',
      type: 1,
      options: [{ name: 'form_id', description: 'Form ID to review', type: INT, required: true, minValue: 1 }],
    },
    {
      name: 'close',
      description: 'Close a form so it no longer accepts responses (Manage Server)',
      type: 1,
      options: [{ name: 'form_id', description: 'Form ID to close', type: INT, required: true, minValue: 1 }],
    },
  ],

  async run(ctx, interaction, cmdCfg) {
    const sub = interaction.options.getSubcommand(true);
    const guildId = interaction.guildId;

    if (sub === 'create') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to create forms.');
      const title = interaction.options.getString('title', true).trim();
      const questions = service.parseQuestions(interaction.options.getString('questions', true), 5);
      if (!questions) return ctx.responses.replyError(interaction, 'Provide between **1 and 5** questions separated by `|`.');
      const reviewChannel = interaction.options.getChannel('review_channel');
      const form = await ctx.db.form.create({
        data: {
          guildId,
          title,
          questionsJson: questions,
          reviewChannelId: reviewChannel?.id || null,
          createdById: interaction.user.id,
          open: true,
        },
      });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { form: title, formid: String(form.id), questions: String(questions.length) },
        `📝 Form **#${form.id} — ${title}** created with ${questions.length} question(s). Members submit it with \`/form submit form_id:${form.id}\`.`,
        { ephemeralDefault: true },
      );
    }

    if (sub === 'list') {
      const forms = await ctx.db.form.findMany({ where: { guildId }, orderBy: { id: 'desc' }, take: 25 });
      const lines = forms.map((f) => `• **#${f.id} — ${f.title}** ${f.open ? '🟢 open' : '🔴 closed'} — ${f.questionsJson.length} question(s)`);
      return respond(
        interaction,
        cmdCfg.responses.success,
        {},
        lines.length ? `${forms.length} form(s).` : 'No forms yet — create one with `/form create`.',
        {
          embeds: [
            new EmbedBuilder()
              .setColor(config.embedColor)
              .setTitle('📝 Forms')
              .setDescription(lines.join('\n').slice(0, 4000) || 'No forms yet — create one with `/form create`.'),
          ],
        },
      );
    }

    const formId = interaction.options.getInteger('form_id', true);
    const form = await ctx.db.form.findUnique({ where: { id: formId } });
    if (!form || form.guildId !== guildId) return ctx.responses.replyError(interaction, 'That form does not exist in this server.');

    if (sub === 'submit') {
      if (!form.open) return ctx.responses.replyError(interaction, 'That form is closed.');
      return interaction.showModal(buildModal(form));
    }

    if (sub === 'review') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to review responses.');
      const responses = await ctx.db.formResponse.findMany({ where: { formId: form.id, guildId }, orderBy: { id: 'desc' }, take: 10 });
      const lines = responses.map((r) => `• \`#${r.id}\` — <@${r.userId}> — **${r.status}** — <t:${service.unix(r.createdAt)}:R>`);
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(`📝 Responses — ${form.title}`.slice(0, 256))
        .setDescription(lines.join('\n').slice(0, 4000) || 'No responses yet.')
        .setFooter({ text: `${form.open ? 'Form is open' : 'Form is closed'} • latest 10 shown` });
      return respond(interaction, cmdCfg.responses.success, {}, `${responses.length} recent response(s).`, { embeds: [embed] });
    }

    // close
    if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to close forms.');
    if (!form.open) return ctx.responses.replyError(interaction, 'That form is already closed.');
    await ctx.db.form.update({ where: { id: form.id }, data: { open: false } });
    return respond(interaction, cmdCfg.responses.success, { form: form.title, formid: String(form.id) }, `🔴 Form **#${form.id} — ${form.title}** is closed.`, { ephemeralDefault: true });
  },
};

/** Modal handler for cmm:form:<formId> — rest is '<formId>'. */
async function handleFormModal(ctx, interaction, rest) {
  const formId = parseInt(String(rest).trim(), 10);
  const form = Number.isFinite(formId) ? await ctx.db.form.findUnique({ where: { id: formId } }) : null;
  if (!form || form.guildId !== interaction.guildId) return ctx.responses.replyError(interaction, 'That form no longer exists.');
  if (!form.open) return ctx.responses.replyError(interaction, 'That form is closed.');

  const answers = form.questionsJson.map((question, i) => {
    let value = '';
    try {
      value = interaction.fields.getTextInputValue(`q${i}`) || '';
    } catch {
      value = '';
    }
    return { question, answer: value.slice(0, 1000) };
  });

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const created = await ctx.db.formResponse.create({
    data: { guildId: interaction.guildId, formId: form.id, userId: interaction.user.id, answersJson: JSON.stringify(answers), status: 'pending' },
  });

  if (form.reviewChannelId) {
    const channel = service.resolveChannel(interaction.guild, form.reviewChannelId);
    if (service.isTextChannel(channel)) {
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(`📥 Form response — ${form.title}`.slice(0, 256))
        .setDescription(
          answers.map((a, i) => `**${i + 1}. ${String(a.question).slice(0, 200)}**\n${a.answer || '*empty*'}`).join('\n\n').slice(0, 4000) || '*empty*',
        )
        .addFields(
          { name: 'Respondent', value: `<@${interaction.user.id}>`, inline: true },
          { name: 'Response', value: `#${created.id}`, inline: true },
        )
        .setTimestamp();
      await channel.send({ embeds: [embed] }).catch(() => {});
    }
  }

  const cmdCfg = await ctx.settings.getCommandConfig(interaction.guildId, service.MODULE_KEY, 'form');
  return respond(interaction, cmdCfg.responses?.success, { form: form.title, formid: String(form.id) }, '✅ Response submitted — thank you!', { ephemeralDefault: true });
}

module.exports = { command, handleFormModal };
