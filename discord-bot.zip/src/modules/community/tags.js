'use strict';

const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const { respond } = require('../../core/responses');
const config = require('../../config');
const placeholders = require('../../core/placeholders');
const service = require('./service');

const STR = ApplicationCommandOptionType.String;

function normalizeName(raw) {
  return String(raw || '').trim();
}

async function findTag(ctx, guildId, name) {
  const query = normalizeName(name).toLowerCase();
  const tags = await ctx.db.tag.findMany({ where: { guildId } });
  return tags.find((t) => t.name.toLowerCase() === query) || null;
}

const command = {
  name: 'tag',
  description: 'Server tags — reusable snippets with {placeholders} and | random pools.',
  cooldown: 2,
  options: [
    {
      name: 'create',
      description: 'Create a tag',
      type: 1,
      options: [
        { name: 'name', description: 'Tag name', type: STR, required: true, maxLength: 32 },
        { name: 'content', description: 'Tag content ({variables} allowed, | separates random pool)', type: STR, required: true, maxLength: 1800 },
      ],
    },
    {
      name: 'edit',
      description: 'Edit a tag you created (or with Manage Server)',
      type: 1,
      options: [
        { name: 'name', description: 'Tag name', type: STR, required: true, maxLength: 32 },
        { name: 'content', description: 'New content', type: STR, required: true, maxLength: 1800 },
      ],
    },
    {
      name: 'delete',
      description: 'Delete a tag you created (or with Manage Server)',
      type: 1,
      options: [{ name: 'name', description: 'Tag name', type: STR, required: true, maxLength: 32 }],
    },
    { name: 'list', description: 'List tags', type: 1, options: [] },
    {
      name: 'show',
      description: 'Show a tag',
      type: 1,
      options: [{ name: 'name', description: 'Tag name', type: STR, required: true, maxLength: 32 }],
    },
  ],

  async run(ctx, interaction, cmdCfg) {
    const sub = interaction.options.getSubcommand(true);
    const guildId = interaction.guildId;

    if (sub === 'create') {
      const name = normalizeName(interaction.options.getString('name', true));
      if (name.length < 1) return ctx.responses.replyError(interaction, 'Give the tag a name.');
      const content = interaction.options.getString('content', true);
      const existing = await ctx.db.tag.findUnique({ where: { guildId_name: { guildId, name } } });
      if (existing) return ctx.responses.replyError(interaction, `A tag named **${name}** already exists.`);
      const tag = await ctx.db.tag.create({ data: { guildId, name, content, createdById: interaction.user.id, uses: 0 } });
      return respond(interaction, cmdCfg.responses.success, { name: tag.name }, `🏷️ Tag **${tag.name}** created — show it with \`/tag show name:${tag.name}\`.`);
    }

    if (sub === 'edit' || sub === 'delete') {
      const name = normalizeName(interaction.options.getString('name', true));
      const tag = await findTag(ctx, guildId, name);
      if (!tag) return ctx.responses.replyError(interaction, `No tag named **${name}** found.`);
      if (tag.createdById !== interaction.user.id && !service.isStaff(interaction.member, [])) {
        return ctx.responses.replyError(interaction, 'Only the tag creator (or staff) can do that.');
      }
      if (sub === 'delete') {
        await ctx.db.tag.delete({ where: { id: tag.id } });
        return respond(interaction, cmdCfg.responses.success, { name: tag.name }, `🗑️ Tag **${tag.name}** deleted.`);
      }
      const content = interaction.options.getString('content', true);
      await ctx.db.tag.update({ where: { id: tag.id }, data: { content } });
      return respond(interaction, cmdCfg.responses.success, { name: tag.name }, `✏️ Tag **${tag.name}** updated.`);
    }

    if (sub === 'list') {
      const tags = await ctx.db.tag.findMany({ where: { guildId }, orderBy: { uses: 'desc' }, take: 50 });
      const lines = tags.slice(0, 30).map((t) => `• **${t.name}** — ${t.uses} use(s)`);
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle('🏷️ Tags')
        .setDescription(lines.join('\n').slice(0, 4000) || 'No tags yet — create one with `/tag create`.')
        .setFooter({ text: `${tags.length} tag(s)` });
      return respond(interaction, cmdCfg.responses.success, {}, `${tags.length} tag(s).`, { embeds: [embed] });
    }

    // show
    const name = normalizeName(interaction.options.getString('name', true));
    const tag = await findTag(ctx, guildId, name);
    if (!tag) return ctx.responses.replyError(interaction, `No tag named **${name}** found.`);
    await ctx.db.tag.update({ where: { id: tag.id }, data: { uses: { increment: 1 } } }).catch(() => {});
    const picked = service.pickRandom(tag.content);
    const filled = placeholders.fill(picked, {
      user: interaction.user,
      member: interaction.member,
      guild: interaction.guild,
      channel: interaction.channel,
      extra: { name: tag.name },
    });
    return respond(interaction, cmdCfg.responses.success, { name: tag.name, content: filled }, filled.slice(0, 2000));
  },
};

module.exports = { command };
