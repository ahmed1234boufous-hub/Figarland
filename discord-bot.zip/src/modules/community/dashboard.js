'use strict';

const db = require('../../core/db');

/**
 * dashboard.js — summary lines for the community module's /community-dashboard overview.
 */

module.exports = {
  async summaryLines(guild, modCfg) {
    const [birthdays, tags, openThreads, lounges] = await Promise.all([
      db.birthday.count({ where: { guildId: guild.id } }),
      db.tag.count({ where: { guildId: guild.id } }),
      db.modMailThread.count({ where: { guildId: guild.id, status: 'open' } }),
      db.tempVoice.count({ where: { guildId: guild.id } }),
    ]);
    const state = await db.countingState.findFirst({ where: { guildId: guild.id } });
    return [
      ['Birthdays / Tags', `${birthdays} saved / ${tags} tags`],
      ['Counting', state ? `current **${state.current}** • best **${state.best}** • fails **${state.fails}**` : '*(not set — /count set)*'],
      ['Modmail / Temp voices', `${openThreads} open thread(s) / ${lounges} lounge(s) active`],
    ];
  },
};
