'use strict';

const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const { respond } = require('../../core/responses');
const config = require('../../config');
const service = require('./service');

const USER = ApplicationCommandOptionType.User;

const CAVEAT = 'Invite attribution is approximate — vanity URLs and paused invites may not be tracked.';

async function bump(ctx, guildId, userId, field) {
  await ctx.db.inviteStat.upsert({
    where: { guildId_userId: { guildId, userId } },
    create: { guildId, userId, [field]: 1 },
    update: { [field]: { increment: 1 } },
  });
}

async function refreshCache(ctx, guild, invites) {
  if (!ctx.inviteCache) ctx.inviteCache = new Map();
  if (invites) ctx.inviteCache.set(guild.id, new Map(invites.map((i) => [i.code, i.uses || 0])));
  else ctx.inviteCache.delete(guild.id);
}

/** Hook: attribute the join to the invite that gained a use, then refresh ctx.inviteCache. */
async function onMemberAdd(ctx, member) {
  const guild = member.guild;
  if (!guild) return;
  const cfg = await service.getCfg(ctx, guild.id);
  if (!cfg.enabled) return;

  const cached = ctx.inviteCache ? ctx.inviteCache.get(guild.id) : null;
  let fresh = null;
  try {
    fresh = await guild.invites.fetch();
  } catch {
    fresh = null; // missing ManageGuild — attribution unavailable, keep the old cache
  }

  let inviterId = null;
  if (fresh && cached) {
    for (const inv of fresh.values()) {
      const before = cached.get(inv.code);
      if (before !== undefined && (inv.uses || 0) > before) {
        inviterId = inv.inviter?.id || null;
        break;
      }
    }
  }
  if (!inviterId) {
    // Unknown code or vanity URL — usage cannot be attributed to a member.
    await guild.fetchVanityData().catch(() => {});
  }

  await refreshCache(ctx, guild, fresh);

  if (!member.user?.bot && inviterId && inviterId !== member.id) {
    await bump(ctx, guild.id, inviterId, 'regular').catch(() => {});
  }
}

/** Hook: count departures — joins shorter than 10 minutes count as fake invites. */
async function onMemberRemove(ctx, member) {
  if (!member.guild || member.user?.bot) return;
  const cfg = await service.getCfg(ctx, member.guild.id);
  if (!cfg.enabled) return;
  const joined = member.joinedTimestamp;
  const field = joined && Date.now() - joined < 10 * 60 * 1000 ? 'fake' : 'left';
  await bump(ctx, member.guild.id, member.id, field).catch(() => {});
}

const command = {
  name: 'invites',
  description: 'Track who invited whom and show an invite leaderboard.',
  cooldown: 3,
  options: [
    {
      name: 'show',
      description: 'Show a member invite stats (default: yours)',
      type: 1,
      options: [{ name: 'user', description: 'Member to look up', type: USER, required: false }],
    },
    { name: 'leaderboard', description: 'Top 10 inviters of this server', type: 1, options: [] },
  ],

  async run(ctx, interaction, cmdCfg) {
    const sub = interaction.options.getSubcommand(true);
    const guildId = interaction.guildId;

    if (sub === 'show') {
      const user = interaction.options.getUser('user') || interaction.user;
      const row = await ctx.db.inviteStat.findUnique({ where: { guildId_userId: { guildId, userId: user.id } } });
      const regular = row?.regular || 0;
      const bonus = row?.bonus || 0;
      const fake = row?.fake || 0;
      const left = row?.left || 0;
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(`📨 Invites — ${user.username}`.slice(0, 256))
        .setDescription(`<@${user.id}> has **${regular + bonus}** tracked invite(s).`)
        .addFields(
          { name: 'Regular', value: `${regular}`, inline: true },
          { name: 'Bonus', value: `${bonus}`, inline: true },
          { name: 'Left server', value: `${left}`, inline: true },
          { name: 'Fake (fast re-leave)', value: `${fake}`, inline: true },
        )
        .setFooter({ text: CAVEAT });
      return respond(interaction, cmdCfg.responses.success, {}, `📨 <@${user.id}> — ${regular + bonus} invite(s).`, { embeds: [embed] });
    }

    // leaderboard
    const rows = await ctx.db.inviteStat.findMany({ where: { guildId } });
    rows.sort((a, b) => b.regular + b.bonus - (a.regular + a.bonus));
    const medals = ['🥇', '🥈', '🥉'];
    const top = rows.filter((r) => r.regular + r.bonus > 0).slice(0, 10);
    const lines = top.map((r, i) => `${medals[i] || '🎖️'} **${i + 1}.** <@${r.userId}> — **${r.regular + r.bonus}** invite(s)`);
    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle('📨 Invite leaderboard — top 10')
      .setDescription(lines.length ? lines.join('\n') : 'No tracked invites yet — stats build up as members join.')
      .setFooter({ text: CAVEAT });
    return respond(interaction, cmdCfg.responses.success, {}, top.length ? `${top.length} entr(ies).` : 'No tracked invites yet.', { embeds: [embed] });
  },
};

module.exports = { command, onMemberAdd, onMemberRemove, CAVEAT };
