'use strict';

const { ApplicationCommandOptionType, ChannelType, EmbedBuilder } = require('discord.js');
const { respond } = require('../../core/responses');
const config = require('../../config');
const service = require('./service');

const INT = ApplicationCommandOptionType.Integer;
const USER = ApplicationCommandOptionType.User;

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

function nextOccurrence(month, day) {
  const now = new Date();
  const year = now.getUTCFullYear();
  let dt = new Date(Date.UTC(year, month - 1, day));
  if (dt.getTime() < Date.UTC(year, now.getUTCMonth(), now.getUTCDate())) {
    dt = new Date(Date.UTC(year + 1, month - 1, day));
  }
  return dt;
}

const command = {
  name: 'birthday',
  description: 'Save your birthday and get a celebration post once a year.',
  cooldown: 3,
  options: [
    {
      name: 'set',
      description: 'Save your birthday (month + day)',
      type: 1,
      options: [
        { name: 'month', description: 'Month (1-12)', type: INT, required: true, minValue: 1, maxValue: 12 },
        { name: 'day', description: 'Day of month (1-31)', type: INT, required: true, minValue: 1, maxValue: 31 },
      ],
    },
    {
      name: 'show',
      description: 'Show a member birthday (default: yours)',
      type: 1,
      options: [{ name: 'user', description: 'Member to look up', type: USER, required: false }],
    },
    { name: 'list', description: 'List all known birthdays', type: 1, options: [] },
  ],

  async run(ctx, interaction, cmdCfg) {
    const sub = interaction.options.getSubcommand(true);
    const guildId = interaction.guildId;

    if (sub === 'set') {
      const month = interaction.options.getInteger('month', true);
      const day = interaction.options.getInteger('day', true);
      if (!service.validBirthday(month, day)) {
        return ctx.responses.replyError(interaction, `**${day} ${MONTHS[month - 1]}** is not a real calendar date.`);
      }
      await ctx.db.birthday.upsert({
        where: { guildId_userId: { guildId, userId: interaction.user.id } },
        create: { guildId, userId: interaction.user.id, month, day },
        update: { month, day },
      });
      const when = nextOccurrence(month, day);
      return respond(
        interaction,
        cmdCfg.responses.success,
        { month: MONTHS[month - 1], day: String(day), date: `<t:${service.unix(when)}:D>` },
        `🎂 Birthday saved: **${day} ${MONTHS[month - 1]}** — next celebration <t:${service.unix(when)}:D>.`,
      );
    }

    if (sub === 'show') {
      const user = interaction.options.getUser('user') || interaction.user;
      const row = await ctx.db.birthday.findUnique({ where: { guildId_userId: { guildId, userId: user.id } } });
      if (!row) {
        return ctx.responses.replyError(
          interaction,
          user.id === interaction.user.id
            ? 'You have no birthday on file — set one with `/birthday set`.'
            : `<@${user.id}> has no birthday on file.`,
        );
      }
      const when = nextOccurrence(row.month, row.day);
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(`🎂 Birthday — ${user.username}`.slice(0, 256))
        .setDescription(`**${row.day} ${MONTHS[row.month - 1]}** — next occurrence <t:${service.unix(when)}:D> (<t:${service.unix(when)}:R>).`)
        .setThumbnail(user.displayAvatarURL({ size: 256, extension: 'png' }));
      return respond(interaction, cmdCfg.responses.success, { day: String(row.day), month: MONTHS[row.month - 1] }, `🎂 **${row.day} ${MONTHS[row.month - 1]}**.`, { embeds: [embed] });
    }

    // list
    const rows = await ctx.db.birthday.findMany({ where: { guildId } });
    rows.sort((a, b) => a.month - b.month || a.day - b.day);
    const lines = rows.slice(0, 25).map((r) => `• **${r.day} ${MONTHS[r.month - 1]}** — <@${r.userId}> (<t:${service.unix(nextOccurrence(r.month, r.day))}:D>)`);
    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle('🎂 Birthdays')
      .setDescription(lines.length ? lines.join('\n').slice(0, 4000) : 'No birthdays saved yet — add yours with `/birthday set`.')
      .setFooter({ text: `${rows.length} birthday(s) on file` });
    return respond(interaction, cmdCfg.responses.success, {}, `${rows.length} birthday(s) on file.`, { embeds: [embed] });
  },
};

/**
 * Scheduler job body — runs hourly, posts at most once per UTC day per guild.
 * Guarded by ModuleConfig settings.lastBirthdayRun ('YYYY-MM-DD').
 */
async function runDaily(ctx) {
  const now = new Date();
  const today = now.toISOString().slice(0, 10);
  const month = now.getUTCMonth() + 1;
  const day = now.getUTCDate();

  for (const guild of ctx.client.guilds.cache.values()) {
    try {
      const cfg = await service.getCfg(ctx, guild.id);
      if (!cfg.enabled) continue;
      if (cfg.settings.lastBirthdayRun === today) continue;
      // Mark first so a crashed send never loops hourly all day.
      await ctx.settings.setModuleSetting(guild.id, service.MODULE_KEY, 'lastBirthdayRun', today);

      const rows = await ctx.db.birthday.findMany({ where: { guildId: guild.id, month, day } });
      if (!rows.length) continue;
      const channel = service.resolveChannel(guild, cfg.settings.birthdayChannel);
      if (!channel || !service.isTextChannel(channel)) continue;

      const mentions = rows.map((r) => `<@${r.userId}>`).join(' ').slice(0, 1500);
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle('🎉 Happy Birthday!')
        .setDescription(`Join us in wishing a happy birthday to:\n${mentions}`)
        .setTimestamp();
      await channel.send({ content: `${mentions} 🎂`, embeds: [embed] });
    } catch (err) {
      ctx.logger.warn(`[community:birthdays] ${guild.id}: ${err?.message || err}`);
    }
  }
}

module.exports = { command, runDaily };
