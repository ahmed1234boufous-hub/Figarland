'use strict';

const { ApplicationCommandOptionType, ChannelType, PermissionFlagsBits } = require('discord.js');
const { respond } = require('../../core/responses');
const service = require('./service');

const CH = ApplicationCommandOptionType.Channel;
const INT = ApplicationCommandOptionType.Integer;
const STR = ApplicationCommandOptionType.String;

const OWNER_PERMS = [PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MuteMembers, PermissionFlagsBits.DeafenMembers];

async function findLoungeFor(ctx, interaction) {
  const voiceId = interaction.member?.voice?.channelId;
  if (!voiceId) return null;
  return ctx.db.tempVoice.findUnique({ where: { channelId: voiceId } });
}

const command = {
  name: 'voice',
  description: 'Temp voice lounges — join the creator channel to get your own channel.',
  cooldown: 3,
  options: [
    {
      name: 'setup',
      description: 'Set the join-to-create channel (Manage Server)',
      type: 1,
      options: [
        { name: 'channel', description: 'Voice channel users join to create a lounge', type: CH, required: true, channel_types: [ChannelType.GuildVoice] },
        { name: 'category', description: 'Optional category for created lounges', type: CH, required: false, channel_types: [ChannelType.GuildCategory] },
      ],
    },
    { name: 'lock', description: 'Lock your lounge so nobody can connect', type: 1, options: [] },
    { name: 'unlock', description: 'Unlock your lounge', type: 1, options: [] },
    {
      name: 'limit',
      description: 'Set a user limit for your lounge',
      type: 1,
      options: [{ name: 'number', description: 'Maximum users (1-99, 0 = unlimited)', type: INT, required: true, minValue: 0, maxValue: 99 }],
    },
    {
      name: 'rename',
      description: 'Rename your lounge',
      type: 1,
      options: [{ name: 'name', description: 'New channel name', type: STR, required: true, maxLength: 90 }],
    },
    { name: 'claim', description: 'Take ownership of this lounge if the owner left', type: 1, options: [] },
  ],

  async run(ctx, interaction, cmdCfg) {
    const sub = interaction.options.getSubcommand(true);
    const guild = interaction.guild;
    const guildId = interaction.guildId;

    if (sub === 'setup') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to configure temp voices.');
      const channel = interaction.options.getChannel('channel', true);
      if (channel.type !== ChannelType.GuildVoice) return ctx.responses.replyError(interaction, 'Pick a voice channel.');
      const category = interaction.options.getChannel('category');
      const cfg = await service.getCfg(ctx, guildId);
      await service.setSettingAndAudit(ctx, guildId, interaction.user.id, 'config.community.creatorChannel', 'creatorChannelId', channel.id, cfg);
      if (category) await service.setSettingAndAudit(ctx, guildId, interaction.user.id, 'config.community.voiceCategory', 'voiceCategory', category.id, null);
      return respond(
        interaction,
        cmdCfg.responses.success,
        { channel: `<#${channel.id}>`, category: category ? `<#${category.id}>` : 'same as the creator channel' },
        `🔊 Join-to-create set to <#${channel.id}>${category ? ` (lounges go into <#${category.id}>)` : ''}.`,
        { ephemeralDefault: true },
      );
    }

    // All remaining subcommands operate on the lounge the user is connected to.
    const row = await findLoungeFor(ctx, interaction);
    if (!row || row.guildId !== guildId) {
      return ctx.responses.replyError(interaction, 'Join one of my temp voice lounges first, then use this command.');
    }
    const channel = guild.channels.cache.get(row.channelId);
    if (!channel) {
      await ctx.db.tempVoice.deleteMany({ where: { channelId: row.channelId } }).catch(() => {});
      return ctx.responses.replyError(interaction, 'That lounge no longer exists.');
    }
    const isOwner = row.ownerId === interaction.user.id;
    const cfg = await service.getCfg(ctx, guildId);

    if (sub === 'claim') {
      if (isOwner) return ctx.responses.replyError(interaction, 'You already own this lounge.');
      if (channel.members.has(row.ownerId)) return ctx.responses.replyError(interaction, 'The lounge owner is still connected — ownership cannot be claimed.');
      await ctx.db.tempVoice.update({ where: { channelId: channel.id }, data: { ownerId: interaction.user.id } });
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>` }, `👑 You now own <#${channel.id}>.`, { ephemeralDefault: true });
    }

    if (!isOwner && !service.isStaff(interaction.member, cfg.settings.reviewRoleIds)) {
      return ctx.responses.replyError(interaction, 'Only the lounge owner (or staff) can do that.');
    }
    if (!service.botHas(guild, 'ManageChannels')) return ctx.responses.replyError(interaction, 'I need the **Manage Channels** permission for that.');

    if (sub === 'lock') {
      await channel.permissionOverwrites.edit(guild.roles.everyone, { Connect: false }).catch(() => {});
      await ctx.db.tempVoice.update({ where: { channelId: channel.id }, data: { locked: true } });
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>` }, `🔒 <#${channel.id}> is locked — nobody new can connect.`, { ephemeralDefault: true });
    }

    if (sub === 'unlock') {
      await channel.permissionOverwrites.edit(guild.roles.everyone, { Connect: null }).catch(() => {});
      await ctx.db.tempVoice.update({ where: { channelId: channel.id }, data: { locked: false } });
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>` }, `🔓 <#${channel.id}> is open again.`, { ephemeralDefault: true });
    }

    if (sub === 'limit') {
      const num = interaction.options.getInteger('number', true);
      const ok = await channel.setUserLimit(num).then(() => true).catch(() => false);
      if (!ok) return ctx.responses.replyError(interaction, 'Discord refused the limit change — check my permissions and try again.');
      return respond(interaction, cmdCfg.responses.success, { amount: String(num), channel: `<#${channel.id}>` }, num === 0 ? `♾️ User limit removed from <#${channel.id}>.` : `👥 <#${channel.id}> is limited to **${num}** user(s).`, { ephemeralDefault: true });
    }

    // rename
    const name = interaction.options.getString('name', true).trim().slice(0, 90);
    if (!name) return ctx.responses.replyError(interaction, 'Give the lounge a name.');
    const renamed = await channel.setName(name).then(() => true).catch(() => false);
    if (!renamed) return ctx.responses.replyError(interaction, 'Discord rate-limits renames — try again in a few minutes.');
    return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>`, name }, `✏️ Lounge renamed to **${name}**.`, { ephemeralDefault: true });
  },
};

async function spawnLounge(ctx, state, cfg) {
  const guild = state.guild;
  const creator = guild.channels.cache.get(cfg.settings.creatorChannelId);
  if (!creator) return;
  const parent = cfg.settings.voiceCategory || creator.parentId || undefined;
  const channel = await guild.channels.create({
    name: `${state.member.displayName}'s lounge`.slice(0, 100),
    type: ChannelType.GuildVoice,
    parent,
    userLimit: 0,
    permissionOverwrites: [{ id: state.member.id, allow: OWNER_PERMS }],
  });
  await ctx.db.tempVoice.create({ data: { guildId: guild.id, channelId: channel.id, ownerId: state.member.id, locked: false } });
  await state.member.voice.setChannel(channel).catch(async () => {
    await ctx.db.tempVoice.deleteMany({ where: { channelId: channel.id } }).catch(() => {});
    await channel.delete('Could not move the member').catch(() => {});
  });
}

async function handleLeave(ctx, oldState) {
  const row = await ctx.db.tempVoice.findUnique({ where: { channelId: oldState.channelId } });
  if (!row) return;
  const channel = oldState.guild.channels.cache.get(oldState.channelId);
  if (!channel) {
    await ctx.db.tempVoice.deleteMany({ where: { channelId: oldState.channelId } }).catch(() => {});
    return;
  }
  const remaining = channel.members.filter((m) => m.id !== oldState.id);
  if (remaining.size === 0) {
    await ctx.db.tempVoice.deleteMany({ where: { channelId: channel.id } }).catch(() => {});
    await channel.delete('Temp voice lounge empty').catch(() => {});
    return;
  }
  if (row.ownerId === oldState.id) {
    const next = remaining.first();
    if (next) await ctx.db.tempVoice.update({ where: { channelId: channel.id }, data: { ownerId: next.id } }).catch(() => {});
  }
}

/** Hook body — one DB read per voice update, two branches. */
async function onVoiceState(ctx, oldState, newState) {
  const guild = newState?.guild || oldState?.guild;
  if (!guild) return;
  const cfg = await service.getCfg(ctx, guild.id);
  if (!cfg.enabled) return;

  if (newState.channelId && newState.channelId === cfg.settings.creatorChannelId && newState.member && !newState.member.user?.bot) {
    await spawnLounge(ctx, newState, cfg).catch((err) => ctx.logger.warn(`[community:voice] spawn: ${err?.message || err}`));
  }

  if (oldState.channelId && oldState.channelId !== newState.channelId) {
    await handleLeave(ctx, oldState).catch((err) => ctx.logger.warn(`[community:voice] leave: ${err?.message || err}`));
  }
}

module.exports = { command, onVoiceState };
