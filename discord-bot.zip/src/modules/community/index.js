'use strict';

const { commands } = require('./commands');
const dashboard = require('./dashboard');
const service = require('./service');
const birthday = require('./birthday');
const invites = require('./invites');
const counting = require('./counting');
const sticky = require('./sticky');
const tempvoice = require('./tempvoice');
const forms = require('./forms');
const applications = require('./applications');
const events = require('./events');
const modmail = require('./modmail');
const components = require('./components');

/**
 * community — Community Extras module.
 *
 * Features: birthdays, invite tracking, counting game, stickies, temp voice
 * lounges, forms, applications, events with RSVP, modmail and tags.
 * Commands: /birthday /invites /count /sticky /voice /form /application
 *           /event /modmail /tag
 */

module.exports = {
  key: 'community',
  name: 'Community Extras',
  emoji: '🎪',
  dashboardCommandName: 'community-dashboard',

  settingsSchema: [
    { key: 'birthdayChannel', label: 'Birthday channel', type: 'channel', desc: 'Where daily birthday celebrations are posted (/birthday).' },
    { key: 'countingChannel', label: 'Counting channel', type: 'channel', desc: 'Managed by /count set — shown here for convenience.' },
    { key: 'countingKeepOnFail', label: 'Counting: keep on fail', type: 'boolean', desc: 'Keep the current number when the count breaks instead of resetting to 0.' },
    { key: 'creatorChannelId', label: 'Temp voice: join-to-create', type: 'channel', desc: 'Voice channel that spawns personal lounges (/voice setup).' },
    { key: 'voiceCategory', label: 'Temp voice: category', type: 'channel', desc: 'Category for new lounges — defaults to the creator channel’s category.' },
    { key: 'eventsChannel', label: 'Events channel', type: 'channel', desc: 'Where event announcements are posted (default: the channel the command is used in).' },
    { key: 'reviewRoleIds', label: 'Application review roles', type: 'roles', desc: 'Roles that can accept/deny applications (Manage Server always can).' },
    { key: 'modmailStaffRoles', label: 'Modmail staff roles', type: 'roles', desc: 'Roles that can read and answer modmail threads — set via /modmail setup.' },
    { key: 'modmailCategoryId', label: 'Modmail category', type: 'channel', desc: 'Category for modmail threads. The picker lists text channels only — use /modmail setup to select a category.' },
    { key: 'modmailLogChannelId', label: 'Modmail log channel', type: 'channel', desc: 'Closed-thread transcripts are posted here (/modmail setup).' },
  ],

  defaults: {
    enabled: true,
    settings: {
      birthdayChannel: null,
      lastBirthdayRun: null,
      countingChannel: null,
      countingKeepOnFail: false,
      creatorChannelId: null,
      voiceCategory: null,
      eventsChannel: null,
      reviewRoleIds: [],
      modmailStaffRoles: [],
      modmailCategoryId: null,
      modmailLogChannelId: null,
    },
    commands: {
      birthday: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      invites: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      count: { cooldown: 2, responses: { success: { text: '', ephemeral: false } } },
      sticky: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      voice: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      form: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      application: { cooldown: 5, responses: { success: { text: '', ephemeral: false } } },
      event: { cooldown: 5, responses: { success: { text: '', ephemeral: false } } },
      modmail: { cooldown: 5, responses: { success: { text: '', ephemeral: false } } },
      tag: { cooldown: 2, responses: { success: { text: '', ephemeral: false } } },
    },
  },

  commands,

  dashboard,

  componentHandlers: { 'cm:': components.handleComponent },
  modalHandlers: { 'cmm:': components.handleModal },

  hooks: {
    async messageCreate(ctx, message) {
      try {
        if (!message || !message.author || message.author.bot) return;
        if (message.guild === null) return modmail.onDmMessage(ctx, message);
        const cfg = await service.getCfg(ctx, message.guild.id);
        if (!cfg.enabled) return;
        await counting.onGuildMessage(ctx, message, cfg);
        await sticky.onGuildMessage(ctx, message, cfg);
      } catch (err) {
        ctx.logger?.warn?.(`[community:messageCreate] ${err?.message || err}`);
      }
    },

    async guildMemberAdd(ctx, member) {
      try {
        await invites.onMemberAdd(ctx, member);
      } catch (err) {
        ctx.logger?.warn?.(`[community:guildMemberAdd] ${err?.message || err}`);
      }
    },

    async guildMemberRemove(ctx, member) {
      try {
        await invites.onMemberRemove(ctx, member);
      } catch (err) {
        ctx.logger?.warn?.(`[community:guildMemberRemove] ${err?.message || err}`);
      }
    },

    async voiceStateUpdate(ctx, oldState, newState) {
      try {
        await tempvoice.onVoiceState(ctx, oldState, newState);
      } catch (err) {
        ctx.logger?.warn?.(`[community:voiceStateUpdate] ${err?.message || err}`);
      }
    },

    async channelDelete(ctx, channel) {
      try {
        if (!channel?.id) return;
        await ctx.db.countingState.deleteMany({ where: { channelId: channel.id } });
        if (channel.guild) await ctx.db.sticky.deleteMany({ where: { guildId: channel.guild.id, channelId: channel.id } });
        await ctx.db.tempVoice.deleteMany({ where: { channelId: channel.id } });
      } catch (err) {
        ctx.logger?.warn?.(`[community:channelDelete] ${err?.message || err}`);
      }
    },
  },

  schedulerJobs: [
    { name: 'birthdays-daily', intervalMs: 3600000, run: (ctx) => birthday.runDaily(ctx) },
    { name: 'events-remind', intervalMs: 600000, run: (ctx) => events.runReminders(ctx) },
  ],
};
