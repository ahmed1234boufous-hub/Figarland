'use strict';

/**
 * commands.js — aggregates the community module's 10 slash commands.
 */

const birthday = require('./birthday');
const invites = require('./invites');
const counting = require('./counting');
const sticky = require('./sticky');
const tempvoice = require('./tempvoice');
const forms = require('./forms');
const applications = require('./applications');
const events = require('./events');
const modmail = require('./modmail');
const tags = require('./tags');

const commands = [
  birthday.command,
  invites.command,
  counting.command,
  sticky.command,
  tempvoice.command,
  forms.command,
  applications.command,
  events.command,
  modmail.command,
  tags.command,
];

module.exports = { commands };
