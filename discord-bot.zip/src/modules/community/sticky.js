'use strict';

const { ApplicationCommandOptionType, ChannelType, EmbedBuilder } = require('discord.js');
const { respond } = require('../../core/responses');
const config = require('../../config');
const placeholders = require('../../core/placeholders');
const service = require('./service');

const CH = ApplicationCommandOptionType.Channel;
const STR = ApplicationCommandOptionType.String;

// guildId → { at, rows } — 10s cache so messageCreate stays cheap
const listCache = new Map();
// stickyId → timestamp of the last repost
const lastRepost = new Map();

async function getStickies(ctx, guildId) {
  const hit = listCache.get(guildId);
  if (hit && Date.now() - hit.at < 10000) return hit.rows;
  const rows = await ctx.db.sticky.findMany({ where: { guildId } });
  listCache.set(guildId, { at: Date.now(), rows });
  return rows;
}

function bustCache(guildId) {
  listCache.delete(guildId);
}

function contentOf(ctx, row) {
  return String((ctx.settings.parse(row.contentJson, {}) || {}).text || '');
}

async function deletePosted(channel, messageId) {
  if (!messageId) return;
  await channel.messages.delete(messageId).catch(() => {});
}

/** Send the sticky content (placeholders filled with the triggering member) and remember the message. */
async function repost(ctx, channel, row, member) {
  const template = contentOf(ctx, row);
  if (!template) return null;
  const content = placeholders
    .fill(template, { user: member?.user || null, member: member || null, guild: channel.guild, channel })
    .slice(0, 2000);
  const sent = await channel.send({ content }).catch(() => null);
  lastRepost.set(row.id, Date.now());
  if (sent) await ctx.db.sticky.update({ where: { id: row.id }, data: { lastMessageId: sent.id } }).catch(() => {});
  return sent;
}

const command = {
  name: 'sticky',
  description: 'Pin a repeating notice to the bottom of a channel.',
  cooldown: 3,
  options: [
    {
      name: 'create',
      description: 'Create a sticky in a channel (Manage Server)',
      type: 1,
      options: [
        { name: 'channel', description: 'Target text channel', type: CH, required: true, channel_types: [ChannelType.GuildText] },
        { name: 'text', description: 'Sticky text ({variables} allowed)', type: STR, required: true, maxLength: 1500 },
      ],
    },
    {
      name: 'edit',
      description: 'Edit a sticky (Manage Server)',
      type: 1,
      options: [
        { name: 'text', description: 'New sticky text', type: STR, required: true, maxLength: 1500 },
        { name: 'channel', description: 'Channel whose sticky to edit', type: CH, required: true, channel_types: [ChannelType.GuildText] },
      ],
    },
    {
      name: 'delete',
      description: 'Remove a sticky (Manage Server)',
      type: 1,
      options: [{ name: 'channel', description: 'Channel whose sticky to remove', type: CH, required: true, channel_types: [ChannelType.GuildText] }],
    },
    { name: 'list', description: 'List all stickies', type: 1, options: [] },
  ],

  async run(ctx, interaction, cmdCfg) {
    const sub = interaction.options.getSubcommand(true);
    const guildId = interaction.guildId;

    if (sub === 'create' || sub === 'edit') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to manage stickies.');
      const channel = interaction.options.getChannel('channel', true);
      if (channel.type !== ChannelType.GuildText) return ctx.responses.replyError(interaction, 'Pick a regular text channel.');
      const text = interaction.options.getString('text', true);
      const existing = await ctx.db.sticky.findFirst({ where: { guildId, channelId: channel.id } });

      if (sub === 'create' && existing) {
        return ctx.responses.replyError(interaction, `A sticky already exists in <#${channel.id}> — use \`/sticky edit\`.`);
      }

      let row;
      if (existing) {
        row = await ctx.db.sticky.update({ where: { id: existing.id }, data: { contentJson: ctx.settings.stringify({ text }) } });
        await deletePosted(channel, row.lastMessageId);
      } else {
        row = await ctx.db.sticky.create({ data: { guildId, channelId: channel.id, contentJson: ctx.settings.stringify({ text }), lastMessageId: null } });
      }
      bustCache(guildId);
      await repost(ctx, channel, row, interaction.member);
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>` }, `📌 Sticky ${sub === 'create' ? 'created' : 'updated'} in <#${channel.id}>.`);
    }

    if (sub === 'delete') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to manage stickies.');
      const channel = interaction.options.getChannel('channel', true);
      const row = await ctx.db.sticky.findFirst({ where: { guildId, channelId: channel.id } });
      if (!row) return ctx.responses.replyError(interaction, `No sticky found in <#${channel.id}>.`);
      await deletePosted(channel, row.lastMessageId);
      await ctx.db.sticky.delete({ where: { id: row.id } });
      bustCache(guildId);
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>` }, `📌 Sticky removed from <#${channel.id}>.`);
    }

    // list
    const rows = await getStickies(ctx, guildId);
    const lines = rows.slice(0, 25).map((r) => `• <#${r.channelId}> — ${(contentOf(ctx, r).split('|')[0] || '').trim().slice(0, 80) || '*empty*'}`);
    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle('📌 Stickies')
      .setDescription(lines.length ? lines.join('\n') : 'No stickies yet — create one with `/sticky create`.')
      .setFooter({ text: `${rows.length} sticky(ies)` });
    return respond(interaction, cmdCfg.responses.success, {}, `${rows.length} sticky(ies).`, { embeds: [embed] });
  },
};

/** Hook body for guild messages (module-level enabled check already done). */
async function onGuildMessage(ctx, message, cfg) {
  if (message.author.id === message.client.user.id) return;
  if (!cfg.enabled) return;

  const rows = await getStickies(ctx, message.guild.id);
  const row = rows.find((r) => r.channelId === message.channel.id);
  if (!row) return;

  const last = lastRepost.get(row.id) || 0;
  if (Date.now() - last <= 5000) return;

  await deletePosted(message.channel, row.lastMessageId);
  await repost(ctx, message.channel, row, message.member).catch(() => {});
}

module.exports = { command, onGuildMessage };
