'use strict';

const {
  ApplicationCommandOptionType,
  ChannelType,
  EmbedBuilder,
} = require('discord.js');
const { respond } = require('../../core/responses');
const config = require('../../config');
const service = require('./service');

const CH = ApplicationCommandOptionType.Channel;
const ROLE = ApplicationCommandOptionType.Role;
const STR = ApplicationCommandOptionType.String;

function staffRoleMentions(roleIds) {
  return (roleIds || []).map((id) => `<@&${id}>`).join(' ');
}

function relayEmbed(message) {
  const attachments = [...message.attachments.values()].map((a) => a.url);
  const desc = [String(message.content || '').slice(0, 3800), attachments.join('\n')].filter(Boolean).join('\n\n');
  return new EmbedBuilder()
    .setAuthor({
      name: `From ${message.author.tag || message.author.username}`.slice(0, 256),
      iconURL: message.author.displayAvatarURL ? message.author.displayAvatarURL({ size: 128, extension: 'png' }) : undefined,
    })
    .setDescription(desc.slice(0, 4000) || '*empty message*')
    .setColor(config.embedColor)
    .setTimestamp();
}

async function createThread(ctx, guild, cfg, user) {
  const staffRoleIds = (cfg.settings.modmailStaffRoles || []).slice(0, 10);
  const name = `modmail-${user.username}`.toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 90) || 'modmail-thread';
  const channel = await guild.channels.create({
    name,
    type: ChannelType.GuildText,
    parent: cfg.settings.modmailCategoryId || undefined,
    permissionOverwrites: [
      { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      ...staffRoleIds.map((id) => ({
        id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      })),
      {
        id: guild.members.me?.id || guild.client.user.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.ManageChannels,
        ],
      },
      { id: user.id, deny: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
    ],
  });
  const thread = await ctx.db.modMailThread.create({
    data: { guildId: guild.id, userId: user.id, channelId: channel.id, status: 'open' },
  });
  const intro = new EmbedBuilder()
    .setTitle('📬 Modmail thread opened')
    .setColor(config.embedColor)
    .setDescription(
      `Messages sent to me by <@${user.id}> land here.\nStaff reply with \`/modmail reply\` in this channel and close it with \`/modmail close\`.`,
    )
    .setTimestamp();
  await channel.send({ content: staffRoleMentions(staffRoleIds), embeds: [intro] }).catch(() => {});
  return thread;
}

const command = {
  name: 'modmail',
  description: 'Modmail — members DM the bot, staff answer from a private thread.',
  cooldown: 5,
  options: [
    {
      name: 'setup',
      description: 'Configure modmail (Manage Server)',
      type: 1,
      options: [
        { name: 'staff_role', description: 'Role that can read and answer threads', type: ROLE, required: true },
        { name: 'category', description: 'Category for thread channels', type: CH, required: true, channel_types: [ChannelType.GuildCategory] },
        { name: 'log_channel', description: 'Optional transcript log channel', type: CH, required: false, channel_types: [ChannelType.GuildText] },
      ],
    },
    {
      name: 'reply',
      description: 'Reply to the member (use inside a modmail thread)',
      type: 1,
      options: [{ name: 'text', description: 'Reply text sent to the member', type: STR, required: true, maxLength: 1500 }],
    },
    { name: 'close', description: 'Close this modmail thread (use inside the thread)', type: 1, options: [] },
  ],

  async run(ctx, interaction, cmdCfg) {
    const sub = interaction.options.getSubcommand(true);
    const guild = interaction.guild;
    const guildId = interaction.guildId;
    const cfg = await service.getCfg(ctx, guildId);

    if (sub === 'setup') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to configure modmail.');
      const staffRole = interaction.options.getRole('staff_role', true);
      const category = interaction.options.getChannel('category', true);
      if (category.type !== ChannelType.GuildCategory) return ctx.responses.replyError(interaction, 'Pick a category (not a channel).');
      const logChannel = interaction.options.getChannel('log_channel');
      const patch = {
        modmailStaffRoles: [staffRole.id],
        modmailCategoryId: category.id,
        modmailLogChannelId: logChannel?.id || null,
      };
      let next = null;
      for (const [key, value] of Object.entries(patch)) {
        // eslint-disable-next-line no-await-in-loop
        next = await service.setSettingAndAudit(ctx, guildId, interaction.user.id, `config.community.${key}`, key, value, next);
      }
      return respond(
        interaction,
        cmdCfg.responses.success,
        { role: `<@&${staffRole.id}>`, category: `<#${category.id}>`, log: logChannel ? `<#${logChannel.id}>` : 'none' },
        `📬 Modmail configured — staff role <@&${staffRole.id}>, threads in **${category.name}**, log ${logChannel ? `<#${logChannel.id}>` : 'disabled'}.\nMembers just DM me to open a thread.`,
        { ephemeralDefault: true },
      );
    }

    // reply / close — must be used inside an open thread channel
    const thread = await ctx.db.modMailThread.findFirst({ where: { guildId, channelId: interaction.channelId, status: 'open' } });
    if (!thread) return ctx.responses.replyError(interaction, 'Use this command inside a modmail thread channel.');
    if (!service.isStaff(interaction.member, cfg.settings.modmailStaffRoles)) {
      return ctx.responses.replyError(interaction, 'Only modmail staff can use the thread commands.');
    }

    if (sub === 'reply') {
      const text = interaction.options.getString('text', true);
      const user = await ctx.client.users.fetch(thread.userId).catch(() => null);
      if (!user) return ctx.responses.replyError(interaction, 'I could not fetch that member — they may have deleted their account.');
      const embed = new EmbedBuilder()
        .setAuthor({ name: `Staff team — ${guild.name}`.slice(0, 256), iconURL: guild.iconURL({ size: 128, extension: 'png' }) || undefined })
        .setDescription(text.slice(0, 4000))
        .setColor(config.embedColor)
        .setTimestamp();
      const sent = await user.send({ embeds: [embed] }).catch(() => null);
      if (!sent) return ctx.responses.replyError(interaction, 'The member has DMs closed — your reply was not delivered.');
      return respond(interaction, cmdCfg.responses.success, { target: `<@${thread.userId}>` }, `✅ Sent to <@${thread.userId}>.`, { ephemeralDefault: true });
    }

    // close
    await ctx.db.modMailThread.update({ where: { id: thread.id }, data: { status: 'closed' } }).catch(() => {});

    const logChannel = service.resolveChannel(guild, cfg.settings.modmailLogChannelId);
    if (service.isTextChannel(logChannel)) {
      try {
        const msgs = await interaction.channel.messages.fetch({ limit: 200 });
        const sorted = [...msgs.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);
        const lines = sorted.map(
          (m) =>
            `[${new Date(m.createdTimestamp).toISOString()}] ${m.author?.tag || m.author?.username || 'unknown'}: ${
              (m.content || '(attachment/embed)').slice(0, 300)
            }${m.attachments.size ? ` ${[...m.attachments.values()].map((a) => a.url).join(' ')}` : ''}`,
        );
        const body = `Modmail transcript — thread #${thread.id} with ${thread.userId} in ${guild.name}\n${'='.repeat(60)}\n${lines.join('\n')}`;
        await logChannel.send({
          content: `📄 Modmail transcript for <@${thread.userId}> (thread #${thread.id})`,
          files: [{ attachment: Buffer.from(body, 'utf8'), name: `modmail-${thread.id}.txt` }],
        }).catch(() => {});
      } catch {
        /* transcript is best effort */
      }
    }

    await respond(interaction, cmdCfg.responses.success, { target: `<@${thread.userId}>` }, '✅ Modmail thread closed.', { ephemeralDefault: true });
    await interaction.channel.delete('Modmail thread closed').catch(() => {});
  },
};

/** Hook body for DM messages (author is never a bot here — filtered upstream). */
async function onDmMessage(ctx, message) {
  const user = message.author;

  let thread = await ctx.db.modMailThread.findFirst({ where: { userId: user.id, status: 'open' }, orderBy: { id: 'asc' } });

  if (!thread) {
    // Find the first guild shared with the user where modmail is configured.
    let found = null;
    for (const guild of ctx.client.guilds.cache.values()) {
      const cfg = await service.getCfg(ctx, guild.id).catch(() => null);
      if (!cfg || !cfg.enabled) continue;
      if (!cfg.settings.modmailCategoryId || !(cfg.settings.modmailStaffRoles || []).length) continue;
      // eslint-disable-next-line no-await-in-loop
      const isMember = await guild.members.fetch(user.id).then(() => true).catch(() => false);
      if (isMember) {
        found = { guild, cfg };
        break;
      }
    }
    if (!found) {
      return message.channel.send('This bot could not find a server with modmail configured.').catch(() => {});
    }
    thread = await createThread(ctx, found.guild, found.cfg, user).catch((err) => {
      ctx.logger.warn(`[community:modmail] open failed: ${err?.message || err}`);
      return null;
    });
    if (!thread) {
      return message.channel.send('I could not open a modmail thread right now — please try again later.').catch(() => {});
    }
  }

  const channel = ctx.client.channels.cache.get(thread.channelId);
  if (!channel || !service.isTextChannel(channel)) {
    await ctx.db.modMailThread.updateMany({ where: { id: thread.id }, data: { status: 'closed' } }).catch(() => {});
    return message.channel.send('Your modmail thread was closed. Send another message to open a new one.').catch(() => {});
  }
  await channel.send({ embeds: [relayEmbed(message)] }).catch(() => {});
}

module.exports = { command, onDmMessage };
