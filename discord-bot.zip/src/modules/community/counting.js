'use strict';

const { ApplicationCommandOptionType, ChannelType, EmbedBuilder } = require('discord.js');
const { respond } = require('../../core/responses');
const config = require('../../config');
const service = require('./service');

const CH = ApplicationCommandOptionType.Channel;

const command = {
  name: 'count',
  description: 'Counting game — the channel counts up one number at a time.',
  cooldown: 2,
  options: [
    {
      name: 'set',
      description: 'Set the counting channel (Manage Server)',
      type: 1,
      options: [{ name: 'channel', description: 'Text channel used for counting', type: CH, required: true, channel_types: [ChannelType.GuildText] }],
    },
    { name: 'disable', description: 'Turn counting off and clear progress (Manage Server)', type: 1, options: [] },
    { name: 'stats', description: 'Show counting progress', type: 1, options: [] },
    { name: 'reset', description: 'Reset the current number to 0 (Manage Server)', type: 1, options: [] },
  ],

  async run(ctx, interaction, cmdCfg) {
    const sub = interaction.options.getSubcommand(true);
    const guildId = interaction.guildId;

    if (sub === 'set') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to configure counting.');
      const channel = interaction.options.getChannel('channel', true);
      if (channel.type !== ChannelType.GuildText) return ctx.responses.replyError(interaction, 'Pick a regular text channel.');
      const cfg = await service.getCfg(ctx, guildId);
      await ctx.db.countingState.deleteMany({ where: { guildId } });
      await ctx.db.countingState.create({ data: { guildId, channelId: channel.id, current: 0, best: 0, fails: 0, lastUserId: null } });
      await service.setSettingAndAudit(ctx, guildId, interaction.user.id, 'config.community.countingChannel', 'countingChannel', channel.id, cfg);
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>` }, `🔢 Counting set up in <#${channel.id}> — the next number is **1**!`);
    }

    if (sub === 'disable') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to disable counting.');
      const cfg = await service.getCfg(ctx, guildId);
      await ctx.db.countingState.deleteMany({ where: { guildId } });
      await service.setSettingAndAudit(ctx, guildId, interaction.user.id, 'config.community.countingChannel', 'countingChannel', null, cfg);
      return respond(interaction, cmdCfg.responses.success, {}, '🔢 Counting disabled and progress cleared.');
    }

    if (sub === 'stats') {
      const state = await ctx.db.countingState.findFirst({ where: { guildId } });
      if (!state) return ctx.responses.replyError(interaction, 'Counting is not set up — an admin can enable it with `/count set`.');
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle('🔢 Counting stats')
        .setDescription(`Counting channel: <#${state.channelId}>`)
        .addFields(
          { name: 'Current', value: `${state.current}`, inline: true },
          { name: 'Best', value: `${state.best}`, inline: true },
          { name: 'Fails', value: `${state.fails}`, inline: true },
        )
        .setFooter({ text: state.lastUserId ? `Last count by <@${state.lastUserId}>`.slice(0, 200) : 'Nobody has counted yet' });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { current: String(state.current), best: String(state.best), fails: String(state.fails) },
        `🔢 Current **${state.current}** • best **${state.best}** • fails **${state.fails}**.`,
        { embeds: [embed] },
      );
    }

    // reset
    if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to reset the count.');
    const state = await ctx.db.countingState.findFirst({ where: { guildId } });
    if (!state) return ctx.responses.replyError(interaction, 'Counting is not set up — an admin can enable it with `/count set`.');
    await ctx.db.countingState.update({ where: { channelId: state.channelId }, data: { current: 0, lastUserId: null } });
    return respond(interaction, cmdCfg.responses.success, {}, `♻️ The count resets to **0** (best **${state.best}** and fails **${state.fails}** kept).`);
  },
};

/** Hook body for guild messages (module-level enabled check already done). */
async function onGuildMessage(ctx, message, cfg) {
  const state = await ctx.db.countingState.findUnique({ where: { channelId: message.channel.id } });
  if (!state) return;

  const raw = String(message.content || '').trim();
  const m = /^(\d+)/.exec(raw);
  const num = m ? parseInt(m[1], 10) : NaN;
  const expected = state.current + 1;
  const valid = Number.isFinite(num) && num === expected && message.author.id !== state.lastUserId;

  if (valid) {
    await message.react('✅').catch(() => {});
    await ctx.db.countingState
      .update({ where: { channelId: message.channel.id }, data: { current: num, lastUserId: message.author.id, best: Math.max(state.best, num) } })
      .catch(() => {});
    return;
  }

  await message.delete().catch(() => {});
  const keepOnFail = Boolean(cfg.settings.countingKeepOnFail);
  const keep = keepOnFail ? state.current : 0;

  let reason;
  if (!Number.isFinite(num)) reason = `That is not a number — the next number was **${expected}**.`;
  else if (message.author.id === state.lastUserId) reason = `You cannot count twice in a row — the next number was **${expected}**.`;
  else reason = `Expected **${expected}**, got **${num}**.`;

  const text = `❌ <@${message.author.id}> broke the count! ${reason} ${keepOnFail ? `The count continues from **${keep}**.` : 'The count resets to **0**.'}`;
  const sent = await message.channel.send({ content: text.slice(0, 2000) }).catch(() => null);
  if (sent) setTimeout(() => sent.delete().catch(() => {}), 5000).unref();

  await ctx.db.countingState
    .update({ where: { channelId: message.channel.id }, data: { fails: { increment: 1 }, current: keep, lastUserId: null } })
    .catch(() => {});
}

module.exports = { command, onGuildMessage };
