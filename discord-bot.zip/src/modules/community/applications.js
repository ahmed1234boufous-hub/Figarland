'use strict';

const {
  ApplicationCommandOptionType,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ChannelType,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
} = require('discord.js');
const { respond } = require('../../core/responses');
const config = require('../../config');
const service = require('./service');

const CH = ApplicationCommandOptionType.Channel;
const INT = ApplicationCommandOptionType.Integer;
const STR = ApplicationCommandOptionType.String;
const ROLE = ApplicationCommandOptionType.Role;

function decisionRow(responseId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`cm:appdec:${responseId}:accept`).setLabel('Accept').setStyle(ButtonStyle.Success).setEmoji('✅'),
    new ButtonBuilder().setCustomId(`cm:appdec:${responseId}:deny`).setLabel('Deny').setStyle(ButtonStyle.Danger).setEmoji('✖️'),
  );
}

function applyModal(app) {
  const modal = new ModalBuilder().setCustomId(`cmm:app:${app.id}`).setTitle(`Apply: ${app.title}`.slice(0, 45));
  app.questionsJson.forEach((question, i) => {
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId(`q${i}`)
          .setLabel(String(question).slice(0, 45))
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1000),
      ),
    );
  });
  return modal;
}

async function reviewEmbed(ctx, interaction, app, created, answers) {
  const embed = new EmbedBuilder()
    .setColor(config.embedColor)
    .setTitle(`📋 New application — ${app.title}`.slice(0, 256))
    .setDescription(
      answers.map((a, i) => `**${i + 1}. ${String(a.question).slice(0, 200)}**\n${a.answer || '*empty*'}`).join('\n\n').slice(0, 3800) || '*empty*',
    )
    .addFields(
      { name: 'Applicant', value: `<@${interaction.user.id}>`, inline: true },
      { name: 'Response', value: `#${created.id}`, inline: true },
      { name: 'Status', value: 'pending', inline: true },
    )
    .setTimestamp();
  if (app.roleId) embed.addFields({ name: 'Reward on accept', value: `<@&${app.roleId}>`, inline: true });
  return embed;
}

async function assignRewardRole(ctx, guild, app, userId) {
  if (!app?.roleId) return false;
  const role = guild.roles.cache.get(app.roleId);
  if (!role || role.managed) return false;
  const me = guild.members.me;
  if (me && role.position >= me.roles.highest.position) return false;
  const member = await guild.members.fetch(userId).catch(() => null);
  if (!member) return false;
  await member.roles.add(role, 'Application accepted').catch(() => {});
  return true;
}

async function dmResult(ctx, guild, app, resp, decision, note) {
  const user = await ctx.client.users.fetch(resp.userId).catch(() => null);
  if (!user) return;
  const title = app?.title || `#${resp.applicationId}`;
  const embed =
    decision === 'accepted'
      ? new EmbedBuilder()
          .setColor(config.successColor)
          .setTitle('🎉 Application accepted')
          .setDescription(`Your application **${title}** in **${guild.name}** was accepted!${app?.roleId ? '\nYour reward role has been assigned.' : ''}`)
      : new EmbedBuilder()
          .setColor(config.errorColor)
          .setTitle('Application denied')
          .setDescription(`Your application **${title}** in **${guild.name}** was denied.`);
  if (note) embed.addFields({ name: 'Staff note', value: String(note).slice(0, 1000) });
  embed.setTimestamp();
  await user.send({ embeds: [embed] }).catch(() => {});
}

const command = {
  name: 'application',
  description: 'Staff-reviewed applications with a panel, apply button and decisions.',
  cooldown: 5,
  options: [
    {
      name: 'create',
      description: 'Create an application panel (Manage Server)',
      type: 1,
      options: [
        { name: 'title', description: 'Application title', type: STR, required: true, maxLength: 100 },
        { name: 'questions', description: '1-5 questions separated by |', type: STR, required: true, maxLength: 1500 },
        { name: 'review_channel', description: 'Where applications are reviewed', type: CH, required: true, channel_types: [ChannelType.GuildText] },
        { name: 'role_reward', description: 'Role assigned when accepted', type: ROLE, required: false },
      ],
    },
    {
      name: 'accept',
      description: 'Accept an application response (staff)',
      type: 1,
      options: [
        { name: 'response_id', description: 'Response ID from the review embed', type: INT, required: true, minValue: 1 },
        { name: 'note', description: 'Optional note sent to the applicant', type: STR, required: false, maxLength: 500 },
      ],
    },
    {
      name: 'deny',
      description: 'Deny an application response (staff)',
      type: 1,
      options: [
        { name: 'response_id', description: 'Response ID from the review embed', type: INT, required: true, minValue: 1 },
        { name: 'note', description: 'Optional note sent to the applicant', type: STR, required: false, maxLength: 500 },
      ],
    },
    { name: 'list', description: 'List applications and their pending responses', type: 1, options: [] },
    {
      name: 'close',
      description: 'Close an application so nobody can apply anymore (Manage Server)',
      type: 1,
      options: [{ name: 'app_id', description: 'Application ID', type: INT, required: true, minValue: 1 }],
    },
  ],

  async run(ctx, interaction, cmdCfg) {
    const sub = interaction.options.getSubcommand(true);
    const guildId = interaction.guildId;
    const cfg = await service.getCfg(ctx, guildId);

    if (sub === 'create') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to create applications.');
      const title = interaction.options.getString('title', true).trim();
      const questions = service.parseQuestions(interaction.options.getString('questions', true), 5);
      if (!questions) return ctx.responses.replyError(interaction, 'Provide between **1 and 5** questions separated by `|`.');
      const reviewChannel = interaction.options.getChannel('review_channel', true);
      if (!service.isTextChannel(reviewChannel)) return ctx.responses.replyError(interaction, 'The review channel must be a regular text channel.');
      const role = interaction.options.getRole('role_reward');
      if (role && (role.managed || role.position >= (interaction.guild.members.me?.roles.highest?.position ?? 0))) {
        return ctx.responses.replyError(interaction, 'That reward role is managed or above my highest role — pick another one.');
      }

      const app = await ctx.db.applicationForm.create({
        data: {
          guildId,
          title,
          roleId: role?.id || null,
          questionsJson: questions,
          panelChannelId: interaction.channelId,
          reviewChannelId: reviewChannel.id,
          open: true,
          createdById: interaction.user.id,
        },
      });

      const panel = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle(`📋 ${title}`.slice(0, 256))
        .setDescription(
          `Click **Apply** below and answer ${questions.length} short question(s).\nApplications are reviewed by the staff team.` +
            (app.roleId ? `\n\n**Reward:** <@&${app.roleId}>` : ''),
        )
        .setFooter({ text: `Application #${app.id}` });
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`cm:appapply:${app.id}`).setLabel('Apply').setEmoji('📋').setStyle(ButtonStyle.Primary),
      );
      await interaction.channel.send({ embeds: [panel], components: [row] }).catch(() => {});
      return respond(
        interaction,
        cmdCfg.responses.success,
        { app: title, appid: String(app.id) },
        `✅ Application panel **#${app.id} — ${title}** posted. Review channel: <#${reviewChannel.id}>.`,
        { ephemeralDefault: true },
      );
    }

    if (sub === 'list') {
      const apps = await ctx.db.applicationForm.findMany({ where: { guildId }, orderBy: { id: 'desc' }, take: 25 });
      const lines = [];
      for (const app of apps) {
        // eslint-disable-next-line no-await-in-loop
        const pending = await ctx.db.applicationResponse.count({ where: { applicationId: app.id, status: 'pending' } });
        lines.push(`• **#${app.id} — ${app.title}** ${app.open ? '🟢 open' : '🔴 closed'} — ${pending} pending`);
      }
      return respond(
        interaction,
        cmdCfg.responses.success,
        {},
        lines.length ? `${apps.length} application(s).` : 'No applications yet — create one with `/application create`.',
        {
          embeds: [
            new EmbedBuilder()
              .setColor(config.embedColor)
              .setTitle('📋 Applications')
              .setDescription(lines.join('\n').slice(0, 4000) || 'No applications yet — create one with `/application create`.'),
          ],
        },
      );
    }

    if (sub === 'close') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to close applications.');
      const appId = interaction.options.getInteger('app_id', true);
      const app = await ctx.db.applicationForm.findUnique({ where: { id: appId } });
      if (!app || app.guildId !== guildId) return ctx.responses.replyError(interaction, 'That application does not exist in this server.');
      if (!app.open) return ctx.responses.replyError(interaction, 'That application is already closed.');
      await ctx.db.applicationForm.update({ where: { id: app.id }, data: { open: false } });
      return respond(interaction, cmdCfg.responses.success, { app: app.title, appid: String(app.id) }, `🔴 Application **#${app.id} — ${app.title}** is closed.`, { ephemeralDefault: true });
    }

    // accept / deny
    if (!service.isStaff(interaction.member, cfg.settings.reviewRoleIds)) {
      return ctx.responses.replyError(interaction, 'Only the application review team can decide applications.');
    }
    const responseId = interaction.options.getInteger('response_id', true);
    const note = interaction.options.getString('note') || null;
    const resp = await ctx.db.applicationResponse.findUnique({ where: { id: responseId } });
    if (!resp || resp.guildId !== guildId) return ctx.responses.replyError(interaction, 'That application response does not exist in this server.');
    if (resp.status !== 'pending') return ctx.responses.replyError(interaction, `That application was already **${resp.status}**.`);

    const decision = sub === 'accept' ? 'accepted' : 'denied';
    await ctx.db.applicationResponse.update({ where: { id: resp.id }, data: { status: decision, decidedById: interaction.user.id } });
    const app = await ctx.db.applicationForm.findUnique({ where: { id: resp.applicationId } });

    let roleNote = '';
    if (decision === 'accepted') {
      const assigned = await assignRewardRole(ctx, interaction.guild, app, resp.userId);
      roleNote = assigned ? ' and the reward role was assigned' : '';
    }
    await dmResult(ctx, interaction.guild, app, resp, decision, note);
    return respond(
      interaction,
      cmdCfg.responses.success,
      { appid: String(resp.applicationId), response: String(resp.id) },
      `✅ Application **#${resp.id}** ${decision}${roleNote}.`,
      { ephemeralDefault: true },
    );
  },
};

/** Component cm:appapply:<appId> — rest is '<appId>'. */
async function handleApplyButton(ctx, interaction, rest) {
  const appId = parseInt(String(rest).trim(), 10);
  const app = Number.isFinite(appId) ? await ctx.db.applicationForm.findUnique({ where: { id: appId } }) : null;
  if (!app || app.guildId !== interaction.guildId) return ctx.responses.replyError(interaction, 'That application no longer exists.');
  if (!app.open) return ctx.responses.replyError(interaction, 'This application is closed.');
  return interaction.showModal(applyModal(app));
}

/** Modal handler cmm:app:<appId> — rest is '<appId>'. */
async function handleApplyModal(ctx, interaction, rest) {
  const appId = parseInt(String(rest).trim(), 10);
  const app = Number.isFinite(appId) ? await ctx.db.applicationForm.findUnique({ where: { id: appId } }) : null;
  if (!app || app.guildId !== interaction.guildId) return ctx.responses.replyError(interaction, 'That application no longer exists.');
  if (!app.open) return ctx.responses.replyError(interaction, 'This application is closed.');

  const answers = app.questionsJson.map((question, i) => {
    let value = '';
    try {
      value = interaction.fields.getTextInputValue(`q${i}`) || '';
    } catch {
      value = '';
    }
    return { question, answer: value.slice(0, 1000) };
  });

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const created = await ctx.db.applicationResponse.create({
    data: { guildId: interaction.guildId, applicationId: app.id, userId: interaction.user.id, answersJson: JSON.stringify(answers), status: 'pending' },
  });

  const channel = service.resolveChannel(interaction.guild, app.reviewChannelId);
  if (service.isTextChannel(channel)) {
    const embed = await reviewEmbed(ctx, interaction, app, created, answers);
    await channel.send({ embeds: [embed], components: [decisionRow(created.id)] }).catch(() => {});
  }

  const cmdCfg = await ctx.settings.getCommandConfig(interaction.guildId, service.MODULE_KEY, 'application');
  return respond(
    interaction,
    cmdCfg.responses?.success,
    { app: app.title, appid: String(app.id) },
    '✅ Application submitted — the staff team will review it soon.',
    { ephemeralDefault: true },
  );
}

/** Component cm:appdec:<respId>:accept|deny — rest is '<respId>:<decision>'. */
async function handleDecisionButton(ctx, interaction, rest) {
  const [idStr, decisionRaw] = String(rest).split(':');
  const decision = decisionRaw === 'accept' ? 'accepted' : decisionRaw === 'deny' ? 'denied' : null;
  if (!decision) return;

  const cfg = await service.getCfg(ctx, interaction.guildId);
  if (!service.isStaff(interaction.member, cfg.settings.reviewRoleIds)) {
    return ctx.responses.replyError(interaction, 'Only the application review team can decide applications.');
  }

  const respId = parseInt(String(idStr).trim(), 10);
  const resp = Number.isFinite(respId) ? await ctx.db.applicationResponse.findUnique({ where: { id: respId } }) : null;
  if (!resp || resp.guildId !== interaction.guildId) return ctx.responses.replyError(interaction, 'That application response no longer exists.');
  if (resp.status !== 'pending') return ctx.responses.replyError(interaction, `That application was already **${resp.status}**.`);

  await ctx.db.applicationResponse.update({ where: { id: resp.id }, data: { status: decision, decidedById: interaction.user.id } });
  const app = await ctx.db.applicationForm.findUnique({ where: { id: resp.applicationId } });

  let roleNote = '';
  if (decision === 'accepted') {
    const assigned = await assignRewardRole(ctx, interaction.guild, app, resp.userId);
    roleNote = assigned ? ' and the reward role was assigned' : '';
  }
  await dmResult(ctx, interaction.guild, app, resp, decision, null);

  // Reflect the decision on the review embed and remove the buttons.
  const msg = interaction.message;
  if (msg?.editable && msg.embeds?.length) {
    try {
      const embed = EmbedBuilder.from(msg.embeds[0])
        .setColor(decision === 'accepted' ? config.successColor : config.errorColor)
        .addFields({ name: 'Decision', value: `${decision === 'accepted' ? '✅ Accepted' : '❌ Denied'} by <@${interaction.user.id}>` });
      await msg.edit({ embeds: [embed], components: [] });
    } catch {
      /* best effort */
    }
  }

  return ctx.responses.replySimple(interaction, `✅ Application **#${resp.id}** ${decision}${roleNote}.`, { ephemeral: true });
}

module.exports = { command, handleApplyButton, handleApplyModal, handleDecisionButton };
