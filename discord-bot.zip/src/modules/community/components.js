'use strict';

/**
 * components.js — routes 'cm:' component and 'cmm:' modal interactions.
 *
 * customId scheme (prefix stripped before calling):
 *   cm:appapply:<appId>
 *   cm:appdec:<respId>:accept|deny
 *   cm:rsvp:<eventId>:going|interested|no
 *   cmm:form:<formId>
 *   cmm:app:<appId>
 */

const forms = require('./forms');
const applications = require('./applications');
const events = require('./events');

async function handleComponent(ctx, interaction, rest) {
  const [action, ...payloadParts] = String(rest).split(':');
  const payload = payloadParts.join(':');

  if (action === 'appapply') return applications.handleApplyButton(ctx, interaction, payload);
  if (action === 'appdec') return applications.handleDecisionButton(ctx, interaction, payload);
  if (action === 'rsvp') return events.handleRsvp(ctx, interaction, payload);
}

async function handleModal(ctx, interaction, rest) {
  const [action, ...payloadParts] = String(rest).split(':');
  const payload = payloadParts.join(':');

  if (action === 'form') return forms.handleFormModal(ctx, interaction, payload);
  if (action === 'app') return applications.handleApplyModal(ctx, interaction, payload);
}

module.exports = { handleComponent, handleModal };
