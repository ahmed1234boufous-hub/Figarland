'use strict';

const {
  ApplicationCommandOptionType,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  EmbedBuilder,
} = require('discord.js');
const { respond } = require('../../core/responses');
const config = require('../../config');
const settings = require('../../core/settings');
const service = require('./service');

const INT = ApplicationCommandOptionType.Integer;
const STR = ApplicationCommandOptionType.String;

function rsvpRow(eventId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`cm:rsvp:${eventId}:going`).setLabel('Going').setStyle(ButtonStyle.Success).setEmoji('✅'),
    new ButtonBuilder().setCustomId(`cm:rsvp:${eventId}:interested`).setLabel('Interested').setStyle(ButtonStyle.Primary).setEmoji('⭐'),
    new ButtonBuilder().setCustomId(`cm:rsvp:${eventId}:no`).setLabel('Not going').setStyle(ButtonStyle.Secondary).setEmoji('❌'),
  );
}

function eventEmbed(ev, guild) {
  const buckets = settings.parse(ev.rsvpsJson, { going: [], interested: [], no: [] }) || { going: [], interested: [], no: [] };
  const going = buckets.going || [];
  const interested = buckets.interested || [];
  const no = buckets.no || [];
  const mentionList = (ids) => (ids.length ? ids.map((id) => `<@${id}>`).join(' ').slice(0, 1024) : '—');
  return new EmbedBuilder()
    .setTitle(`📅 ${ev.title}`.slice(0, 256))
    .setColor(config.embedColor)
    .setDescription(ev.description ? String(ev.description).slice(0, 3800) : '*No description provided.*')
    .addFields(
      { name: 'Starts (UTC)', value: `<t:${service.unix(ev.startAt)}:F>\n(<t:${service.unix(ev.startAt)}:R>)` },
      { name: `Going (${going.length})`, value: mentionList(going), inline: true },
      { name: `Interested (${interested.length})`, value: mentionList(interested), inline: true },
      { name: `Not going (${no.length})`, value: mentionList(no), inline: true },
    )
    .setFooter({ text: `Event #${ev.id} • click a button to RSVP` });
}

async function editAnnouncement(ctx, ev, guild, payloadBuilder) {
  if (!ev.messageId || !ev.channelId) return;
  const channel = service.resolveChannel(guild, ev.channelId);
  if (!channel || !service.isTextChannel(channel)) return;
  const msg = await channel.messages.fetch(ev.messageId).catch(() => null);
  if (!msg || !msg.editable) return;
  await payloadBuilder(msg).catch(() => {});
}

const command = {
  name: 'event',
  description: 'Schedule server events with RSVP buttons and automatic reminders.',
  cooldown: 5,
  options: [
    {
      name: 'create',
      description: 'Create an event (Manage Server)',
      type: 1,
      options: [
        { name: 'title', description: 'Event title', type: STR, required: true, maxLength: 100 },
        { name: 'starts', description: 'Start time, UTC — format YYYY-MM-DD HH:mm', type: STR, required: true, maxLength: 16 },
        { name: 'description', description: 'Optional description', type: STR, required: false, maxLength: 1000 },
      ],
    },
    {
      name: 'edit',
      description: 'Edit an event (Manage Server)',
      type: 1,
      options: [
        { name: 'id', description: 'Event ID', type: INT, required: true, minValue: 1 },
        { name: 'title', description: 'New title', type: STR, required: false, maxLength: 100 },
        { name: 'description', description: 'New description', type: STR, required: false, maxLength: 1000 },
        { name: 'starts', description: 'New start time, UTC — YYYY-MM-DD HH:mm', type: STR, required: false, maxLength: 16 },
      ],
    },
    { name: 'list', description: 'List upcoming events', type: 1, options: [] },
    {
      name: 'cancel',
      description: 'Cancel an event (Manage Server)',
      type: 1,
      options: [{ name: 'id', description: 'Event ID', type: INT, required: true, minValue: 1 }],
    },
  ],

  async run(ctx, interaction, cmdCfg) {
    const sub = interaction.options.getSubcommand(true);
    const guild = interaction.guild;
    const guildId = interaction.guildId;
    const cfg = await service.getCfg(ctx, guildId);

    if (sub === 'create') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to create events.');
      const title = interaction.options.getString('title', true).trim();
      const startAt = service.parseUtcDate(interaction.options.getString('starts', true));
      if (!startAt) return ctx.responses.replyError(interaction, 'Invalid start time — use `YYYY-MM-DD HH:mm` (UTC), e.g. `2025-08-01 18:00`.');
      if (startAt.getTime() <= Date.now()) return ctx.responses.replyError(interaction, 'That start time is in the past.');
      const description = interaction.options.getString('description') || '';

      const target = service.resolveChannel(guild, cfg.settings.eventsChannel) || interaction.channel;
      const ev = await ctx.db.serverEvent.create({
        data: {
          guildId,
          title,
          description,
          startAt,
          channelId: target.id,
          createdById: interaction.user.id,
          rsvpsJson: JSON.stringify({ going: [], interested: [], no: [] }),
          announced: false,
        },
      });
      const msg = await target
        .send({ embeds: [eventEmbed(ev, guild)], components: [rsvpRow(ev.id)] })
        .catch(() => null);
      if (msg) await ctx.db.serverEvent.update({ where: { id: ev.id }, data: { messageId: msg.id } }).catch(() => {});
      return respond(
        interaction,
        cmdCfg.responses.success,
        { event: title, eventid: String(ev.id), channel: `<#${target.id}>` },
        `📅 Event **#${ev.id} — ${title}** created — announcement posted in <#${target.id}>. Reminder goes out 60 minutes before start.`,
        { ephemeralDefault: true },
      );
    }

    if (sub === 'list') {
      const events = await ctx.db.serverEvent.findMany({ where: { guildId }, orderBy: { startAt: 'asc' }, take: 15 });
      const now = Date.now();
      const upcoming = events.filter((e) => new Date(e.startAt).getTime() >= now);
      const past = events.filter((e) => new Date(e.startAt).getTime() < now);
      const lines = [...upcoming, ...past.slice(0, 5)].map(
        (e) => `• **#${e.id} — ${e.title}** — <t:${service.unix(e.startAt)}:F> ${new Date(e.startAt).getTime() < now ? '*(past)*' : ''}`,
      );
      const embed = new EmbedBuilder()
        .setColor(config.embedColor)
        .setTitle('📅 Events')
        .setDescription(lines.join('\n').slice(0, 4000) || 'No events yet — create one with `/event create`.')
        .setFooter({ text: `${upcoming.length} upcoming` });
      return respond(interaction, cmdCfg.responses.success, {}, `${upcoming.length} upcoming event(s).`, { embeds: [embed] });
    }

    const evId = interaction.options.getInteger('id', true);
    const ev = await ctx.db.serverEvent.findUnique({ where: { id: evId } });
    if (!ev || ev.guildId !== guildId) return ctx.responses.replyError(interaction, 'That event does not exist in this server.');

    if (sub === 'edit') {
      if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to edit events.');
      const title = interaction.options.getString('title');
      const description = interaction.options.getString('description');
      const startsRaw = interaction.options.getString('starts');
      const data = {};
      if (title !== null) data.title = title.trim();
      if (description !== null) data.description = description;
      if (startsRaw !== null) {
        const startAt = service.parseUtcDate(startsRaw);
        if (!startAt) return ctx.responses.replyError(interaction, 'Invalid start time — use `YYYY-MM-DD HH:mm` (UTC), e.g. `2025-08-01 18:00`.');
        data.startAt = startAt;
      }
      if (!Object.keys(data).length) return ctx.responses.replyError(interaction, 'Nothing to change — provide `title`, `description` and/or `starts`.');
      const updated = await ctx.db.serverEvent.update({ where: { id: ev.id }, data });
      await editAnnouncement(ctx, updated, guild, (msg) => msg.edit({ embeds: [eventEmbed(updated, guild)], components: [rsvpRow(updated.id)] }));
      return respond(interaction, cmdCfg.responses.success, { event: updated.title, eventid: String(updated.id) }, `✏️ Event **#${updated.id}** updated.`, { ephemeralDefault: true });
    }

    // cancel
    if (!service.isStaff(interaction.member, [])) return ctx.responses.replyError(interaction, 'You need **Manage Server** to cancel events.');
    await ctx.db.serverEvent.delete({ where: { id: ev.id } }).catch(() => {});
    await editAnnouncement(ctx, ev, guild, (msg) =>
      msg.edit({
        embeds: [EmbedBuilder.from(msg.embeds[0] || eventEmbed(ev, guild)).setColor(config.errorColor).setFooter({ text: `Event #${ev.id} • 🚫 cancelled` })],
        components: [],
      }),
    );
    return respond(interaction, cmdCfg.responses.success, { event: ev.title, eventid: String(ev.id) }, `🚫 Event **#${ev.id} — ${ev.title}** cancelled.`, { ephemeralDefault: true });
  },
};

/** Component cm:rsvp:<eventId>:going|interested|no — rest is '<eventId>:<bucket>'. */
async function handleRsvp(ctx, interaction, rest) {
  const [idStr, bucket] = String(rest).split(':');
  if (!['going', 'interested', 'no'].includes(bucket)) return;
  const evId = parseInt(String(idStr).trim(), 10);
  const ev = Number.isFinite(evId) ? await ctx.db.serverEvent.findUnique({ where: { id: evId } }) : null;
  if (!ev || ev.guildId !== interaction.guildId) return ctx.responses.replyError(interaction, 'That event no longer exists.');

  const buckets = ctx.settings.parse(ev.rsvpsJson, { going: [], interested: [], no: [] }) || { going: [], interested: [], no: [] };
  const wasIn = (buckets[bucket] || []).includes(interaction.user.id);
  for (const key of Object.keys(buckets)) {
    buckets[key] = (buckets[key] || []).filter((id) => id !== interaction.user.id);
  }
  if (!wasIn) buckets[bucket].push(interaction.user.id);
  await ctx.db.serverEvent.update({ where: { id: ev.id }, data: { rsvpsJson: JSON.stringify(buckets) } }).catch(() => {});

  const updated = { ...ev, rsvpsJson: JSON.stringify(buckets) };
  const labels = { going: 'Going', interested: 'Interested', no: 'Not going' };
  const text = wasIn ? `RSVP removed (was **${labels[bucket]}**).` : `✅ RSVP saved: **${labels[bucket]}**.`;

  if (interaction.message?.editable) {
    // interaction.update must be the first response — the ephemeral notice follows as a follow-up.
    await interaction.update({ embeds: [eventEmbed(updated, interaction.guild)], components: [rsvpRow(ev.id)] }).catch(() => {});
    return interaction.followUp({ content: text, flags: 64 }).catch(() => {});
  }
  return ctx.responses.replySimple(interaction, text, { ephemeral: true });
}

/** Scheduler job body — remind 60 minutes before unannounced events. */
async function runReminders(ctx) {
  const now = Date.now();
  const soon = new Date(now + 60 * 60 * 1000);
  const events = await ctx.db.serverEvent.findMany({
    where: { announced: false, startAt: { gte: new Date(now), lte: soon } },
  });
  if (!events.length) return;

  for (const ev of events) {
    try {
      await ctx.db.serverEvent.update({ where: { id: ev.id }, data: { announced: true } });
      const guild = ctx.client.guilds.cache.get(ev.guildId);
      const channel = guild ? service.resolveChannel(guild, ev.channelId) : null;
      if (channel && service.isTextChannel(channel) && ev.messageId) {
        const msg = await channel.messages.fetch(ev.messageId).catch(() => null);
        if (msg?.editable) {
          const embed = EmbedBuilder.from(msg.embeds[0] || eventEmbed(ev, guild)).setColor(config.warnColor);
          await msg.edit({ content: '⏰ **Starts soon!**', embeds: [embed] }).catch(() => {});
        }
      }
      const buckets = ctx.settings.parse(ev.rsvpsJson, {}) || {};
      const userIds = [...new Set([...(buckets.going || []), ...(buckets.interested || [])])];
      for (const userId of userIds) {
        // eslint-disable-next-line no-await-in-loop
        const user = await ctx.client.users.fetch(userId).catch(() => null);
        if (!user) continue;
        // eslint-disable-next-line no-await-in-loop
        await user
          .send(`⏰ Reminder: **${ev.title}** in **${guild?.name || 'your server'}** starts <t:${service.unix(ev.startAt)}:R>.`)
          .catch(() => {});
      }
    } catch (err) {
      ctx.logger.warn(`[community:events] ${ev.id}: ${err?.message || err}`);
    }
  }
}

module.exports = { command, handleRsvp, runReminders };
