'use strict';

const { ChannelType, PermissionFlagsBits } = require('discord.js');

/**
 * service.js — shared helpers for the community module.
 */

const MODULE_KEY = 'community';

/** Module settings for a guild (defaults merged with stored overrides). */
async function getCfg(ctx, guildId) {
  return ctx.settings.getModuleConfig(guildId, MODULE_KEY);
}

function resolveChannel(guild, channelId) {
  if (!guild || !channelId) return null;
  return guild.channels.cache.get(channelId) || null;
}

/** Manage Server (or Administrator) OR membership of one of the given roles. */
function isStaff(member, roleIds = []) {
  if (!member) return false;
  if (member.permissions?.has(PermissionFlagsBits.Administrator)) return true;
  if (member.permissions?.has(PermissionFlagsBits.ManageGuild)) return true;
  return (roleIds || []).some((r) => member.roles?.cache?.has(r));
}

/** 'YYYY-MM-DD HH:mm' interpreted as UTC → Date, or null when invalid. */
function parseUtcDate(raw) {
  const m = /^\s*(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})\s*$/.exec(String(raw || ''));
  if (!m) return null;
  const [, y, mo, d, h, mi] = m;
  const ms = Date.parse(`${y}-${mo}-${d}T${h}:${mi}:00Z`);
  if (Number.isNaN(ms)) return null;
  const dt = new Date(ms);
  // Reject rolled-over dates such as 2025-02-31.
  if (dt.getUTCMonth() + 1 !== parseInt(mo, 10) || dt.getUTCDate() !== parseInt(d, 10)) return null;
  return dt;
}

/** Real calendar date check for birthdays (leap-year aware via 2024). */
function validBirthday(month, day) {
  if (!Number.isInteger(month) || !Number.isInteger(day)) return false;
  const dt = new Date(Date.UTC(2024, month - 1, day));
  return dt.getUTCMonth() === month - 1 && dt.getUTCDate() === day;
}

/** Split a '|'-separated string into 1..max trimmed questions (null when invalid). */
function parseQuestions(raw, max = 5) {
  const questions = String(raw || '')
    .split('|')
    .map((q) => q.trim())
    .filter(Boolean);
  if (!questions.length || questions.length > max) return null;
  return questions;
}

/** Persist one module setting with an audit trail. Returns the next module config. */
async function setSettingAndAudit(ctx, guildId, userId, action, key, value, beforeCfg) {
  const before = beforeCfg ? { enabled: beforeCfg.enabled, settings: beforeCfg.settings } : null;
  const next = await ctx.settings.setModuleSetting(guildId, MODULE_KEY, key, value);
  await ctx.audit.log(guildId, userId, action, `module:${MODULE_KEY}`, before, next);
  return next;
}

/** First segment of a '|'-separated random pool. */
function pickRandom(content) {
  const pool = String(content || '')
    .split('|')
    .map((s) => s.trim())
    .filter(Boolean);
  if (!pool.length) return String(content || '');
  return pool[Math.floor(Math.random() * pool.length)];
}

function unix(date) {
  return Math.floor(new Date(date).getTime() / 1000);
}

function isTextChannel(channel) {
  return Boolean(channel) && channel.type === ChannelType.GuildText && channel.isTextBased();
}

module.exports = {
  MODULE_KEY,
  getCfg,
  resolveChannel,
  isStaff,
  parseUtcDate,
  validBirthday,
  parseQuestions,
  setSettingAndAudit,
  pickRandom,
  unix,
  isTextChannel,
};
