'use strict';

const { PermissionFlagsBits } = require('discord.js');
const { commands } = require('./commands');
const dashboard = require('./dashboard');
const service = require('./service');
const responses = require('../../core/responses');

module.exports = {
  key: 'automod',
  name: 'Auto Moderation',
  emoji: '🤖',
  dashboardCommandName: 'automod-dashboard',

  settingsSchema: [
    { key: 'alertChannel', label: 'Alert channel', type: 'channel', desc: 'Automod alerts and escalations are posted here.' },
    { key: 'exemptRoleIds', label: 'Exempt roles', type: 'roles', desc: 'Members with these roles bypass all automod rules.' },
    { key: 'escalationAfter', label: 'Escalate after hits', type: 'number', desc: 'Hits within one hour before the escalation action runs (0 = off).' },
    { key: 'escalationAction', label: 'Escalation action', type: 'text', desc: 'One of: delete, warn, timeout, kick, alert.' },
  ],

  defaults: {
    enabled: true,
    settings: {
      alertChannel: null,
      exemptRoleIds: [],
      exemptChannelIds: [],
      escalationAfter: 3,
      escalationAction: 'timeout',
    },
    commands: {
      automod: { cooldown: 5, responses: { success: { text: '', ephemeral: true } } },
    },
  },

  commands,

  dashboard,

  /**
   * Buttons attached to automod alert embeds.
   * rest = 'timeout:<userId>'
   */
  componentHandlers: {
    'am:': async (ctx, interaction, rest) => {
      try {
        const [action, userId] = String(rest || '').split(':');
        if (action !== 'timeout' || !userId) return;
        const perms = interaction.memberPermissions;
        if (!perms?.has(PermissionFlagsBits.ModerateMembers) && !perms?.has(PermissionFlagsBits.Administrator)) {
          return responses.replyError(interaction, 'You need the **Timeout Members** permission to use this button.');
        }
        if (!interaction.guild) return;
        const member = await interaction.guild.members.fetch(userId).catch(() => null);
        if (!member) return responses.replyError(interaction, 'That member is no longer in the server.');
        const hierarchy = ctx.permissions.checkBotHierarchy(interaction.guild, member);
        if (!hierarchy.ok) return responses.replyError(interaction, hierarchy.reason);
        await member.timeout(10 * 60 * 1000, `Automod panel: muted by ${interaction.user.tag}`);
        return responses.replySimple(
          interaction,
          `🔇 <@${userId}> was timed out for **10 minutes** by <@${interaction.user.id}>.`,
          { ephemeral: true },
        );
      } catch (err) {
        ctx.logger.warn('[automod] am: handler:', err?.message || err);
        return responses.replyError(interaction, 'That action failed.');
      }
    },
  },

  hooks: {
    async messageCreate(ctx, message) {
      try {
        return await service.handleMessageCreate(ctx, message);
      } catch (err) {
        ctx.logger.warn('[automod] messageCreate:', err?.message || err);
      }
    },
  },

  schedulerJobs: [
    {
      name: 'automod-sweep',
      intervalMs: 10 * 60 * 1000,
      run(ctx) {
        try {
          service.sweep();
        } catch (err) {
          ctx.logger.warn('[automod] sweep:', err?.message || err);
        }
      },
    },
  ],
};
