'use strict';

const { ApplicationCommandOptionType, ChannelType, EmbedBuilder } = require('discord.js');
const { respond, replyError } = require('../../core/responses');
const settings = require('../../core/settings');
const audit = require('../../core/audit');
const config = require('../../config');
const service = require('./service');

const SUB = ApplicationCommandOptionType.Subcommand;
const STR = ApplicationCommandOptionType.String;
const INT = ApplicationCommandOptionType.Integer;
const ROLE = ApplicationCommandOptionType.Role;
const CH = ApplicationCommandOptionType.Channel;

const TYPE_CHOICES = service.RULE_TYPES.map((t) => ({ name: t, value: t }));

const commands = [
  {
    name: 'automod',
    description: 'Configure Auto Moderation rules, exemptions and escalation.',
    requiredPerms: ['ManageGuild'],
    cooldown: 5,
    options: [
      { name: 'enable', description: 'Enable Auto Moderation for this server', type: SUB, options: [] },
      { name: 'disable', description: 'Disable Auto Moderation for this server', type: SUB, options: [] },
      {
        name: 'add',
        description: 'Create a new automod rule',
        type: SUB,
        options: [
          { name: 'name', description: 'Rule name', type: STR, required: true, maxLength: 50 },
          { name: 'type', description: 'What the rule detects', type: STR, required: true, choices: TYPE_CHOICES },
          {
            name: 'actions',
            description: 'Comma-separated actions: delete, warn, timeout, kick, alert',
            type: STR,
            required: true,
            maxLength: 100,
          },
          { name: 'threshold', description: 'Threshold (meaning depends on type)', type: INT, required: false, minValue: 1, maxValue: 1000 },
          { name: 'timeout_minutes', description: 'Timeout length when the timeout action is used', type: INT, required: false, minValue: 1, maxValue: 40320 },
          { name: 'words', description: 'blockedWords only: words separated by |', type: STR, required: false, maxLength: 1000 },
          { name: 'regex', description: 'regex only: regular expression source', type: STR, required: false, maxLength: 200 },
        ],
      },
      {
        name: 'remove',
        description: 'Delete an automod rule by name',
        type: SUB,
        options: [{ name: 'name', description: 'Rule name', type: STR, required: true, maxLength: 50 }],
      },
      { name: 'list', description: 'List all automod rules and their state', type: SUB, options: [] },
      {
        name: 'test',
        description: 'Check which rules would trigger on a text (no actions executed)',
        type: SUB,
        options: [{ name: 'text', description: 'Text to test', type: STR, required: true, maxLength: 500 }],
      },
      {
        name: 'exemptions',
        description: 'Guild-wide automod exemptions (roles/channels that bypass all rules)',
        type: SUB,
        options: [
          { name: 'exempt_role', description: 'Add an exempt role', type: ROLE, required: false },
          { name: 'unexempt_role', description: 'Remove an exempt role', type: ROLE, required: false },
          { name: 'exempt_channel', description: 'Add an exempt channel', type: CH, required: false, channel_types: [ChannelType.GuildText] },
          { name: 'unexempt_channel', description: 'Remove an exempt channel', type: CH, required: false, channel_types: [ChannelType.GuildText] },
        ],
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();
      const guildId = interaction.guildId;

      if (sub === 'enable' || sub === 'disable') {
        const modCfg = await settings.getModuleConfig(guildId, 'automod');
        const next = sub === 'enable';
        if (modCfg.enabled === next) {
          return replyError(interaction, `Auto Moderation is already **${next ? 'enabled' : 'disabled'}**.`);
        }
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const after = await settings.setModuleConfig(guildId, 'automod', { enabled: next });
        await audit.log(guildId, interaction.user.id, 'config.automod.enabled', 'module:automod', before, after);
        return respond(interaction, cmdCfg.responses.success, {}, `🤖 Auto Moderation is now **${next ? 'enabled' : 'disabled'}**.`);
      }

      if (sub === 'add') {
        const name = interaction.options.getString('name', true).trim();
        const type = interaction.options.getString('type', true);
        const actionsRaw = interaction.options.getString('actions', true);
        const threshold = interaction.options.getInteger('threshold');
        const timeoutMinutes = interaction.options.getInteger('timeout_minutes');
        const wordsRaw = interaction.options.getString('words');
        const regexRaw = interaction.options.getString('regex');

        const actions = actionsRaw
          .split(',')
          .map((a) => a.trim().toLowerCase())
          .filter((a) => service.ACTIONS.includes(a));
        if (!actions.length) {
          return replyError(interaction, '`actions` must be a comma-separated list from: **delete, warn, timeout, kick, alert**.');
        }
        if (!service.RULE_TYPES.includes(type)) return replyError(interaction, 'Unknown rule type.');

        let words = [];
        if (type === 'blockedWords') {
          if (!wordsRaw) return replyError(interaction, '`blockedWords` rules need the `words` option (words separated by `|`).');
          words = wordsRaw.split('|').map((w) => w.trim()).filter(Boolean).slice(0, 100);
          if (!words.length) return replyError(interaction, 'Provide at least one word separated by `|`.');
        }
        let regex = null;
        if (type === 'regex') {
          if (!regexRaw) return replyError(interaction, '`regex` rules need the `regex` option.');
          try {
            // eslint-disable-next-line no-new
            new RegExp(regexRaw, 'i');
          } catch (err) {
            return replyError(interaction, `Invalid regular expression: ${err?.message || err}`);
          }
          regex = regexRaw;
        }

        const existing = await ctx.db.automodRule.findFirst({ where: { guildId, name } });
        if (existing) return replyError(interaction, `A rule named "**${name}**" already exists in this server.`);
        const count = await ctx.db.automodRule.count({ where: { guildId } });
        if (count >= service.MAX_RULES_PER_GUILD) {
          return replyError(interaction, `This server already has the maximum of **${service.MAX_RULES_PER_GUILD}** rules.`);
        }

        await ctx.db.automodRule.create({
          data: {
            guildId,
            name,
            type,
            enabled: true,
            configJson: settings.stringify({ threshold: threshold ?? null, words, regex, timeoutMin: timeoutMinutes ?? null }),
            actionsJson: settings.stringify(actions),
            exemptionsJson: settings.stringify({ roleIds: [], channelIds: [], userIds: [] }),
          },
        });
        service.invalidateRules(guildId);
        await audit.log(guildId, interaction.user.id, 'config.automod.rule.add', 'module:automod', null, { name, type, actions });
        return respond(
          interaction,
          cmdCfg.responses.success,
          { name, type },
          `🤖 Rule **${name}** created — type: \`${type}\`, actions: **${actions.join(', ')}**.`,
        );
      }

      if (sub === 'remove') {
        const name = interaction.options.getString('name', true);
        const rule = await ctx.db.automodRule.findFirst({ where: { guildId, name } });
        if (!rule) return replyError(interaction, `No rule named "**${name}**" exists in this server.`);
        await ctx.db.automodRule.delete({ where: { id: rule.id } });
        service.invalidateRules(guildId);
        await audit.log(guildId, interaction.user.id, 'config.automod.rule.remove', 'module:automod', { name: rule.name, type: rule.type }, null);
        return respond(interaction, cmdCfg.responses.success, { name }, `🗑️ Rule **${name}** removed.`);
      }

      if (sub === 'list') {
        const rules = await ctx.db.automodRule.findMany({ where: { guildId }, orderBy: { id: 'asc' } });
        const lines = rules.map((r) => {
          const cfg = settings.parse(r.configJson, {});
          const actions = settings.parse(r.actionsJson, []);
          const bits = [r.enabled ? '🟢' : '🔴', `**${r.name}**`, `\`${r.type}\``];
          if (cfg.threshold) bits.push(`threshold ${cfg.threshold}`);
          if (cfg.timeoutMin) bits.push(`timeout ${cfg.timeoutMin}m`);
          if (Array.isArray(cfg.words) && cfg.words.length) bits.push(`${cfg.words.length} word(s)`);
          if (cfg.regex) bits.push(`regex \`/${String(cfg.regex).slice(0, 40)}/\``);
          bits.push(`actions: **${actions.join(', ') || 'none'}**`);
          return bits.join(' • ');
        });
        const embed = new EmbedBuilder()
          .setTitle('🤖 Automod rules')
          .setColor(config.embedColor)
          .setDescription(lines.length ? lines.slice(0, 25).join('\n').slice(0, 4000) : 'No rules yet — add one with `/automod add`.')
          .setFooter({ text: `${rules.filter((r) => r.enabled).length}/${rules.length} rule(s) enabled` });
        return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
      }

      if (sub === 'test') {
        const text = interaction.options.getString('text', true);
        const checks = await service.runDryChecks(ctx, guildId, text);
        const lines = checks.map(({ rule, result }) =>
          result.matched
            ? `🟢 **${rule.name}** (\`${rule.type}\`) — ${result.detail}`
            : `⚪ ${rule.name} (\`${rule.type}\`)${result.detail ? ` — ${result.detail}` : ''}`,
        );
        const embed = new EmbedBuilder()
          .setTitle('🧪 Automod test')
          .setColor(config.embedColor)
          .setDescription(
            lines.length
              ? lines.slice(0, 25).join('\n').slice(0, 4000)
              : 'No enabled rules in this server yet — add one with `/automod add`.',
          )
          .setFooter({ text: 'Dry run only — no actions were executed. Rate-based rules are skipped.' });
        return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
      }

      // exemptions
      const addRole = interaction.options.getRole('exempt_role');
      const removeRole = interaction.options.getRole('unexempt_role');
      const addChannel = interaction.options.getChannel('exempt_channel');
      const removeChannel = interaction.options.getChannel('unexempt_channel');
      if (!addRole && !removeRole && !addChannel && !removeChannel) {
        return replyError(interaction, 'Provide at least one option, e.g. `exempt_role:<role>` or `exempt_channel:<channel>`.');
      }
      const modCfg = await settings.getModuleConfig(guildId, 'automod');
      const roles = Array.isArray(modCfg.settings.exemptRoleIds) ? [...modCfg.settings.exemptRoleIds] : [];
      const channels = Array.isArray(modCfg.settings.exemptChannelIds) ? [...modCfg.settings.exemptChannelIds] : [];
      if (addRole && !roles.includes(addRole.id)) roles.push(addRole.id);
      if (removeRole) {
        const idx = roles.indexOf(removeRole.id);
        if (idx !== -1) roles.splice(idx, 1);
      }
      if (addChannel && !channels.includes(addChannel.id)) channels.push(addChannel.id);
      if (removeChannel) {
        const idx = channels.indexOf(removeChannel.id);
        if (idx !== -1) channels.splice(idx, 1);
      }
      const before = { enabled: modCfg.enabled, settings: modCfg.settings };
      const after = await settings.setModuleConfig(guildId, 'automod', { settings: { exemptRoleIds: roles, exemptChannelIds: channels } });
      service.invalidateConfig(guildId);
      await audit.log(guildId, interaction.user.id, 'config.automod.exemptions', 'module:automod', before, after);
      return respond(
        interaction,
        cmdCfg.responses.success,
        {},
        `🤖 Exemptions updated — **${roles.length}** exempt role(s), **${channels.length}** exempt channel(s). Administrators always bypass automod.`,
      );
    },
  },
];

module.exports = { commands };
