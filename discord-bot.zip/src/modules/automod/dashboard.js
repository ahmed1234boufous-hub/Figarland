'use strict';

const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonStyle, MessageFlags } = require('discord.js');
const settings = require('../../core/settings');
const audit = require('../../core/audit');
const config = require('../../config');
const service = require('./service');

/** Build the rules manager view (embed + select menu for toggling rules). */
async function rulesView(ctx, guildId, helpers) {
  const rules = await ctx.db.automodRule.findMany({ where: { guildId }, orderBy: { id: 'asc' } });
  const modCfg = await settings.getModuleConfig(guildId, 'automod');
  const embed = new EmbedBuilder()
    .setTitle('🤖 Automod — rules manager')
    .setColor(modCfg.enabled ? config.embedColor : config.errorColor)
    .setDescription(
      rules.length
        ? rules
            .map((r) => {
              const actions = settings.parse(r.actionsJson, []);
              return `${r.enabled ? '🟢' : '🔴'} \`#${r.id}\` **${r.name}** — \`${r.type}\` • ${actions.join(', ') || 'no actions'}`;
            })
            .join('\n')
            .slice(0, 4000)
        : 'No rules yet — add one with `/automod add`.',
    )
    .setFooter({ text: 'Select a rule to enable or disable it' });

  const components = [];
  if (rules.length) {
    components.push(
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(helpers.cid('automod', 'x:rulesel'))
          .setPlaceholder('Toggle a rule…')
          .addOptions(
            rules.slice(0, 25).map((r) => ({
              label: `${r.enabled ? 'ON' : 'OFF'} • ${r.name}`.slice(0, 100),
              description: `${r.type} • rule #${r.id}`.slice(0, 100),
              value: String(r.id),
            })),
          ),
      ),
    );
  }
  components.push(
    new ActionRowBuilder().addComponents(helpers.btn('◀ Back to /automod', ButtonStyle.Secondary, helpers.cid('automod', 'cmd', 'automod'))),
  );
  return { embeds: [embed], components, flags: MessageFlags.Ephemeral };
}

module.exports = {
  async summaryLines(guild, modCfg) {
    const [total, enabled] = await Promise.all([
      require('../../core/db').automodRule.count({ where: { guildId: guild.id } }),
      require('../../core/db').automodRule.count({ where: { guildId: guild.id, enabled: true } }),
    ]);
    return [
      ['Rules', `${total}`],
      ['Enabled rules', `${enabled}`],
      ['Alert channel', modCfg.settings?.alertChannel ? `<#${modCfg.settings.alertChannel}>` : '*(not set — Advanced)*'],
    ];
  },

  async extraCommandButtons(commandKey) {
    if (commandKey !== 'automod') return [];
    return [{ label: 'Rules manager', style: ButtonStyle.Primary, action: 'x:rules' }];
  },

  async handle({ interaction, ctx, action, helpers }) {
    if (action === 'rules') {
      return helpers.edit(interaction, await rulesView(ctx, interaction.guildId, helpers));
    }
    if (action === 'rulesel') {
      const id = parseInt(interaction.values?.[0] || '0', 10);
      const rule = id ? await ctx.db.automodRule.findUnique({ where: { id } }) : null;
      if (!rule || rule.guildId !== interaction.guildId) {
        return helpers.edit(interaction, await rulesView(ctx, interaction.guildId, helpers));
      }
      const before = { enabled: rule.enabled, name: rule.name };
      const after = await ctx.db.automodRule.update({ where: { id: rule.id }, data: { enabled: !rule.enabled } });
      service.invalidateRules(interaction.guildId);
      await audit.log(
        interaction.guildId,
        interaction.user.id,
        'config.automod.rule.toggle',
        'module:automod',
        before,
        { enabled: after.enabled, name: rule.name },
      );
      return helpers.edit(interaction, await rulesView(ctx, interaction.guildId, helpers));
    }
    return undefined;
  },
};
