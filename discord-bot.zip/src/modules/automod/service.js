'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} = require('discord.js');
const config = require('../../config');
const moderationService = require('../moderation/service');

/**
 * automod/service.js — rule evaluation engine, actions and escalation.
 *
 * Rules live in the AutomodRule table; guild-wide exemptions live in
 * ModuleConfig('automod').settings. Both are cached per guild for 30s.
 * The messageCreate hook returns false when the message was deleted so later
 * modules (XP, counting, ...) veto the message too.
 */

const RULE_TYPES = ['spam', 'mentionSpam', 'invites', 'links', 'caps', 'blockedWords', 'repeatedChars', 'emojiSpam', 'regex'];
const ACTIONS = ['delete', 'warn', 'timeout', 'kick', 'alert'];
const DEFAULT_THRESHOLDS = { spam: 5, mentionSpam: 5, caps: 10, emojiSpam: 8 };
const ESCALATION_TIMEOUT_MS = 10 * 60 * 1000;

const INVITE_RE = /discord\.gg\/|discord\.com\/invite\//i;
const LINK_RE = /https?:\/\//i;
const REPEATED_RE = /(.)\1{9,}/;
const EMOJI_RE = /\p{Extended_Pictographic}/gu;

const SPAM_WINDOW_MS = 5000;
const ESCALATION_WINDOW_MS = 60 * 60 * 1000;
const SWEEP_MIN_AGE_MS = 10 * 60 * 1000;
const CFG_TTL_MS = 30 * 1000;
const RULES_TTL_MS = 30 * 1000;
const MAX_RULES_PER_GUILD = 25;

const cfgCache = new Map(); // guildId -> { cfg, at }
const rulesCache = new Map(); // guildId -> { rules, at }
const msgBuffers = new Map(); // "guildId:userId" -> [{ t, len }]
const hitCounters = new Map(); // "guildId:userId" -> number[]

function safeJson(raw, fallback) {
  if (raw === null || raw === undefined) return fallback;
  try {
    const v = JSON.parse(raw);
    return v === null || v === undefined ? fallback : v;
  } catch {
    return fallback;
  }
}

function invalidateConfig(guildId) {
  cfgCache.delete(guildId);
}

function invalidateRules(guildId) {
  rulesCache.delete(guildId);
}

async function loadConfig(ctx, guildId) {
  const hit = cfgCache.get(guildId);
  if (hit && Date.now() - hit.at < CFG_TTL_MS) return hit.cfg;
  const cfg = await ctx.settings.getModuleConfig(guildId, 'automod');
  cfgCache.set(guildId, { cfg, at: Date.now() });
  return cfg;
}

/** Enabled rules for a guild in creation order, with parsed JSON columns. */
async function loadRules(ctx, guildId) {
  const hit = rulesCache.get(guildId);
  if (hit && Date.now() - hit.at < RULES_TTL_MS) return hit.rules;
  const rows = await ctx.db.automodRule.findMany({ where: { guildId, enabled: true }, orderBy: { id: 'asc' } });
  const rules = rows.map((r) => ({
    ...r,
    configJson: safeJson(r.configJson, {}),
    actionsJson: safeJson(r.actionsJson, []),
    exemptionsJson: safeJson(r.exemptionsJson, {}),
  }));
  rulesCache.set(guildId, { rules, at: Date.now() });
  return rules;
}

/** Sliding window helper: push value, prune entries older than windowMs, return the pruned array. */
function pushBuffer(map, key, value, windowMs) {
  const cutoff = Date.now() - windowMs;
  const arr = (map.get(key) || []).filter((e) => {
    const t = typeof e === 'number' ? e : e.t;
    return t >= cutoff;
  });
  arr.push(value);
  map.set(key, arr);
  return arr;
}

function sweep() {
  const msgCutoff = Date.now() - SWEEP_MIN_AGE_MS;
  const hitCutoff = Date.now() - ESCALATION_WINDOW_MS;
  for (const [key, arr] of msgBuffers) {
    const kept = arr.filter((e) => e.t >= msgCutoff);
    if (kept.length) msgBuffers.set(key, kept);
    else msgBuffers.delete(key);
  }
  for (const [key, arr] of hitCounters) {
    const kept = arr.filter((t) => t >= hitCutoff);
    if (kept.length) hitCounters.set(key, kept);
    else hitCounters.delete(key);
  }
}

// ─────────────────────────────── Evaluation ──────────────────────────────────

/**
 * Evaluate one rule against a message-like input.
 * @returns {{ matched: boolean, detail?: string }}
 */
function evaluateRule(rule, input) {
  const cfgJson = rule.configJson || {};
  const threshold = Number(cfgJson.threshold) || DEFAULT_THRESHOLDS[rule.type] || 5;
  const content = input.content || '';

  switch (rule.type) {
    case 'spam': {
      if (input.dry) return { matched: false, detail: 'rate-based rule (skipped in test)' };
      if ((input.spamCount || 0) > threshold) {
        return { matched: true, detail: `${input.spamCount} messages within 5s (threshold: ${threshold})` };
      }
      if ((input.spamChars || 0) > threshold * 300) {
        return { matched: true, detail: `${input.spamChars} characters within 5s (length burst)` };
      }
      return { matched: false };
    }
    case 'mentionSpam': {
      const m = input.mentionCount || 0;
      return m > threshold ? { matched: true, detail: `${m} mention(s) (threshold: ${threshold})` } : { matched: false };
    }
    case 'invites':
      return INVITE_RE.test(content) ? { matched: true, detail: 'server invite link detected' } : { matched: false };
    case 'links':
      return LINK_RE.test(content) ? { matched: true, detail: 'link detected' } : { matched: false };
    case 'caps': {
      if (content.length < threshold) return { matched: false };
      const letters = content.replace(/[^a-zA-Z]/g, '');
      if (!letters.length) return { matched: false };
      const upper = letters.replace(/[^A-Z]/g, '').length;
      const ratio = upper / letters.length;
      return ratio > 0.7 ? { matched: true, detail: `${Math.round(ratio * 100)}% uppercase` } : { matched: false };
    }
    case 'blockedWords': {
      const words = Array.isArray(cfgJson.words) ? cfgJson.words : [];
      const lower = content.toLowerCase();
      const hit = words.find((w) => w && lower.includes(String(w).toLowerCase()));
      return hit ? { matched: true, detail: `blocked word: "${String(hit).slice(0, 60)}"` } : { matched: false };
    }
    case 'repeatedChars': {
      const m = REPEATED_RE.exec(content);
      return m ? { matched: true, detail: `repeated pattern "${m[0].slice(0, 20)}"` } : { matched: false };
    }
    case 'emojiSpam': {
      const found = content.match(EMOJI_RE) || [];
      return found.length > threshold
        ? { matched: true, detail: `${found.length} emoji (threshold: ${threshold})` }
        : { matched: false };
    }
    case 'regex': {
      if (!cfgJson.regex) return { matched: false };
      let re;
      try {
        re = new RegExp(String(cfgJson.regex), 'i');
      } catch {
        return { matched: false, detail: 'stored regex is invalid (rule skipped)' };
      }
      const m = re.exec(content);
      return m ? { matched: true, detail: `matched /${String(cfgJson.regex).slice(0, 60)}/` } : { matched: false };
    }
    default:
      return { matched: false };
  }
}

/** Per-rule exemptions (rule.exemptionsJson: { roleIds, channelIds, userIds }). */
function isRuleExempt(rule, message, member) {
  const ex = rule.exemptionsJson || {};
  if (Array.isArray(ex.channelIds) && ex.channelIds.includes(message.channelId)) return true;
  if (Array.isArray(ex.userIds) && ex.userIds.includes(message.author.id)) return true;
  if (member && Array.isArray(ex.roleIds) && ex.roleIds.some((r) => member.roles.cache.has(r))) return true;
  return false;
}

/** Run all enabled rules in dry mode (used by /automod test). */
async function runDryChecks(ctx, guildId, text) {
  const rules = await loadRules(ctx, guildId);
  const input = { content: text, mentionCount: 0, spamCount: 0, spamChars: 0, dry: true };
  return rules.map((rule) => ({ rule, result: evaluateRule(rule, input) }));
}

// ─────────────────────────────── Actions ─────────────────────────────────────

function sendAutomodAlert(ctx, message, rule, modCfg, detail) {
  try {
    const channelId = modCfg.settings?.alertChannel;
    if (!channelId) return;
    const channel = message.guild.channels.cache.get(channelId);
    if (!channel || !channel.isTextBased?.()) return;
    const embed = new EmbedBuilder()
      .setTitle('🤖 Automod alert')
      .setColor(config.warnColor)
      .setTimestamp()
      .addFields(
        { name: 'Rule', value: `${rule.name} (${rule.type})`, inline: true },
        { name: 'User', value: `<@${message.author.id}> (${message.author.tag})`, inline: true },
        { name: 'Channel', value: `<#${message.channelId}>`, inline: true },
        { name: 'Trigger', value: String(detail?.detail || 'matched').slice(0, 1024) },
        { name: 'Actions', value: (rule.actionsJson || []).join(', ') || 'none', inline: true },
        { name: 'Content', value: message.content ? message.content.slice(0, 200) : '*(no text)*' },
      );
    if (message.url) embed.addFields({ name: 'Message', value: `[Jump to message](${message.url})`, inline: true });
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`am:timeout:${message.author.id}`).setLabel('Mute 10 minutes').setStyle(ButtonStyle.Danger),
    );
    channel.send({ embeds: [embed], components: [row] }).catch(() => {});
  } catch (err) {
    ctx.logger.warn('[automod] alert failed:', err?.message || err);
  }
}

/** Execute the actions of a matched rule. @returns {boolean} true when the message was deleted */
async function applyActions(ctx, message, rule, modCfg, result) {
  let veto = false;
  const reason = `Automod rule: ${rule.name}`;
  for (const action of rule.actionsJson || []) {
    switch (action) {
      case 'delete':
        await message.delete().catch(() => {});
        veto = true;
        break;
      case 'warn': {
        try {
          await moderationService.createCase({
            guildId: message.guild.id,
            type: 'automod-warn',
            targetUser: message.author,
            moderatorId: ctx.client.user.id,
            reason,
          });
          await message.member
            ?.send(`⚠️ You were warned by Auto Moderation in **${message.guild.name}** (${reason}).`)
            .catch(() => {});
        } catch (err) {
          ctx.logger.warn('[automod] warn failed:', err?.message || err);
        }
        break;
      }
      case 'timeout': {
        const member = message.member;
        if (!member) break;
        const hierarchy = ctx.permissions.checkBotHierarchy(message.guild, member);
        if (!hierarchy.ok || !ctx.permissions.botHas(message.guild, 'ModerateMembers')) break;
        const minutes = Number(rule.configJson?.timeoutMin) || 10;
        await member.timeout(minutes * 60 * 1000, reason).catch(() => {});
        break;
      }
      case 'kick': {
        const member = message.member;
        if (!member) break;
        const hierarchy = ctx.permissions.checkBotHierarchy(message.guild, member);
        if (!hierarchy.ok || !ctx.permissions.botHas(message.guild, 'KickMembers')) break;
        await member.kick(reason).catch(() => {});
        break;
      }
      case 'alert':
        sendAutomodAlert(ctx, message, rule, modCfg, result);
        break;
      default:
        break;
    }
  }
  return veto;
}

function sendEscalationAlert(ctx, message, modCfg, hits, action, line) {
  try {
    const channelId = modCfg.settings?.alertChannel;
    if (!channelId) return;
    const channel = message.guild.channels.cache.get(channelId);
    if (!channel || !channel.isTextBased?.()) return;
    const embed = new EmbedBuilder()
      .setTitle('🤖 Automod escalation')
      .setColor(config.errorColor)
      .setTimestamp()
      .addFields(
        { name: 'User', value: `<@${message.author.id}> (${message.author.tag})`, inline: true },
        { name: 'Hits', value: `**${hits}** in the last hour`, inline: true },
        { name: 'Channel', value: `<#${message.channelId}>`, inline: true },
        { name: 'Action applied', value: `**${action}** — ${line}`.slice(0, 1024) },
      );
    channel.send({ embeds: [embed] }).catch(() => {});
  } catch (err) {
    ctx.logger.warn('[automod] escalation alert failed:', err?.message || err);
  }
}

/** Count hits per guild:user (1h window); escalate when escalationAfter is reached. */
async function maybeEscalate(ctx, message, modCfg) {
  const s = modCfg.settings || {};
  const after = Number(s.escalationAfter) || 0;
  if (after <= 0) return;
  const action = String(s.escalationAction || 'timeout').toLowerCase();
  if (!ACTIONS.includes(action)) return;

  const key = `${message.guild.id}:${message.author.id}`;
  const hits = pushBuffer(hitCounters, key, Date.now(), ESCALATION_WINDOW_MS);
  if (hits.length < after) return;
  hitCounters.set(key, []); // reset the window after escalating

  const member = message.member;
  const reason = `Automod escalation: ${hits.length} hits in 1h`;
  let line = 'Alert only — no extra punishment.';
  try {
    if (action === 'delete') {
      await message.delete().catch(() => {});
      line = 'Message deleted.';
    } else if (action === 'warn') {
      await moderationService.createCase({
        guildId: message.guild.id,
        type: 'automod-warn',
        targetUser: message.author,
        moderatorId: ctx.client.user.id,
        reason,
      });
      line = 'Warning case created.';
      await member?.send(`⚠️ Auto Moderation in **${message.guild.name}** escalated: repeated rule violations.`).catch(() => {});
    } else if (action === 'timeout' && member) {
      const hierarchy = ctx.permissions.checkBotHierarchy(message.guild, member);
      if (hierarchy.ok && ctx.permissions.botHas(message.guild, 'ModerateMembers')) {
        await member.timeout(ESCALATION_TIMEOUT_MS, reason).catch(() => {});
        line = 'Timed out for 10 minutes.';
      } else {
        line = `Timeout skipped: ${hierarchy.reason || 'missing permission'}`;
      }
    } else if (action === 'kick' && member) {
      const hierarchy = ctx.permissions.checkBotHierarchy(message.guild, member);
      if (hierarchy.ok && ctx.permissions.botHas(message.guild, 'KickMembers')) {
        await member.kick(reason).catch(() => {});
        line = 'Member kicked.';
      } else {
        line = `Kick skipped: ${hierarchy.reason || 'missing permission'}`;
      }
    }
  } catch (err) {
    line = `Escalation action failed: ${err?.message || err}`;
  }
  sendEscalationAlert(ctx, message, modCfg, hits.length, action, line);
}

// ─────────────────────────────── Hook entry ──────────────────────────────────

/**
 * messageCreate hook body. Returns false when the message was deleted
 * (vetoes later modules such as leveling/counting); otherwise undefined.
 */
async function handleMessageCreate(ctx, message) {
  if (!message?.guild || message.author?.bot || message.system) return;
  const guild = message.guild;

  const modCfg = await loadConfig(ctx, guild.id).catch(() => null);
  if (!modCfg?.enabled) return;
  const s = modCfg.settings || {};
  if (Array.isArray(s.exemptChannelIds) && s.exemptChannelIds.includes(message.channelId)) return;

  const member = message.member;
  if (member?.permissions?.has(PermissionFlagsBits.Administrator)) return;
  if (member && Array.isArray(s.exemptRoleIds) && s.exemptRoleIds.some((r) => member.roles.cache.has(r))) return;

  const rules = await loadRules(ctx, guild.id).catch(() => []);
  if (!rules.length) return;

  const key = `${guild.id}:${message.author.id}`;
  const buffer = pushBuffer(msgBuffers, key, { t: Date.now(), len: (message.content || '').length }, SPAM_WINDOW_MS);
  const input = {
    content: message.content || '',
    mentionCount:
      (message.mentions?.users?.size || 0) +
      (message.mentions?.roles?.size || 0) +
      (message.mentions?.everyone ? 1 : 0),
    spamCount: buffer.length,
    spamChars: buffer.reduce((acc, e) => acc + (e.len || 0), 0),
    dry: false,
  };

  for (const rule of rules) {
    if (isRuleExempt(rule, message, member)) continue;
    const result = evaluateRule(rule, input);
    if (!result.matched) continue;
    let veto = false;
    try {
      veto = await applyActions(ctx, message, rule, modCfg, result);
    } catch (err) {
      ctx.logger.warn('[automod] actions failed:', err?.message || err);
    }
    try {
      await maybeEscalate(ctx, message, modCfg);
    } catch (err) {
      ctx.logger.warn('[automod] escalation failed:', err?.message || err);
    }
    return veto ? false : undefined;
  }
  return undefined;
}

module.exports = {
  RULE_TYPES,
  ACTIONS,
  DEFAULT_THRESHOLDS,
  MAX_RULES_PER_GUILD,
  invalidateConfig,
  invalidateRules,
  loadConfig,
  loadRules,
  evaluateRule,
  runDryChecks,
  handleMessageCreate,
  sweep,
};
