'use strict';

const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../../core/db');
const config = require('../../config');

/**
 * Suggestions service — suggestion embeds, polls, starboard plumbing and
 * reputation cooldowns. All Discord-facing helpers are defensive.
 */

const STATUS_COLORS = {
  pending: config.embedColor,
  approved: 0x57f287,
  denied: 0xed4245,
  considered: 0xfee75c,
};

const STATUS_LABELS = {
  pending: '🕓 Pending',
  approved: '✅ Approved',
  denied: '❌ Denied',
  considered: '🤔 Considering',
};

const NUM_EMOJIS = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

// ── Suggestions ──────────────────────────────────────────────────────────────

/** Build (or rebuild) the canonical suggestion embed. */
function suggestionEmbed({ number, content, authorText, status, staffNote }) {
  const embed = new EmbedBuilder()
    .setTitle(`💡 Suggestion #${number}`)
    .setColor(STATUS_COLORS[status] || config.embedColor)
    .setDescription(String(content || '').slice(0, 4000))
    .addFields(
      { name: 'Submitted by', value: authorText || 'Anonymous', inline: true },
      { name: 'Status', value: STATUS_LABELS[status] || status, inline: true },
    );
  if (staffNote) embed.addFields({ name: 'Staff note', value: String(staffNote).slice(0, 1024) });
  return embed;
}

// ── Polls ────────────────────────────────────────────────────────────────────

/** Parse '30m' / '1h' / '1d' / '2w' style durations. Returns ms or null. */
function parseDurationMs(raw) {
  const m = /^(\d+)\s*(s|m|h|d|w)$/i.exec(String(raw || '').trim());
  if (!m) return null;
  const n = parseInt(m[1], 10);
  if (!Number.isFinite(n) || n <= 0) return null;
  const mult = { s: 1000, m: 60000, h: 3600000, d: 86400000, w: 604800000 }[m[2].toLowerCase()];
  const ms = n * mult;
  if (ms < 10000 || ms > 30 * 86400000) return null;
  return ms;
}

function pollVotes(poll) {
  let votes = {};
  try {
    votes = JSON.parse(poll.votesJson || '{}') || {};
  } catch {
    votes = {};
  }
  return votes;
}

/** Render a poll embed (current counts, voters when not anonymous). */
function pollEmbed(poll) {
  let options = [];
  try {
    options = JSON.parse(poll.optionsJson || '[]') || [];
  } catch {
    options = [];
  }
  const votes = pollVotes(poll);
  const lines = options.map((text, i) => {
    const voters = Array.isArray(votes[String(i)]) ? votes[String(i)] : [];
    const emoji = NUM_EMOJIS[i] || `\`${i + 1}.\``;
    let line = `${emoji} ${text} — **${voters.length}** vote(s)`;
    if (!poll.anonymous && voters.length) {
      const shown = voters.slice(0, 15).map((id) => `<@${id}>`).join(' ');
      line += `\n└ ${shown}${voters.length > 15 ? ` *(+${voters.length - 15})*` : ''}`;
    }
    return line;
  });

  const embed = new EmbedBuilder()
    .setTitle(`📊 ${String(poll.question || '').slice(0, 250)}${poll.ended ? ' — Ended' : ''}`)
    .setColor(poll.ended ? config.successColor : config.embedColor)
    .setDescription(lines.join('\n').slice(0, 4000) || 'No options.')
    .addFields({ name: 'Ends', value: `<t:${Math.floor(new Date(poll.endAt).getTime() / 1000)}:R>`, inline: true })
    .setFooter({ text: `Poll #${poll.id} • ${poll.anonymous ? 'Anonymous' : 'Public'} votes` });
  return embed;
}

/** Vote buttons: up to 5 per action row, two rows for 6-10 options. */
function buildPollRows(pollId, options) {
  const rows = [];
  for (let i = 0; i < Math.min(options.length, 10); i += 5) {
    const chunk = options.slice(i, i + 5);
    rows.push(
      new ActionRowBuilder().addComponents(
        chunk.map((text, j) => {
          const idx = i + j;
          const button = new ButtonBuilder()
            .setCustomId(`sg:vote:${pollId}:${idx}`)
            .setLabel(String(text).slice(0, 80) || `Option ${idx + 1}`)
            .setStyle(ButtonStyle.Primary);
          if (NUM_EMOJIS[idx]) button.setEmoji(NUM_EMOJIS[idx]);
          return button;
        }),
      ),
    );
  }
  return rows;
}

// ── Poll ending (scheduler) ──────────────────────────────────────────────────

async function endDuePolls(ctx) {
  try {
    const due = await db.poll.findMany({ where: { ended: false, endAt: { lte: new Date() } }, take: 25 });
    for (const poll of due) {
      try {
        await endPoll(ctx, poll);
      } catch (err) {
        ctx.logger?.warn?.(`[polls-end] poll ${poll.id}: ${err?.message || err}`);
      }
    }
  } catch (err) {
    ctx.logger?.warn?.(`[polls-end] ${err?.message || err}`);
  }
}

async function endPoll(ctx, poll) {
  await db.poll.update({ where: { id: poll.id }, data: { ended: true } }).catch(() => {});

  let options = [];
  try {
    options = JSON.parse(poll.optionsJson || '[]') || [];
  } catch {
    options = [];
  }
  const votes = pollVotes(poll);
  const counts = options.map((_, i) => (Array.isArray(votes[String(i)]) ? votes[String(i)].length : 0));
  const max = Math.max(0, ...counts);
  const winners = counts.map((c, i) => ({ c, i })).filter((x) => x.c === max && max > 0).map((x) => x.i);

  const lines = options.map((text, i) => {
    const emoji = NUM_EMOJIS[i] || `\`${i + 1}.\``;
    return `${emoji} ${text} — **${counts[i]}** vote(s)${winners.includes(i) ? ' 🏆' : ''}`;
  });
  const winnerText = max > 0 ? winners.map((i) => `${NUM_EMOJIS[i] || `\`${i + 1}.\``} ${options[i]}`).join(' , ') : 'No votes were cast.';

  const embed = new EmbedBuilder()
    .setTitle(`📊 ${String(poll.question || '').slice(0, 250)} — Ended`)
    .setColor(config.successColor)
    .setDescription(lines.join('\n').slice(0, 3800) || 'No options.')
    .addFields({ name: 'Winner(s)', value: winnerText.slice(0, 1024) })
    .setFooter({ text: `Poll #${poll.id} • ${poll.anonymous ? 'Anonymous' : 'Public'} votes` });

  const channel = await ctx.client.channels.fetch(poll.channelId).catch(() => null);
  if (channel && poll.messageId) {
    const message = await channel.messages.fetch(poll.messageId).catch(() => null);
    if (message) await message.edit({ embeds: [embed], components: [] }).catch(() => {});
  }
  if (channel && typeof channel.send === 'function') {
    await channel
      .send({
        embeds: [
          new EmbedBuilder()
            .setTitle(`🏁 Poll ended: ${String(poll.question || '').slice(0, 200)}`)
            .setColor(config.successColor)
            .setDescription(`**Winner(s):** ${winnerText}`.slice(0, 4000)),
        ],
      })
      .catch(() => {});
  }
}

// ── Reputation cooldown (in-memory, per giver) ───────────────────────────────

const repCooldowns = new Map(); // `${guildId}:${userId}` -> unlock timestamp

/** Compact human duration for cooldown messages: "4m 30s". */
function fmtSeconds(seconds) {
  const s = Math.max(0, Math.ceil(seconds || 0));
  const m = Math.floor(s / 60);
  const rest = s % 60;
  if (m > 0) return `${m}m ${rest}s`;
  return `${s}s`;
}

function checkRepCooldown(key, seconds) {
  if (!seconds || seconds <= 0) return { ok: true, remaining: 0 };
  const now = Date.now();
  const until = repCooldowns.get(key) || 0;
  if (until > now) return { ok: false, remaining: Math.ceil((until - now) / 1000) };
  repCooldowns.set(key, now + seconds * 1000);
  return { ok: true, remaining: 0 };
}

setInterval(() => {
  const now = Date.now();
  for (const [k, v] of repCooldowns) if (v < now) repCooldowns.delete(k);
}, 10 * 60 * 1000).unref();

// ── Starboard ────────────────────────────────────────────────────────────────

const STAR = '⭐';

function starEmbed(message, content, stars) {
  const embed = new EmbedBuilder()
    .setAuthor({
      name: message.author?.tag || message.author?.username || 'Unknown author',
      ...(message.author?.displayAvatarURL?.({ size: 128, extension: 'png' }) ? { iconURL: message.author.displayAvatarURL({ size: 128, extension: 'png' }) } : {}),
    })
    .setDescription(content.content ? content.content.slice(0, 500) : '*no text content*')
    .setColor(config.embedColor)
    .addFields(
      { name: 'Channel', value: `<#${message.channelId}>`, inline: true },
      { name: 'Jump', value: `[Jump to message](${content.jumpUrl})`, inline: true },
    )
    .setFooter({ text: `${STAR} ${stars}` });
  if (content.imageUrl) embed.setImage(content.imageUrl);
  return embed;
}

/**
 * Shared handler for messageReactionAdd and messageReactionRemove.
 * Posts/updates/removes the starboard entry for a message. Never throws.
 */
async function handleStarReaction(ctx, reaction, user) {
  try {
    if (user?.bot) return; // bots never trigger starboard updates
    if (reaction?.emoji?.name !== STAR) return;
    if (reaction.partial) await reaction.fetch().catch(() => null);
    let message = reaction.message;
    if (!message) return;
    if (message.partial) message = await message.fetch().catch(() => null);
    if (!message?.guild) return;

    const guild = message.guild;
    const modCfg = await ctx.settings.getModuleConfig(guild.id, 'suggestions');
    if (!modCfg.enabled) return;
    const s = modCfg.settings;
    if (!s.starboardChannel) return;
    const threshold = Math.max(1, parseInt(s.starboardThreshold, 10) || 3);

    const stars = message.reactions?.cache?.get(STAR)?.count ?? 0;
    const entry = await db.starboardEntry
      .findUnique({ where: { guildId_originalMessageId: { guildId: guild.id, originalMessageId: message.id } } })
      .catch(() => null);
    const starboardChannel = guild.channels.cache.get(s.starboardChannel) || (await guild.channels.fetch(s.starboardChannel).catch(() => null));

    if (stars >= threshold) {
      const content = {
        authorId: message.author?.id || null,
        content: (message.content || '').slice(0, 500),
        imageUrl: message.attachments?.find?.((a) => a.width)?.url || null,
        jumpUrl: message.url,
      };
      if (!entry) {
        if (!starboardChannel || typeof starboardChannel.send !== 'function') return;
        const sent = await starboardChannel.send({ content: `${STAR} ${stars}`, embeds: [starEmbed(message, content, stars)] }).catch(() => null);
        await db.starboardEntry
          .create({
            data: {
              guildId: guild.id,
              channelId: message.channelId,
              originalMessageId: message.id,
              starboardMessageId: sent?.id || null,
              stars,
              contentJson: JSON.stringify(content),
            },
          })
          .catch(() => {});
      } else {
        await db.starboardEntry.update({ where: { id: entry.id }, data: { stars } }).catch(() => {});
        if (entry.starboardMessageId && starboardChannel) {
          const starMessage = await starboardChannel.messages.fetch(entry.starboardMessageId).catch(() => null);
          if (starMessage) await starMessage.edit({ content: `${STAR} ${stars}` }).catch(() => {});
        }
      }
      return;
    }

    // Below threshold: remove any existing entry + starboard message.
    if (entry) {
      if (entry.starboardMessageId && starboardChannel) {
        const starMessage = await starboardChannel.messages.fetch(entry.starboardMessageId).catch(() => null);
        if (starMessage) await starMessage.delete().catch(() => {});
      }
      await db.starboardEntry.delete({ where: { id: entry.id } }).catch(() => {});
    }
  } catch {
    /* starboard is strictly best-effort */
  }
}

module.exports = {
  STATUS_COLORS,
  STATUS_LABELS,
  NUM_EMOJIS,
  suggestionEmbed,
  parseDurationMs,
  pollVotes,
  pollEmbed,
  buildPollRows,
  endDuePolls,
  checkRepCooldown,
  fmtSeconds,
  handleStarReaction,
  STAR,
};
