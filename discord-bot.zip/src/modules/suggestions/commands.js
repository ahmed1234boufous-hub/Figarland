'use strict';

const { EmbedBuilder, ApplicationCommandOptionType, PermissionFlagsBits, ChannelType } = require('discord.js');
const { respond, replyError } = require('../../core/responses');
const settings = require('../../core/settings');
const audit = require('../../core/audit');
const config = require('../../config');
const db = require('../../core/db');
const service = require('./service');

const STR = ApplicationCommandOptionType.String;
const INT = ApplicationCommandOptionType.Integer;
const USER = ApplicationCommandOptionType.User;
const CH = ApplicationCommandOptionType.Channel;
const BOOL = ApplicationCommandOptionType.Boolean;

const STATUS_CHOICES = [
  { name: 'pending', value: 'pending' },
  { name: 'approved', value: 'approved' },
  { name: 'denied', value: 'denied' },
  { name: 'considered', value: 'considered' },
  { name: 'all', value: 'all' },
];

function trunc(text, n) {
  const s = String(text || '');
  return s.length > n ? `${s.slice(0, n - 1)}…` : s;
}

/** Manage Server permission OR membership in one of the review roles. */
function isReviewer(interaction, s) {
  if (interaction.member?.permissions?.has?.(PermissionFlagsBits.ManageGuild)) return true;
  const reviewRoles = Array.isArray(s.reviewRoleIds) ? s.reviewRoleIds : [];
  return interaction.member?.roles?.cache?.some((r) => reviewRoles.includes(r.id)) || false;
}

const commands = [
  {
    name: 'suggest',
    description: 'Submit, review and list server suggestions.',
    cooldown: 10,
    options: [
      {
        name: 'submit',
        description: 'Submit a new suggestion',
        type: 1,
        options: [
          { name: 'suggestion', description: 'What would you like to suggest?', type: STR, required: true, maxLength: 1000 },
          { name: 'anonymous', description: 'Hide your name on the suggestion?', type: BOOL, required: false },
        ],
      },
      {
        name: 'approve',
        description: 'Approve a suggestion (staff)',
        type: 1,
        options: [
          { name: 'id', description: 'Suggestion number', type: INT, required: true, minValue: 1 },
          { name: 'note', description: 'Optional staff note', type: STR, required: false, maxLength: 500 },
        ],
      },
      {
        name: 'deny',
        description: 'Deny a suggestion (staff)',
        type: 1,
        options: [
          { name: 'id', description: 'Suggestion number', type: INT, required: true, minValue: 1 },
          { name: 'note', description: 'Optional staff note', type: STR, required: false, maxLength: 500 },
        ],
      },
      {
        name: 'consider',
        description: 'Mark a suggestion as being considered (staff)',
        type: 1,
        options: [
          { name: 'id', description: 'Suggestion number', type: INT, required: true, minValue: 1 },
          { name: 'note', description: 'Optional staff note', type: STR, required: false, maxLength: 500 },
        ],
      },
      {
        name: 'list',
        description: 'List recent suggestions',
        type: 1,
        options: [{ name: 'status', description: 'Filter by status (default: pending)', type: STR, required: false, choices: STATUS_CHOICES }],
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();
      const modCfg = await settings.getModuleConfig(interaction.guildId, 'suggestions');
      const s = modCfg.settings;

      if (sub === 'submit') {
        const content = interaction.options.getString('suggestion', true).trim();
        const anonymous = interaction.options.getBoolean('anonymous') || false;
        if (!content) return replyError(interaction, 'Your suggestion cannot be empty.');
        if (anonymous && s.anonymousAllowed === false) {
          return replyError(interaction, 'Anonymous suggestions are disabled on this server.');
        }
        const channelId = s.suggestionChannel;
        if (!channelId) return replyError(interaction, 'No suggestion channel is configured — an admin can set it in **/suggestion-dashboard → Advanced**.');
        const channel = interaction.guild.channels.cache.get(channelId) || (await interaction.guild.channels.fetch(channelId).catch(() => null));
        if (!channel || typeof channel.send !== 'function') {
          return replyError(interaction, 'The configured suggestion channel no longer exists.');
        }

        await interaction.deferReply({ flags: 64 });
        const created = await db.suggestion.create({
          data: { guildId: interaction.guildId, userId: interaction.user.id, content: content.slice(0, 4000), status: 'pending' },
        });
        const embed = service.suggestionEmbed({
          number: created.id,
          content: created.content,
          authorText: anonymous ? 'Anonymous' : `<@${interaction.user.id}>`,
          status: 'pending',
        });
        const message = await channel.send({ embeds: [embed] }).catch(() => null);
        if (message) {
          await db.suggestion.update({ where: { id: created.id }, data: { messageId: message.id } }).catch(() => {});
          await message.react('👍').catch(() => {});
          await message.react('👎').catch(() => {});
        }
        return respond(
          interaction,
          cmdCfg.responses.success,
          { number: created.id, channel: `<#${channelId}>`, target: `<@${interaction.user.id}>` },
          message
            ? `💡 Suggestion **#${created.id}** was posted in <#${channelId}>.`
            : `💡 Suggestion **#${created.id}** was saved, but it could not be posted in <#${channelId}>.`,
        );
      }

      if (sub === 'approve' || sub === 'deny' || sub === 'consider') {
        if (!isReviewer(interaction, s)) {
          return replyError(interaction, 'You need the **Manage Server** permission or a review role to decide suggestions.');
        }
        const id = interaction.options.getInteger('id', true);
        const note = interaction.options.getString('note') || null;
        const sug = await db.suggestion.findFirst({ where: { id, guildId: interaction.guildId } });
        if (!sug) return replyError(interaction, `Suggestion **#${id}** was not found on this server.`);
        if (sug.status !== 'pending') {
          return replyError(interaction, `Suggestion **#${id}** was already decided (${sug.status}).`);
        }

        await interaction.deferReply({ flags: 64 });
        const status = sub === 'approve' ? 'approved' : sub === 'deny' ? 'denied' : 'considered';
        const updated = await db.suggestion.update({
          where: { id: sug.id },
          data: { status, staffNote: note, decidedById: interaction.user.id },
        });

        // Update the suggestion message in place (keeps anonymous authors hidden).
        let wasAnonymous = false;
        if (sug.messageId && s.suggestionChannel) {
          const channel =
            interaction.guild.channels.cache.get(s.suggestionChannel) ||
            (await interaction.guild.channels.fetch(s.suggestionChannel).catch(() => null));
          const message = channel ? await channel.messages.fetch(sug.messageId).catch(() => null) : null;
          if (message?.embeds?.length) {
            const old = message.embeds[0];
            const authorField = old.fields?.find((f) => f.name === 'Submitted by');
            wasAnonymous = (authorField?.value || '') === 'Anonymous';
            const embed = service.suggestionEmbed({
              number: updated.id,
              content: updated.content,
              authorText: authorField?.value || 'Anonymous',
              status,
              staffNote: note,
            });
            await message.edit({ embeds: [embed] }).catch(() => {});
          }
        }

        // Try to DM the author about the outcome (skip anonymous submitters).
        if (!wasAnonymous) {
          const author = await interaction.client.users.fetch(sug.userId).catch(() => null);
          if (author) {
            const dmText =
              `Your suggestion **#${updated.id}** in **${interaction.guild.name}** was ${status}.` +
              (note ? `\nStaff note: ${note}` : '');
            await author.send(dmText).catch(() => {});
          }
        }

        return respond(
          interaction,
          cmdCfg.responses.success,
          { number: id, status, reason: note || '' },
          `✅ Suggestion **#${id}** is now **${status}**${note ? ` — note: ${note}` : ''}.`,
        );
      }

      // list
      const status = interaction.options.getString('status') || 'pending';
      const where = { guildId: interaction.guildId };
      if (status !== 'all') where.status = status;
      const rows = await db.suggestion.findMany({ where, orderBy: { id: 'desc' }, take: 10 });
      const lines = rows.map((r) => `\`#${r.id}\` ${service.STATUS_LABELS[r.status] || r.status} — ${trunc(r.content, 100)}`);
      const embed = new EmbedBuilder()
        .setTitle(`💡 Suggestions — ${status}`)
        .setColor(config.embedColor)
        .setDescription(lines.join('\n') || 'No suggestions found for this filter.')
        .setFooter({ text: `Showing ${rows.length} most recent • details with /suggest list` });
      return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
    },
  },
  {
    name: 'poll',
    description: 'Create a reaction-style poll with clickable vote buttons.',
    cooldown: 5,
    options: [
      { name: 'question', description: 'Poll question', type: STR, required: true, maxLength: 250 },
      { name: 'options', description: 'Poll options separated by | (2-10)', type: STR, required: true },
      { name: 'duration', description: "How long it runs, e.g. 30m, 1h, 1d, 1w", type: STR, required: true },
      { name: 'anonymous', description: 'Hide who voted for what?', type: BOOL, required: false },
    ],
    async run(ctx, interaction, cmdCfg) {
      const question = interaction.options.getString('question', true).trim();
      const anonymous = interaction.options.getBoolean('anonymous') || false;
      const options = interaction.options
        .getString('options', true)
        .split('|')
        .map((o) => o.trim())
        .filter(Boolean);
      if (options.length < 2) return replyError(interaction, 'Provide at least two options separated by `|`.');
      if (options.length > 10) return replyError(interaction, 'A poll supports at most **10** options.');
      const durationMs = service.parseDurationMs(interaction.options.getString('duration', true));
      if (!durationMs) return replyError(interaction, 'Invalid duration — use formats like `30m`, `1h`, `1d` or `1w` (10 minutes to 30 days).');
      if (!interaction.channel || typeof interaction.channel.send !== 'function') {
        return replyError(interaction, 'Polls can only be created in regular text channels.');
      }

      await interaction.deferReply({ flags: 64 });
      const endAt = new Date(Date.now() + durationMs);
      const poll = await db.poll.create({
        data: {
          guildId: interaction.guildId,
          channelId: interaction.channelId,
          messageId: '',
          question: question.slice(0, 250),
          optionsJson: JSON.stringify(options.map((o) => o.slice(0, 100))),
          votesJson: '{}',
          endAt,
          anonymous,
          createdById: interaction.user.id,
        },
      });
      const embed = service.pollEmbed(poll);
      const rows = service.buildPollRows(poll.id, options);
      const message = await interaction.channel.send({ embeds: [embed], components: rows }).catch(() => null);
      if (message) {
        await db.poll.update({ where: { id: poll.id }, data: { messageId: message.id } }).catch(() => {});
      }
      return respond(
        interaction,
        cmdCfg.responses.success,
        { number: poll.id, duration: interaction.options.getString('duration', true) },
        `📊 Poll **#${poll.id}** created — ends <t:${Math.floor(endAt.getTime() / 1000)}:R>.`,
      );
    },
  },
  {
    name: 'rep',
    description: 'Give reputation to helpful members or view the leaderboard.',
    cooldown: 3,
    options: [
      {
        name: 'give',
        description: 'Give +1 reputation to a member',
        type: 1,
        options: [{ name: 'user', description: 'Member to rep', type: USER, required: true }],
      },
      { name: 'leaderboard', description: 'Show the reputation leaderboard', type: 1, options: [] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();
      const modCfg = await settings.getModuleConfig(interaction.guildId, 'suggestions');
      const s = modCfg.settings;

      if (sub === 'give') {
        const target = interaction.options.getUser('user', true);
        if (target.bot) return replyError(interaction, 'You cannot give reputation to bots.');
        if (target.id === interaction.user.id) return replyError(interaction, 'You cannot give reputation to yourself.');

        const cooldownMinutes = Math.max(0, parseInt(s.repCooldownMinutes, 10) || 0);
        const cd = service.checkRepCooldown(`${interaction.guildId}:${interaction.user.id}`, cooldownMinutes * 60);
        if (!cd.ok) {
          return replyError(interaction, `You can give reputation again in **${service.fmtSeconds(cd.remaining)}**.`);
        }

        const row = await db.repUser.upsert({
          where: { guildId_userId: { guildId: interaction.guildId, userId: target.id } },
          create: { guildId: interaction.guildId, userId: target.id, reps: 1, lastGivenAt: new Date() },
          update: { reps: { increment: 1 }, lastGivenAt: new Date() },
        });
        return respond(
          interaction,
          cmdCfg.responses.success,
          { target: `<@${target.id}>`, amount: 1 },
          `⭐ Gave +1 rep to <@${target.id}> — they now have **${row.reps}** rep.`,
        );
      }

      const top = await db.repUser.findMany({ where: { guildId: interaction.guildId }, orderBy: { reps: 'desc' }, take: 10 });
      const medals = ['🥇', '🥈', '🥉'];
      const lines = top.map((r, i) => `${medals[i] || `**${i + 1}.**`} <@${r.userId}> — ${r.reps} rep`);
      const embed = new EmbedBuilder()
        .setTitle('🌟 Reputation leaderboard')
        .setColor(config.embedColor)
        .setDescription(lines.join('\n') || 'No reputation given yet — thank someone with `/rep give`!')
        .setFooter({ text: 'Server rankings • 10 shown' });
      return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
    },
  },
  {
    name: 'starboard',
    description: 'Configure the starboard that reposts starred messages.',
    requiredPerms: ['ManageGuild'],
    cooldown: 3,
    options: [
      {
        name: 'set',
        description: 'Set or update the starboard',
        type: 1,
        options: [
          { name: 'channel', description: 'Channel where starred messages are reposted', type: CH, required: true },
          { name: 'threshold', description: 'Stars needed to hit the starboard (default 3)', type: INT, required: false, minValue: 1, maxValue: 50 },
        ],
      },
      { name: 'disable', description: 'Disable the starboard', type: 1, options: [] },
      { name: 'info', description: 'Show the current starboard configuration', type: 1, options: [] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();
      const modCfg = await settings.getModuleConfig(interaction.guildId, 'suggestions');
      const s = modCfg.settings;

      if (sub === 'set') {
        const channel = interaction.options.getChannel('channel', true);
        if (channel.type !== ChannelType.GuildText) return replyError(interaction, 'Pick a regular text channel for the starboard.');
        const threshold = Math.max(1, Math.min(50, interaction.options.getInteger('threshold') || 3));
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const next = await settings.setModuleConfig(interaction.guildId, 'suggestions', {
          settings: { starboardChannel: channel.id, starboardThreshold: threshold },
        });
        await audit.log(interaction.guildId, interaction.user.id, 'config.starboard.set', 'module:suggestions', before, next);
        return respond(
          interaction,
          cmdCfg.responses.success,
          { channel: `<#${channel.id}>`, amount: threshold },
          `⭐ Starboard set to <#${channel.id}> — a message needs **${threshold}** stars to appear.`,
        );
      }

      if (sub === 'disable') {
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const next = await settings.setModuleConfig(interaction.guildId, 'suggestions', {
          settings: { starboardChannel: null, starboardThreshold: 3 },
        });
        await audit.log(interaction.guildId, interaction.user.id, 'config.starboard.disable', 'module:suggestions', before, next);
        return respond(interaction, cmdCfg.responses.success, {}, '⭐ Starboard disabled — existing starboard entries stay in place.');
      }

      const embed = new EmbedBuilder()
        .setTitle('⭐ Starboard configuration')
        .setColor(config.embedColor)
        .addFields(
          { name: 'Channel', value: s.starboardChannel ? `<#${s.starboardChannel}>` : '*(disabled)*', inline: true },
          { name: 'Threshold', value: `${s.starboardThreshold ?? 3} stars`, inline: true },
        )
        .setFooter({ text: 'Reactions with ⭐ count towards the starboard' });
      return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
    },
  },
];

module.exports = { commands, isReviewer };
