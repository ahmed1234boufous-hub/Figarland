'use strict';

const { commands } = require('./commands');
const service = require('./service');
const dashboard = require('./dashboard');

module.exports = {
  key: 'suggestions',
  name: 'Suggestions & Community',
  emoji: '💡',
  dashboardCommandName: 'suggestion-dashboard',

  settingsSchema: [
    { key: 'suggestionChannel', label: 'Suggestion channel', type: 'channel', desc: 'Where submitted suggestions are posted.' },
    { key: 'reviewRoleIds', label: 'Review roles', type: 'roles', desc: 'Members with these roles can approve/deny/consider suggestions.' },
    { key: 'anonymousAllowed', label: 'Allow anonymous', type: 'boolean', desc: 'Whether anonymous submissions are permitted.' },
    { key: 'repCooldownMinutes', label: 'Rep cooldown (minutes)', type: 'number', desc: 'How often one member can give reputation.' },
    { key: 'starboardChannel', label: 'Starboard channel', type: 'channel', desc: 'Where starred messages are reposted (also /starboard set).' },
    { key: 'starboardThreshold', label: 'Starboard threshold', type: 'number', desc: 'Stars needed for a message to hit the starboard.' },
  ],

  defaults: {
    enabled: true,
    settings: {
      suggestionChannel: null,
      reviewRoleIds: [],
      anonymousAllowed: true,
      repCooldownMinutes: 60,
      starboardChannel: null,
      starboardThreshold: 3,
      dashboardRoles: [],
    },
    commands: {
      suggest: { cooldown: 10, responses: { success: { text: '', ephemeral: true } } },
      poll: { cooldown: 5, responses: { success: { text: '', ephemeral: true } } },
      rep: { cooldown: 3, responses: { success: { text: '', ephemeral: true } } },
      starboard: { cooldown: 3, responses: { success: { text: '', ephemeral: true } } },
    },
  },

  commands,

  dashboard,

  componentHandlers: {
    'sg:': async (ctx, interaction, rest) => {
      try {
        const [action, pollIdRaw, idxRaw] = (rest || '').split(':');
        if (action !== 'vote') return;
        const pollId = parseInt(pollIdRaw, 10);
        const idx = parseInt(idxRaw, 10);
        if (!Number.isFinite(pollId) || !Number.isFinite(idx)) return;

        const poll = await ctx.db.poll.findUnique({ where: { id: pollId } });
        if (!poll || poll.guildId !== interaction.guildId) return;
        if (poll.ended || new Date(poll.endAt).getTime() <= Date.now()) {
          return ctx.responses.replyError(interaction, 'This poll has already ended.');
        }

        let options = [];
        try {
          options = JSON.parse(poll.optionsJson || '[]') || [];
        } catch {
          options = [];
        }
        if (idx < 0 || idx >= options.length) return;

        // Single-choice toggle: remove the voter from every bucket, then add
        // them to the clicked option unless they had already selected it.
        const votes = service.pollVotes(poll);
        for (let i = 0; i < options.length; i += 1) {
          if (!Array.isArray(votes[String(i)])) votes[String(i)] = [];
        }
        const chosen = String(idx);
        const had = votes[chosen].includes(interaction.user.id);
        for (const key of Object.keys(votes)) {
          votes[key] = votes[key].filter((id) => id !== interaction.user.id);
        }
        if (!had) votes[chosen].push(interaction.user.id);

        await ctx.db.poll.update({ where: { id: poll.id }, data: { votesJson: JSON.stringify(votes) } }).catch(() => {});
        const updated = { ...poll, votesJson: JSON.stringify(votes), ended: false };
        const embed = service.pollEmbed(updated);
        await interaction.update({ embeds: [embed], components: interaction.message.components }).catch(() => {});
      } catch (err) {
        ctx.logger.warn(`[suggestions] component failed: ${err?.message || err}`);
      }
    },
  },

  modalHandlers: {},

  hooks: {
    messageReactionAdd(ctx, reaction, user) {
      return service.handleStarReaction(ctx, reaction, user);
    },
    messageReactionRemove(ctx, reaction, user) {
      return service.handleStarReaction(ctx, reaction, user);
    },
  },

  schedulerJobs: [
    {
      name: 'polls-end',
      intervalMs: 30000,
      run: async (ctx) => {
        await service.endDuePolls(ctx);
      },
    },
  ],
};
