'use strict';

const db = require('../../core/db');

module.exports = {
  async summaryLines(guild, modCfg) {
    const s = modCfg.settings || {};
    const pending = await db.suggestion.count({ where: { guildId: guild.id, status: 'pending' } });
    return [
      ['Suggestion channel', s.suggestionChannel ? `<#${s.suggestionChannel}>` : '*(not set — Advanced)*'],
      ['Pending suggestions', `${pending}`],
      [
        'Starboard',
        s.starboardChannel
          ? `<#${s.starboardChannel}> • ${s.starboardThreshold ?? 3} stars`
          : '*(disabled)*',
      ],
    ];
  },
};
