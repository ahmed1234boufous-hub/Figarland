'use strict';

const {
  AuditLogEvent,
  ChannelType,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const config = require('../../config');

/**
 * security/service.js — anti-nuke detection engine and anti-raid helpers.
 *
 * Detection: destructive gateway events are matched against fresh audit log
 * entries to find the responsible actor. Every detected destructive action is
 * persisted as a SecurityEvent row; when a per-event sliding window crosses
 * its threshold the configured action is executed and an alert embed is sent.
 */

const EVENTS = ['channelDelete', 'roleDelete', 'banAdd', 'kickAdd', 'webhookCreate'];
const ACTIONS = ['alert', 'quarantine', 'timeout', 'kick', 'ban'];

const AUDIT_TYPES = {
  channelDelete: AuditLogEvent.ChannelDelete,
  roleDelete: AuditLogEvent.RoleDelete,
  banAdd: AuditLogEvent.MemberBanAdd,
  kickAdd: AuditLogEvent.MemberKick,
  webhookCreate: AuditLogEvent.WebhookCreate,
};

const EVENT_LABELS = {
  channelDelete: 'Channel deleted',
  roleDelete: 'Role deleted',
  banAdd: 'Member banned',
  kickAdd: 'Member kicked',
  webhookCreate: 'Webhook created',
};

const CFG_TTL_MS = 10 * 1000;
const AUDIT_FRESHNESS_MS = 60 * 1000;
const SWEEP_MIN_AGE_MS = 10 * 60 * 1000;
const MAX_TIMEOUT_MS = 28 * 24 * 60 * 60 * 1000; // Discord hard limit

const cfgCache = new Map(); // guildId -> { cfg, at }
const windows = new Map(); // "guildId:actorId:event" -> number[] (timestamps)
const joinBuffer = new Map(); // guildId -> number[] (join timestamps)

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function invalidateConfig(guildId) {
  cfgCache.delete(guildId);
}

async function getCfg(ctx, guildId) {
  const hit = cfgCache.get(guildId);
  if (hit && Date.now() - hit.at < CFG_TTL_MS) return hit.cfg;
  const cfg = await ctx.settings.getModuleConfig(guildId, 'security');
  cfgCache.set(guildId, { cfg, at: Date.now() });
  return cfg;
}

// ─────────────────────────────── Windows ─────────────────────────────────────

function recordWindow(guildId, actorId, event, timestamp, windowSec) {
  const key = `${guildId}:${actorId}:${event}`;
  const cutoff = Date.now() - Math.max(1, windowSec) * 1000;
  const arr = (windows.get(key) || []).filter((t) => t >= cutoff);
  arr.push(timestamp || Date.now());
  windows.set(key, arr);
  return { count: arr.length };
}

function recordJoin(guildId, windowMs) {
  const now = Date.now();
  const arr = (joinBuffer.get(guildId) || []).filter((t) => now - t < windowMs);
  arr.push(now);
  joinBuffer.set(guildId, arr);
  return arr;
}

function sweep() {
  const cutoff = Date.now() - SWEEP_MIN_AGE_MS;
  for (const [key, arr] of windows) {
    const kept = arr.filter((t) => t >= cutoff);
    if (kept.length) windows.set(key, kept);
    else windows.delete(key);
  }
  for (const [key, arr] of joinBuffer) {
    const kept = arr.filter((t) => t >= cutoff);
    if (kept.length) joinBuffer.set(key, kept);
    else joinBuffer.delete(key);
  }
}

// ─────────────────────────────── Detection ───────────────────────────────────

/** Find the freshest audit entry of `type` whose target matches targetId. */
async function findAuditEntry(guild, type, targetId) {
  const fetched = await guild.fetchAuditLogs({ type, limit: 5 }).catch(() => null);
  if (!fetched) return null;
  const freshCutoff = Date.now() - AUDIT_FRESHNESS_MS;
  for (const entry of fetched.entries.values()) {
    if ((entry.createdTimestamp || 0) < freshCutoff) continue;
    const tid = entry.target?.id ?? entry.targetId ?? null;
    if (!targetId) return entry;
    if (tid && String(tid) === String(targetId)) return entry;
  }
  return null;
}

/** Is the actor protected from being acted upon? (whitelist / exempt roles / owner / bot) */
function isProtectedActor(cfg, guild, executorId, member) {
  if (!executorId) return true;
  if (executorId === guild.client.user.id) return true;
  if (executorId === guild.ownerId) return true;
  if ((cfg.settings.whitelistUserIds || []).includes(executorId)) return true;
  if (member && (cfg.settings.exemptRoleIds || []).some((r) => member.roles.cache.has(r))) return true;
  return false;
}

async function persistSecurityEvent(ctx, guildId, userId, type) {
  try {
    await ctx.db.securityEvent.create({ data: { guildId, userId, type } });
  } catch (err) {
    ctx.logger.warn('[security] could not persist SecurityEvent:', err?.message || err);
  }
}

/**
 * Full anti-nuke pipeline for one destructive event.
 * @param {string} event one of EVENTS
 * @param {string|null} targetId id of the destroyed entity (channel/role/user/webhook)
 */
async function detectAndEnforce(ctx, guild, event, targetId) {
  if (!guild?.id || !EVENTS.includes(event)) return;
  const cfg = await getCfg(ctx, guild.id).catch(() => null);
  if (!cfg?.enabled || cfg.settings.antiNukeEnabled === false) return;
  const conf = (cfg.settings.antiNuke || {})[event];
  if (!conf || !conf.count) return;

  // The audit log can trail the gateway event by a moment — try twice.
  let entry = null;
  for (const delay of [0, 1500]) {
    if (delay) await sleep(delay);
    entry = await findAuditEntry(guild, AUDIT_TYPES[event], targetId);
    if (entry) break;
  }
  if (!entry) return;

  const executorId = entry.executorId;
  if (isProtectedActor(cfg, guild, executorId, null)) return;
  const member = await guild.members.fetch(executorId).catch(() => null);
  if (isProtectedActor(cfg, guild, executorId, member)) return;

  await persistSecurityEvent(ctx, guild.id, executorId, event);

  const { count } = recordWindow(guild.id, executorId, event, entry.createdTimestamp, conf.windowSec);
  if (count !== conf.count) return; // act exactly at the threshold crossing
  await executeAction(ctx, guild, event, executorId, member, conf, count);
}

/** Kick detection on member removal (kickAdd has no dedicated gateway event). */
async function detectKick(ctx, member) {
  if (!member?.guild) return;
  await detectAndEnforce(ctx, member.guild, 'kickAdd', member.id);
}

// ─────────────────────────────── Actions ─────────────────────────────────────

async function performAction(ctx, guild, event, member, executorId, action) {
  const reason = `Anti-nuke: ${EVENT_LABELS[event] || event} threshold exceeded`;
  switch (action) {
    case 'alert':
      return 'Alert only — no automatic punishment was applied.';
    case 'quarantine': {
      if (!member) return 'Could not quarantine — the actor already left the server.';
      const hierarchy = ctx.permissions.checkBotHierarchy(guild, member);
      if (!hierarchy.ok) return `Could not quarantine: ${hierarchy.reason}`;
      if (!ctx.permissions.botHas(guild, 'ManageRoles', 'ModerateMembers')) {
        return 'Could not quarantine — I lack **Manage Roles** and/or **Timeout Members**.';
      }
      const me = guild.members.me;
      const removable = [...member.roles.cache.values()]
        .filter((r) => !r.managed && r.id !== guild.id && r.position < me.roles.highest.position)
        .map((r) => r.id);
      let stripped = 0;
      if (removable.length) {
        try {
          await member.roles.remove(removable, reason);
          stripped = removable.length;
        } catch (err) {
          return `Quarantine partially failed while stripping roles: ${err?.message || err}`;
        }
      }
      await member.timeout(60 * 60 * 1000, reason).catch(() => {});
      return `Quarantined <@${executorId}> — stripped **${stripped}** role(s) + **1h** timeout.`;
    }
    case 'timeout': {
      if (!member) return 'Could not timeout — the actor already left the server.';
      const hierarchy = ctx.permissions.checkBotHierarchy(guild, member);
      if (!hierarchy.ok) return `Could not timeout: ${hierarchy.reason}`;
      if (!ctx.permissions.botHas(guild, 'ModerateMembers')) return 'Could not timeout — I lack **Timeout Members**.';
      await member.timeout(MAX_TIMEOUT_MS, reason).catch((err) => `Timeout failed: ${err?.message || err}`);
      return `Timed out <@${executorId}> for **28 days** (maximum).`;
    }
    case 'kick': {
      if (!member) return 'Could not kick — the actor already left the server.';
      const hierarchy = ctx.permissions.checkBotHierarchy(guild, member);
      if (!hierarchy.ok) return `Could not kick: ${hierarchy.reason}`;
      if (!ctx.permissions.botHas(guild, 'KickMembers')) return 'Could not kick — I lack **Kick Members**.';
      await member.kick(reason).catch((err) => `Kick failed: ${err?.message || err}`);
      return `Kicked <@${executorId}>.`;
    }
    case 'ban': {
      const hierarchy = member ? ctx.permissions.checkBotHierarchy(guild, member) : { ok: true };
      if (!hierarchy.ok) return `Could not ban: ${hierarchy.reason}`;
      if (!ctx.permissions.botHas(guild, 'BanMembers')) return 'Could not ban — I lack **Ban Members**.';
      await guild.members.ban(executorId, { reason }).catch((err) => `Ban failed: ${err?.message || err}`);
      return `Banned <@${executorId}>.`;
    }
    default:
      return `Unknown action "${action}" — no punishment applied.`;
  }
}

async function executeAction(ctx, guild, event, executorId, member, conf, count) {
  const embed = new EmbedBuilder()
    .setTitle('☢️ Anti-nuke triggered')
    .setColor(config.errorColor)
    .setDescription('Destructive activity was detected faster than the configured threshold allows.')
    .setTimestamp()
    .addFields(
      { name: 'Event', value: EVENT_LABELS[event] || event, inline: true },
      { name: 'Actor', value: `<@${executorId}>${member ? ` (${member.user.tag})` : ''}`, inline: true },
      {
        name: 'Detection',
        value: `**${count}** action(s) within **${conf.windowSec}s** — threshold: **${conf.count}**`,
        inline: false,
      },
    );
  let line = 'No response executed.';
  try {
    line = await performAction(ctx, guild, event, member, executorId, conf.action);
  } catch (err) {
    line = `Action failed: ${err?.message || err}`;
  }
  embed.addFields({ name: 'Automatic response', value: String(line).slice(0, 1024) });
  const cfg = await getCfg(ctx, guild.id).catch(() => null);
  if (cfg) sendAlert(ctx, guild, cfg, embed);
}

// ─────────────────────────────── Alerts ──────────────────────────────────────

function resolveAlertChannel(guild, cfg) {
  const id = cfg.settings?.alertChannel;
  return (id && guild.channels.cache.get(id)) || guild.systemChannel || guild.publicUpdatesChannel || null;
}

function sendAlert(ctx, guild, cfg, embed, extraRows) {
  const channel = resolveAlertChannel(guild, cfg);
  if (!channel) return;
  const payload = { embeds: [embed] };
  if (extraRows?.length) payload.components = extraRows;
  channel.send(payload).catch(() => {});
}

// ──────────────────────────── Anti-raid & joins ──────────────────────────────

/**
 * Handle a member join: min account age gate + raid spike detection.
 * @returns {boolean} true when the member was kicked (caller may veto later hooks)
 */
async function handleJoin(ctx, member) {
  if (!member?.guild || member.user?.bot) return false;
  const guild = member.guild;
  const cfg = await getCfg(ctx, guild.id).catch(() => null);
  if (!cfg?.enabled) return false;
  const s = cfg.settings || {};

  // Minimum account age gate (independent of raid monitoring being enabled)
  const minDays = Number(s.raid?.minAccountAgeDays) || 0;
  if (minDays > 0) {
    const ageMs = Date.now() - member.user.createdTimestamp;
    if (ageMs < minDays * 24 * 60 * 60 * 1000) {
      await persistSecurityEvent(ctx, guild.id, member.id, 'accountAgeKick');
      await member.kick(`Account younger than ${minDays} day(s) - anti-raid gate`).catch(() => {});
      const embed = new EmbedBuilder()
        .setTitle('⛔ Account age gate')
        .setColor(config.warnColor)
        .setTimestamp()
        .addFields(
          { name: 'Member', value: `<@${member.id}> (${member.user.tag})`, inline: true },
          { name: 'Account age', value: `${Math.floor(ageMs / 86400000)} day(s) - minimum: ${minDays}`, inline: true },
          { name: 'Action', value: 'Member was kicked on join.' },
        );
      sendAlert(ctx, guild, cfg, embed);
      return true;
    }
  }

  if (s.raidEnabled === false) return false;
  const raid = s.raid || {};
  const windowSec = Number(raid.windowSec) || 60;
  const threshold = Number(raid.joinThreshold) || 8;
  const joins = recordJoin(guild.id, windowSec * 1000);
  if (joins.length !== threshold) return false; // alert exactly at the threshold crossing

  const embed = new EmbedBuilder()
    .setTitle('🚨 Raid spike detected')
    .setColor(config.errorColor)
    .setTimestamp()
    .addFields(
      {
        name: 'Joins',
        value: `**${joins.length}** members within **${windowSec}s** (threshold: **${threshold}**)`,
        inline: false,
      },
      { name: 'Member count', value: `${guild.memberCount}`, inline: true },
      {
        name: 'Lockdown',
        value: s.lockdownActive ? 'Already active' : 'Use the button below or `/antiraid lockdown`',
        inline: true,
      },
    );
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('sec:lockdown').setLabel('Lock down server').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('sec:unlock').setLabel('Unlock').setStyle(ButtonStyle.Secondary),
  );

  if (raid.autoLockdown && !s.lockdownActive) {
    const res = await applyLockdown(ctx, guild, 'server');
    if (res.ok) {
      try {
        await ctx.settings.setModuleSetting(guild.id, 'security', 'lockdownActive', true);
      } catch (err) {
        ctx.logger.warn('[security] could not persist lockdown state:', err?.message || err);
      }
      invalidateConfig(guild.id);
      embed.addFields({ name: 'Auto-lockdown', value: `Locked **${res.count}** channel(s).`, inline: false });
    }
  }
  sendAlert(ctx, guild, cfg, embed, [row]);
  return false;
}

// ─────────────────────────────── Lockdown ────────────────────────────────────

/** Deny SendMessages for @everyone. scope: 'channels' (text only) or 'server' (+ voice). */
async function applyLockdown(ctx, guild, scope) {
  if (!ctx.permissions.botHas(guild, 'ManageRoles')) {
    return { ok: false, count: 0, reason: 'I need the **Manage Roles** permission to edit channel overwrites.' };
  }
  let count = 0;
  const textChannels = guild.channels.cache.filter(
    (c) => c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement,
  );
  for (const ch of textChannels.values()) {
    try {
      await ch.permissionOverwrites.edit(
        guild.roles.everyone,
        { SendMessages: false, SendMessagesInThreads: false },
        { reason: 'Anti-raid lockdown' },
      );
      count += 1;
    } catch {
      /* missing perms on this channel — skip */
    }
  }
  if (scope === 'server') {
    const voiceChannels = guild.channels.cache.filter(
      (c) => c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice,
    );
    for (const ch of voiceChannels.values()) {
      try {
        await ch.permissionOverwrites.edit(guild.roles.everyone, { Speak: false }, { reason: 'Anti-raid lockdown' });
        count += 1;
      } catch {
        /* skip */
      }
    }
  }
  return { ok: true, count };
}

/** Neutralize the SendMessages/Speak overwrites for @everyone (custom overwrites are NOT restored). */
async function applyUnlock(ctx, guild) {
  if (!ctx.permissions.botHas(guild, 'ManageRoles')) {
    return { ok: false, count: 0, reason: 'I need the **Manage Roles** permission to edit channel overwrites.' };
  }
  let count = 0;
  const textChannels = guild.channels.cache.filter(
    (c) => c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement,
  );
  for (const ch of textChannels.values()) {
    try {
      await ch.permissionOverwrites.edit(
        guild.roles.everyone,
        { SendMessages: null, SendMessagesInThreads: null },
        { reason: 'Anti-raid unlock' },
      );
      count += 1;
    } catch {
      /* skip */
    }
  }
  const voiceChannels = guild.channels.cache.filter(
    (c) => c.type === ChannelType.GuildVoice || c.type === ChannelType.GuildStageVoice,
  );
  for (const ch of voiceChannels.values()) {
    try {
      await ch.permissionOverwrites.edit(guild.roles.everyone, { Speak: null }, { reason: 'Anti-raid unlock' });
      count += 1;
    } catch {
      /* skip */
    }
  }
  return { ok: true, count };
}

module.exports = {
  EVENTS,
  ACTIONS,
  EVENT_LABELS,
  invalidateConfig,
  detectAndEnforce,
  detectKick,
  handleJoin,
  applyLockdown,
  applyUnlock,
  sweep,
};
