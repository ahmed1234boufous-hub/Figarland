'use strict';

const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const { commands } = require('./commands');
const dashboard = require('./dashboard');
const service = require('./service');
const settings = require('../../core/settings');
const audit = require('../../core/audit');
const responses = require('../../core/responses');

module.exports = {
  key: 'security',
  name: 'Anti-Nuke & Anti-Raid',
  emoji: '☢️',
  dashboardCommandName: 'security-dashboard',

  settingsSchema: [
    {
      key: 'alertChannel',
      label: 'Alert channel',
      type: 'channel',
      desc: 'Where anti-nuke and anti-raid alerts are posted (fallback: system channel).',
    },
    {
      key: 'exemptRoleIds',
      label: 'Exempt roles',
      type: 'roles',
      desc: 'Members with these roles are ignored by anti-nuke detection.',
    },
  ],

  defaults: {
    enabled: true,
    settings: {
      antiNukeEnabled: true,
      raidEnabled: false,
      lockdownActive: false,
      alertChannel: null,
      whitelistUserIds: [],
      exemptRoleIds: [],
      raid: {
        joinThreshold: 8,
        windowSec: 60,
        minAccountAgeDays: 0,
        autoLockdown: false,
      },
      antiNuke: {
        channelDelete: { count: 3, windowSec: 10, action: 'alert' },
        roleDelete: { count: 3, windowSec: 10, action: 'alert' },
        banAdd: { count: 4, windowSec: 20, action: 'alert' },
        kickAdd: { count: 4, windowSec: 20, action: 'alert' },
        webhookCreate: { count: 3, windowSec: 30, action: 'alert' },
      },
    },
    commands: {
      antinuke: { cooldown: 5, responses: { success: { text: '', ephemeral: true } } },
      antiraid: { cooldown: 3, responses: { success: { text: '', ephemeral: true } } },
      security: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
    },
  },

  commands,

  dashboard,

  componentHandlers: {
    /**
     * Buttons attached to raid alert embeds.
     * rest = 'lockdown' | 'unlock'
     */
    'sec:': async (ctx, interaction, rest) => {
      try {
        const action = String(rest || '').split(':')[0];
        if (action !== 'lockdown' && action !== 'unlock') return;
        const perms = interaction.memberPermissions;
        if (!perms?.has(PermissionFlagsBits.ManageGuild) && !perms?.has(PermissionFlagsBits.Administrator)) {
          return responses.replyError(interaction, 'You need the **Manage Server** permission to use this button.');
        }
        if (!interaction.guild) return;
        const modCfg = await settings.getModuleConfig(interaction.guildId, 'security');
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };

        if (action === 'lockdown') {
          if (modCfg.settings.lockdownActive) {
            return responses.replySimple(
              interaction,
              '🔒 Lockdown is already active — use the Unlock button or `/antiraid unlock`.',
              { ephemeral: true },
            );
          }
          await interaction.deferReply({ flags: MessageFlags.Ephemeral });
          const res = await service.applyLockdown(ctx, interaction.guild, 'server');
          if (!res.ok) return responses.replyError(interaction, res.reason);
          const after = await settings.setModuleSetting(interaction.guildId, 'security', 'lockdownActive', true);
          service.invalidateConfig(interaction.guildId);
          await audit.log(interaction.guildId, interaction.user.id, 'config.antiraid.lockdown', 'module:security', before, after);
          return responses.replySimple(
            interaction,
            `🔒 Lockdown applied to **${res.count}** channel(s). Use \`/antiraid unlock\` or the Unlock button to lift it.`,
            { ephemeral: true },
          );
        }

        // unlock
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const res = await service.applyUnlock(ctx, interaction.guild);
        if (!res.ok) return responses.replyError(interaction, res.reason);
        const after = await settings.setModuleSetting(interaction.guildId, 'security', 'lockdownActive', false);
        service.invalidateConfig(interaction.guildId);
        await audit.log(interaction.guildId, interaction.user.id, 'config.antiraid.unlock', 'module:security', before, after);
        return responses.replySimple(
          interaction,
          `🔓 Lockdown lifted — **${res.count}** channel(s) restored. Previous custom overwrites were **not** restored.`,
          { ephemeral: true },
        );
      } catch (err) {
        ctx.logger.warn('[security] sec: handler:', err?.message || err);
        return responses.replyError(interaction, 'That action failed — check my permissions and try again.');
      }
    },
  },

  hooks: {
    async channelDelete(ctx, channel) {
      try {
        if (channel?.guild) await service.detectAndEnforce(ctx, channel.guild, 'channelDelete', channel.id);
      } catch (err) {
        ctx.logger.warn('[security] channelDelete:', err?.message || err);
      }
    },
    async roleDelete(ctx, role) {
      try {
        if (role?.guild) await service.detectAndEnforce(ctx, role.guild, 'roleDelete', role.id);
      } catch (err) {
        ctx.logger.warn('[security] roleDelete:', err?.message || err);
      }
    },
    async guildBanAdd(ctx, ban) {
      try {
        if (ban?.guild && ban.user?.id) await service.detectAndEnforce(ctx, ban.guild, 'banAdd', ban.user.id);
      } catch (err) {
        ctx.logger.warn('[security] guildBanAdd:', err?.message || err);
      }
    },
    async webhookCreate(ctx, webhook) {
      try {
        const guild = webhook?.guild || (webhook?.guildId ? ctx.client.guilds.cache.get(webhook.guildId) : null);
        if (guild && webhook?.id) await service.detectAndEnforce(ctx, guild, 'webhookCreate', webhook.id);
      } catch (err) {
        ctx.logger.warn('[security] webhookCreate:', err?.message || err);
      }
    },
    async guildMemberRemove(ctx, member) {
      try {
        await service.detectKick(ctx, member);
      } catch (err) {
        ctx.logger.warn('[security] guildMemberRemove:', err?.message || err);
      }
    },
    async guildMemberAdd(ctx, member) {
      try {
        const vetoed = await service.handleJoin(ctx, member);
        if (vetoed) return false; // member was kicked (account age gate) — skip later hooks
      } catch (err) {
        ctx.logger.warn('[security] guildMemberAdd:', err?.message || err);
      }
    },
  },

  schedulerJobs: [
    {
      name: 'security-sweep',
      intervalMs: 10 * 60 * 1000,
      run(ctx) {
        try {
          service.sweep();
        } catch (err) {
          ctx.logger.warn('[security] sweep:', err?.message || err);
        }
      },
    },
  ],
};
