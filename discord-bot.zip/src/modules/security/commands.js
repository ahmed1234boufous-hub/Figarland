'use strict';

const { ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');
const { respond, replyError } = require('../../core/responses');
const settings = require('../../core/settings');
const audit = require('../../core/audit');
const config = require('../../config');
const service = require('./service');

const SUB = ApplicationCommandOptionType.Subcommand;
const STR = ApplicationCommandOptionType.String;
const INT = ApplicationCommandOptionType.Integer;
const USER = ApplicationCommandOptionType.User;

const EVENT_CHOICES = service.EVENTS.map((e) => ({ name: service.EVENT_LABELS[e], value: e }));
const ACTION_CHOICES = service.ACTIONS.map((a) => ({ name: a, value: a }));

const commands = [
  {
    name: 'antinuke',
    description: 'Configure anti-nuke protection: thresholds, whitelist and automatic responses.',
    requiredPerms: ['Administrator'],
    cooldown: 5,
    options: [
      { name: 'enable', description: 'Enable anti-nuke detection for this server', type: SUB, options: [] },
      { name: 'disable', description: 'Disable anti-nuke detection for this server', type: SUB, options: [] },
      {
        name: 'whitelist',
        description: 'Exempt a trusted user from anti-nuke detection',
        type: SUB,
        options: [{ name: 'user', description: 'Trusted user to whitelist', type: USER, required: true }],
      },
      {
        name: 'unwhitelist',
        description: 'Remove a user from the anti-nuke whitelist',
        type: SUB,
        options: [{ name: 'user', description: 'User to remove from the whitelist', type: USER, required: true }],
      },
      {
        name: 'config',
        description: 'Set the threshold and automatic response for one event type',
        type: SUB,
        options: [
          { name: 'event', description: 'Which destructive event to configure', type: STR, required: true, choices: EVENT_CHOICES },
          { name: 'count', description: 'How many occurrences trigger the action', type: INT, required: false, minValue: 2, maxValue: 50 },
          { name: 'window_seconds', description: 'Sliding detection window in seconds', type: INT, required: false, minValue: 5, maxValue: 600 },
          {
            name: 'action',
            description: 'Automatic response when the threshold is exceeded',
            type: STR,
            required: false,
            choices: ACTION_CHOICES,
          },
        ],
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();
      const guildId = interaction.guildId;

      if (sub === 'enable' || sub === 'disable') {
        const modCfg = await settings.getModuleConfig(guildId, 'security');
        const next = sub === 'enable';
        if (modCfg.settings.antiNukeEnabled === next) {
          return replyError(interaction, `Anti-nuke is already **${next ? 'enabled' : 'disabled'}**.`);
        }
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const after = await settings.setModuleSetting(guildId, 'security', 'antiNukeEnabled', next);
        service.invalidateConfig(guildId);
        await audit.log(guildId, interaction.user.id, 'config.antinuke.enabled', 'module:security', before, after);
        return respond(
          interaction,
          cmdCfg.responses.success,
          {},
          `☢️ Anti-nuke is now **${next ? 'enabled' : 'disabled'}**. Current thresholds: \`/antinuke config event:<event>\`.`,
        );
      }

      if (sub === 'whitelist' || sub === 'unwhitelist') {
        const user = interaction.options.getUser('user', true);
        const modCfg = await settings.getModuleConfig(guildId, 'security');
        const list = Array.isArray(modCfg.settings.whitelistUserIds) ? [...modCfg.settings.whitelistUserIds] : [];
        if (sub === 'whitelist') {
          if (list.includes(user.id)) return replyError(interaction, `<@${user.id}> is already whitelisted.`);
          if (list.length >= 25) return replyError(interaction, 'The whitelist is limited to 25 users.');
          list.push(user.id);
        } else if (!list.includes(user.id)) {
          return replyError(interaction, `<@${user.id}> is not on the whitelist.`);
        } else {
          list.splice(list.indexOf(user.id), 1);
        }
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const after = await settings.setModuleSetting(guildId, 'security', 'whitelistUserIds', list);
        service.invalidateConfig(guildId);
        await audit.log(guildId, interaction.user.id, `config.antinuke.${sub}`, 'module:security', before, after);
        return respond(
          interaction,
          cmdCfg.responses.success,
          { user: `<@${user.id}>`, count: list.length },
          sub === 'whitelist'
            ? `☢️ <@${user.id}> added to the anti-nuke whitelist (**${list.length}** total).`
            : `☢️ <@${user.id}> removed from the anti-nuke whitelist (**${list.length}** total).`,
        );
      }

      // config
      const event = interaction.options.getString('event', true);
      const count = interaction.options.getInteger('count');
      const windowSec = interaction.options.getInteger('window_seconds');
      const action = interaction.options.getString('action');
      const modCfg = await settings.getModuleConfig(guildId, 'security');
      const current = (modCfg.settings.antiNuke || {})[event];
      if (!current) return replyError(interaction, 'Unknown event type.');

      if (count == null && windowSec == null && !action) {
        const embed = new EmbedBuilder()
          .setTitle(`☢️ Anti-nuke threshold — ${service.EVENT_LABELS[event]}`)
          .setColor(config.embedColor)
          .setDescription(
            `Triggers when **${current.count}** occur(s) within **${current.windowSec}s**.\n` +
              `Automatic response: **${current.action}**.\n\n` +
              'Change it with `/antinuke config` and any of `count`, `window_seconds`, `action`.',
          );
        return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
      }

      const patch = { ...current };
      if (count != null) patch.count = count;
      if (windowSec != null) patch.windowSec = windowSec;
      if (action) patch.action = action;
      const before = { enabled: modCfg.enabled, settings: modCfg.settings };
      const after = await settings.setModuleConfig(guildId, 'security', { settings: { antiNuke: { [event]: patch } } });
      service.invalidateConfig(guildId);
      await audit.log(guildId, interaction.user.id, 'config.antinuke.threshold', 'module:security', before, after);
      return respond(
        interaction,
        cmdCfg.responses.success,
        { event: service.EVENT_LABELS[event], count: patch.count, window: patch.windowSec, action: patch.action },
        `☢️ **${service.EVENT_LABELS[event]}**: **${patch.count}** per **${patch.windowSec}s** → **${patch.action}**.`,
      );
    },
  },
  {
    name: 'antiraid',
    description: 'Configure anti-raid join monitoring and server lockdown.',
    requiredPerms: ['ManageGuild'],
    cooldown: 3,
    options: [
      { name: 'enable', description: 'Enable anti-raid join monitoring', type: SUB, options: [] },
      { name: 'disable', description: 'Disable anti-raid join monitoring', type: SUB, options: [] },
      {
        name: 'lockdown',
        description: 'Lock down channels to stop an active raid',
        type: SUB,
        options: [
          {
            name: 'scope',
            description: 'channels = text channels only, server = text + voice',
            type: STR,
            required: true,
            choices: [
              { name: 'channels', value: 'channels' },
              { name: 'server', value: 'server' },
            ],
          },
        ],
      },
      { name: 'unlock', description: 'Lift an active lockdown and restore messaging', type: SUB, options: [] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();
      const guildId = interaction.guildId;

      if (sub === 'enable' || sub === 'disable') {
        const modCfg = await settings.getModuleConfig(guildId, 'security');
        const next = sub === 'enable';
        if (modCfg.settings.raidEnabled === next) {
          return replyError(interaction, `Anti-raid monitoring is already **${next ? 'enabled' : 'disabled'}**.`);
        }
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const after = await settings.setModuleSetting(guildId, 'security', 'raidEnabled', next);
        service.invalidateConfig(guildId);
        await audit.log(guildId, interaction.user.id, 'config.antiraid.enabled', 'module:security', before, after);
        return respond(
          interaction,
          cmdCfg.responses.success,
          {},
          `🚨 Anti-raid monitoring is now **${next ? 'enabled' : 'disabled'}** ` +
            `(spike threshold: **${modCfg.settings.raid?.joinThreshold ?? 8}** joins / **${modCfg.settings.raid?.windowSec ?? 60}s**).`,
        );
      }

      if (sub === 'lockdown') {
        const scope = interaction.options.getString('scope', true);
        const modCfg = await settings.getModuleConfig(guildId, 'security');
        const already = Boolean(modCfg.settings.lockdownActive);
        await interaction.deferReply({ flags: 64 });
        const res = await service.applyLockdown(ctx, interaction.guild, scope);
        if (!res.ok) return replyError(interaction, res.reason);
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const after = await settings.setModuleSetting(guildId, 'security', 'lockdownActive', true);
        service.invalidateConfig(guildId);
        await audit.log(guildId, interaction.user.id, 'config.antiraid.lockdown', 'module:security', before, after);
        return respond(
          interaction,
          cmdCfg.responses.success,
          { count: res.count, scope },
          `🔒 Lockdown applied — **${res.count}** channel(s) locked (scope: **${scope}**).` +
            `${already ? '\nLockdown was already active; overwrites were re-applied.' : ''}\n` +
            'Note: `/antiraid unlock` resets the @everyone overwrites set by lockdown — previous custom overwrites are **not** restored.',
        );
      }

      // unlock
      const modCfg = await settings.getModuleConfig(guildId, 'security');
      await interaction.deferReply({ flags: 64 });
      const res = await service.applyUnlock(ctx, interaction.guild);
      if (!res.ok) return replyError(interaction, res.reason);
      const before = { enabled: modCfg.enabled, settings: modCfg.settings };
      const after = await settings.setModuleSetting(guildId, 'security', 'lockdownActive', false);
      service.invalidateConfig(guildId);
      await audit.log(guildId, interaction.user.id, 'config.antiraid.unlock', 'module:security', before, after);
      return respond(
        interaction,
        cmdCfg.responses.success,
        { count: res.count },
        `🔓 Lockdown lifted — **${res.count}** channel(s) restored. Note: previous custom overwrites were **not** restored.`,
      );
    },
  },
  {
    name: 'security',
    description: 'View the security configuration and recent security events.',
    requiredPerms: ['ManageGuild'],
    cooldown: 3,
    options: [
      { name: 'status', description: 'Show the current anti-nuke / anti-raid configuration', type: SUB, options: [] },
      { name: 'logs', description: 'Show the last 20 security events', type: SUB, options: [] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();

      if (sub === 'status') {
        const modCfg = await settings.getModuleConfig(interaction.guildId, 'security');
        const s = modCfg.settings;
        const thresholds = service.EVENTS.map((ev) => {
          const c = (s.antiNuke || {})[ev] || {};
          return `${String(service.EVENT_LABELS[ev] || ev).padEnd(16)} ${String(c.count ?? '?').padEnd(4)} / ${String(c.windowSec ?? '?').padEnd(4)}s -> ${c.action ?? '?'}`;
        }).join('\n');
        const raid = s.raid || {};
        const wl = Array.isArray(s.whitelistUserIds) ? s.whitelistUserIds : [];
        const embed = new EmbedBuilder()
          .setTitle('☢️ Security status')
          .setColor(modCfg.enabled ? config.embedColor : config.errorColor)
          .addFields(
            { name: 'Anti-nuke', value: s.antiNukeEnabled ? '🟢 Enabled' : '🔴 Disabled', inline: true },
            {
              name: 'Alert channel',
              value: s.alertChannel ? `<#${s.alertChannel}>` : '*(system channel fallback)*',
              inline: true,
            },
            { name: 'Lockdown', value: s.lockdownActive ? '🔒 **ACTIVE**' : '⚪ Inactive', inline: true },
            { name: 'Event thresholds', value: `\`\`\`\n${thresholds}\n\`\`\`` },
            {
              name: 'Anti-raid',
              value:
                `${s.raidEnabled ? '🟢 Enabled' : '🔴 Disabled'} — **${raid.joinThreshold ?? 8}** joins / **${raid.windowSec ?? 60}s**\n` +
                `Min account age: ${raid.minAccountAgeDays ? `**${raid.minAccountAgeDays}** day(s)` : 'off'} • ` +
                `Auto-lockdown: ${raid.autoLockdown ? 'on' : 'off'}`,
            },
            {
              name: 'Whitelist',
              value: wl.length
                ? `${wl.length} user(s): ${wl.slice(0, 10).map((id) => `<@${id}>`).join(' ')}`
                : '*(empty)*',
            },
          );
        return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
      }

      // logs
      const rows = await ctx.db.securityEvent.findMany({
        where: { guildId: interaction.guildId },
        orderBy: { createdAt: 'desc' },
        take: 20,
      });
      const embed = new EmbedBuilder()
        .setTitle('📜 Recent security events')
        .setColor(config.embedColor)
        .setDescription(
          rows.length
            ? rows
                .map(
                  (r) =>
                    `\`#${r.id}\` **${r.type}** — <@${r.userId}> • <t:${Math.floor(r.createdAt.getTime() / 1000)}:R>`,
                )
                .join('\n')
                .slice(0, 4000)
            : 'No security events recorded yet.',
        )
        .setFooter({ text: rows.length ? `Last ${rows.length} event(s)` : 'Events appear when destructive actions are detected' });
      return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
    },
  },
];

module.exports = { commands };
