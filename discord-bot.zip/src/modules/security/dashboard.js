'use strict';

const service = require('./service');

module.exports = {
  async summaryLines(guild, modCfg) {
    const s = modCfg.settings || {};
    const raid = s.raid || {};
    const wl = Array.isArray(s.whitelistUserIds) ? s.whitelistUserIds : [];
    return [
      ['Anti-nuke', s.antiNukeEnabled ? `🟢 Enabled — ${service.EVENTS.length} events monitored` : '🔴 Disabled'],
      ['Anti-raid', s.raidEnabled ? `🟢 Enabled — ${raid.joinThreshold || 8} joins / ${raid.windowSec || 60}s` : '🔴 Disabled'],
      ['Whitelist', `${wl.length} user(s)`],
      ['Alert channel', s.alertChannel ? `<#${s.alertChannel}>` : '*(system channel fallback)*'],
    ];
  },
};
