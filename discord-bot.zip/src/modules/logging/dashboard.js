'use strict';

const service = require('./service');

module.exports = {
  async summaryLines(guild, modCfg) {
    const s = modCfg.settings || {};
    const enabled = Array.isArray(s.enabledEvents) ? s.enabledEvents : service.EVENTS;
    return [
      ['Default channel', s.defaultChannel ? `<#${s.defaultChannel}>` : '*(not set)*'],
      ['Enabled events', `${enabled.length}/${service.EVENTS.length}`],
      ['Ignored channels', `${(s.ignoredChannelIds || []).length}`],
    ];
  },
};
