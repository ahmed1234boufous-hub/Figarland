'use strict';

const { EmbedBuilder } = require('discord.js');
const config = require('../../config');

/**
 * logging/service.js — event pipeline: dispatch -> destination -> embed.
 *
 * Every event goes through dispatch(): module enabled check, per-event enable
 * check, destination resolution (per-event channel or default channel),
 * ignored channel/role checks, then a themed embed is posted.
 */

const EVENTS = [
  'messageDelete',
  'messageEdit',
  'memberJoin',
  'memberLeave',
  'banAdd',
  'roleChange',
  'nicknameChange',
  'voiceJoin',
  'voiceLeave',
  'channelDelete',
];

const EVENT_META = {
  messageDelete: { title: '📝 Message deleted', color: config.errorColor, label: 'Message deleted' },
  messageEdit: { title: '✏️ Message edited', color: config.warnColor, label: 'Message edited' },
  memberJoin: { title: '📥 Member joined', color: config.successColor, label: 'Member joined' },
  memberLeave: { title: '📤 Member left', color: config.errorColor, label: 'Member left' },
  banAdd: { title: '🔨 Member banned', color: config.errorColor, label: 'Member banned' },
  roleChange: { title: '🎭 Roles updated', color: config.embedColor, label: 'Roles updated' },
  nicknameChange: { title: '📛 Nickname changed', color: config.warnColor, label: 'Nickname changed' },
  voiceJoin: { title: '🔊 Voice joined', color: config.successColor, label: 'Voice joined' },
  voiceLeave: { title: '🔈 Voice left', color: config.errorColor, label: 'Voice left' },
  channelDelete: { title: '🗑️ Channel deleted', color: config.errorColor, label: 'Channel deleted' },
};

const EVENT_CHOICES = EVENTS.map((e) => ({ name: EVENT_META[e].label, value: e }));

const CFG_TTL_MS = 5 * 1000;
const cfgCache = new Map(); // guildId -> { cfg, at }

function invalidateConfig(guildId) {
  cfgCache.delete(guildId);
}

async function getCfg(ctx, guildId) {
  const hit = cfgCache.get(guildId);
  if (hit && Date.now() - hit.at < CFG_TTL_MS) return hit.cfg;
  const cfg = await ctx.settings.getModuleConfig(guildId, 'logging');
  cfgCache.set(guildId, { cfg, at: Date.now() });
  return cfg;
}

function snippet(text, max = 500) {
  const s = String(text || '');
  return s.length > max ? `${s.slice(0, max - 1)}…` : s;
}

function userLine(user) {
  if (!user?.id) return 'Unknown';
  return `<@${user.id}>${user.tag ? ` (${user.tag})` : ''}`;
}

function mentionList(ids, prefix) {
  if (!ids?.length) return 'None';
  return ids.slice(0, 15).map((id) => `${prefix}${id}>`).join(' ') + (ids.length > 15 ? ` *(+${ids.length - 15})*` : '');
}

/** Build the themed embed for one event. Exported so /logs test can reuse it. */
function buildEventEmbed(event, data) {
  const meta = EVENT_META[event] || { title: 'Event', color: config.embedColor };
  const embed = new EmbedBuilder().setTitle(meta.title).setColor(meta.color).setTimestamp();
  const thumb = data.user?.displayAvatarURL ? data.user.displayAvatarURL({ size: 256, extension: 'png' }) : null;
  if (thumb) embed.setThumbnail(thumb);

  switch (event) {
    case 'messageDelete':
      embed.addFields(
        { name: 'Author', value: userLine(data.user), inline: true },
        { name: 'Channel', value: data.channelId ? `<#${data.channelId}>` : 'Unknown', inline: true },
        { name: 'Content', value: snippet(data.content) || '*(no text)*' },
        { name: 'Attachments', value: `${data.attachments || 0}`, inline: true },
      );
      if (data.url) embed.addFields({ name: 'Message', value: `[Jump to message](${data.url})`, inline: true });
      break;
    case 'messageEdit':
      embed.addFields(
        { name: 'Author', value: userLine(data.user), inline: true },
        { name: 'Channel', value: data.channelId ? `<#${data.channelId}>` : 'Unknown', inline: true },
        {
          name: 'Before',
          value: data.before === null || data.before === undefined ? '*(content not cached)*' : snippet(data.before) || '*(no text)*',
        },
        { name: 'After', value: snippet(data.after) || '*(no text)*' },
      );
      if (data.url) embed.addFields({ name: 'Message', value: `[Jump to message](${data.url})`, inline: true });
      break;
    case 'memberJoin':
      embed.addFields(
        { name: 'Member', value: userLine(data.user), inline: true },
        {
          name: 'Account created',
          value: data.user?.createdTimestamp ? `<t:${Math.floor(data.user.createdTimestamp / 1000)}:R>` : 'Unknown',
          inline: true,
        },
        { name: 'Member count', value: `${data.memberCount ?? '?'}`, inline: true },
      );
      break;
    case 'memberLeave':
      embed.addFields(
        { name: 'Member', value: userLine(data.user), inline: true },
        { name: 'Member count', value: `${data.memberCount ?? '?'}`, inline: true },
      );
      break;
    case 'banAdd':
      embed.addFields(
        { name: 'User', value: userLine(data.user), inline: true },
        { name: 'Reason', value: snippet(data.reason, 500) || 'No reason provided' },
      );
      break;
    case 'roleChange':
      embed.addFields(
        { name: 'Member', value: userLine(data.user), inline: true },
        { name: 'Roles added', value: mentionList(data.added, '<@&') },
        { name: 'Roles removed', value: mentionList(data.removed, '<@&') },
      );
      break;
    case 'nicknameChange':
      embed.addFields(
        { name: 'Member', value: userLine(data.user), inline: true },
        { name: 'Before', value: snippet(data.before, 100) || '*(none)*', inline: true },
        { name: 'After', value: snippet(data.after, 100) || '*(none)*', inline: true },
      );
      break;
    case 'voiceJoin':
      embed.addFields(
        { name: 'Member', value: userLine(data.user), inline: true },
        { name: 'Channel', value: data.channelId ? `<#${data.channelId}>` : 'Unknown', inline: true },
      );
      if (data.movedFrom) embed.addFields({ name: 'Moved from', value: `<#${data.movedFrom}>`, inline: true });
      break;
    case 'voiceLeave':
      embed.addFields(
        { name: 'Member', value: userLine(data.user), inline: true },
        { name: 'Channel', value: data.channelId ? `<#${data.channelId}>` : 'Unknown', inline: true },
      );
      break;
    case 'channelDelete':
      embed.addFields(
        { name: 'Channel', value: `#${data.name || 'unknown'} (\`${data.id || '?'}\`)`, inline: true },
        { name: 'Category', value: data.categoryName || 'None', inline: true },
      );
      break;
    default:
      embed.setDescription(snippet(JSON.stringify(data), 1000));
  }
  return embed;
}

/**
 * Central dispatcher: resolve destination, apply checks, post the embed.
 * @param {object} opts { subjectChannelId, subjectUserId }
 */
async function dispatch(ctx, guild, event, data, opts = {}) {
  try {
    if (!guild?.id || !EVENTS.includes(event)) return;
    const cfg = await getCfg(ctx, guild.id).catch(() => null);
    if (!cfg?.enabled) return;
    const s = cfg.settings || {};

    const enabled = Array.isArray(s.enabledEvents) ? s.enabledEvents : EVENTS;
    if (!enabled.includes(event)) return;

    const destination = s.eventChannels?.[event] || s.defaultChannel;
    if (!destination) return;

    if (opts.subjectChannelId && Array.isArray(s.ignoredChannelIds) && s.ignoredChannelIds.includes(opts.subjectChannelId)) return;
    if (opts.subjectUserId && Array.isArray(s.ignoredRoleIds) && s.ignoredRoleIds.length) {
      const member = guild.members.cache.get(opts.subjectUserId);
      if (member && s.ignoredRoleIds.some((r) => member.roles.cache.has(r))) return;
    }

    const channel = guild.channels.cache.get(destination);
    if (!channel || !channel.isTextBased?.()) return;
    await channel.send({ embeds: [buildEventEmbed(event, data)] }).catch(() => {});
  } catch (err) {
    ctx.logger.warn('[logging] dispatch failed:', err?.message || err);
  }
}

// ─────────────────────────────── Event hooks ─────────────────────────────────

async function logMessageDelete(ctx, message) {
  if (!message?.guild) return;
  await dispatch(
    ctx,
    message.guild,
    'messageDelete',
    {
      user: message.author,
      channelId: message.channelId,
      content: message.content || '',
      attachments: message.attachments?.size || 0,
      url: message.url || null,
    },
    { subjectChannelId: message.channelId, subjectUserId: message.author?.id },
  );
}

async function logMessageUpdate(ctx, oldMessage, newMessage) {
  if (!newMessage?.guild || newMessage.author?.bot) return;
  const before = oldMessage && !oldMessage.partial ? oldMessage.content || '' : null; // null = uncached
  const after = newMessage.content || '';
  if (before !== null && before === after) return; // embed-only edit, no content change
  await dispatch(
    ctx,
    newMessage.guild,
    'messageEdit',
    {
      user: newMessage.author,
      channelId: newMessage.channelId,
      before,
      after,
      url: newMessage.url || null,
    },
    { subjectChannelId: newMessage.channelId, subjectUserId: newMessage.author?.id },
  );
}

async function logMemberJoin(ctx, member) {
  if (!member?.guild) return;
  await dispatch(
    ctx,
    member.guild,
    'memberJoin',
    { user: member.user, memberCount: member.guild.memberCount },
    { subjectUserId: member.id },
  );
}

async function logMemberLeave(ctx, member) {
  if (!member?.guild) return;
  await dispatch(
    ctx,
    member.guild,
    'memberLeave',
    { user: member.user, memberCount: member.guild.memberCount },
    { subjectUserId: member.id },
  );
}

async function logBanAdd(ctx, ban) {
  if (!ban?.guild || !ban.user) return;
  await dispatch(ctx, ban.guild, 'banAdd', { user: ban.user, reason: ban.reason || null }, { subjectUserId: ban.user.id });
}

async function logMemberUpdate(ctx, oldMember, newMember) {
  if (!newMember?.guild || newMember.user?.bot) return;
  const oldIds = new Set([...(oldMember?.roles?.cache?.keys() || [])]);
  const newIds = new Set([...(newMember.roles?.cache?.keys() || [])]);
  const added = [...newIds].filter((id) => !oldIds.has(id));
  const removed = [...oldIds].filter((id) => !newIds.has(id));
  const nickChanged = (oldMember?.nickname ?? null) !== (newMember.nickname ?? null);
  if (!added.length && !removed.length && !nickChanged) return;

  if (added.length || removed.length) {
    await dispatch(
      ctx,
      newMember.guild,
      'roleChange',
      { user: newMember.user, added, removed },
      { subjectUserId: newMember.id },
    );
  }
  if (nickChanged) {
    await dispatch(
      ctx,
      newMember.guild,
      'nicknameChange',
      { user: newMember.user, before: oldMember?.displayName || '(none)', after: newMember.displayName },
      { subjectUserId: newMember.id },
    );
  }
}

async function logVoiceState(ctx, oldState, newState) {
  const guild = newState?.guild || oldState?.guild;
  if (!guild) return;
  const member = newState?.member || oldState?.member;
  if (!member) return;
  const oldId = oldState?.channelId || null;
  const newId = newState?.channelId || null;
  const opts = { subjectUserId: member.id };

  if (!oldId && newId) {
    await dispatch(ctx, guild, 'voiceJoin', { user: member.user, channelId: newId }, opts);
  } else if (oldId && !newId) {
    await dispatch(ctx, guild, 'voiceLeave', { user: member.user, channelId: oldId }, opts);
  } else if (oldId && newId && oldId !== newId) {
    await dispatch(ctx, guild, 'voiceJoin', { user: member.user, channelId: newId, movedFrom: oldId }, opts);
  }
}

async function logChannelDelete(ctx, channel) {
  if (!channel?.guild) return;
  await dispatch(
    ctx,
    channel.guild,
    'channelDelete',
    { name: channel.name, id: channel.id, categoryName: channel.parent?.name || null },
    { subjectChannelId: channel.id },
  );
}

module.exports = {
  EVENTS,
  EVENT_META,
  EVENT_CHOICES,
  invalidateConfig,
  buildEventEmbed,
  dispatch,
  logMessageDelete,
  logMessageUpdate,
  logMemberJoin,
  logMemberLeave,
  logBanAdd,
  logMemberUpdate,
  logVoiceState,
  logChannelDelete,
};
