'use strict';

const { PermissionFlagsBits } = require('discord.js');
const { commands } = require('./commands');
const dashboard = require('./dashboard');
const service = require('./service');
const settings = require('../../core/settings');
const audit = require('../../core/audit');
const responses = require('../../core/responses');

module.exports = {
  key: 'logging',
  name: 'Logging',
  emoji: '📜',
  dashboardCommandName: 'logging-dashboard',

  settingsSchema: [
    {
      key: 'defaultChannel',
      label: 'Default log channel',
      type: 'channel',
      desc: 'Used for every event without a dedicated channel (also settable via /logs setup).',
    },
  ],

  defaults: {
    enabled: true,
    settings: {
      defaultChannel: null,
      eventChannels: {
        messageDelete: null,
        messageEdit: null,
        memberJoin: null,
        memberLeave: null,
        banAdd: null,
        roleChange: null,
        nicknameChange: null,
        voiceJoin: null,
        voiceLeave: null,
        channelDelete: null,
      },
      enabledEvents: [
        'messageDelete',
        'messageEdit',
        'memberJoin',
        'memberLeave',
        'banAdd',
        'roleChange',
        'nicknameChange',
        'voiceJoin',
        'voiceLeave',
        'channelDelete',
      ],
      ignoredChannelIds: [],
      ignoredRoleIds: [],
    },
    commands: {
      logs: { cooldown: 3, responses: { success: { text: '', ephemeral: true } } },
    },
  },

  commands,

  dashboard,

  /**
   * Preset buttons attached to the /logs channels view.
   * rest = 'enableall' | 'disableall'
   */
  componentHandlers: {
    'log:': async (ctx, interaction, rest) => {
      try {
        const action = String(rest || '').split(':')[0];
        if (action !== 'enableall' && action !== 'disableall') return;
        const perms = interaction.memberPermissions;
        if (!perms?.has(PermissionFlagsBits.ManageGuild) && !perms?.has(PermissionFlagsBits.Administrator)) {
          return responses.replyError(interaction, 'You need the **Manage Server** permission to use this button.');
        }
        if (!interaction.guild) return;
        const modCfg = await settings.getModuleConfig(interaction.guildId, 'logging');
        const before = { enabled: modCfg.enabled, settings: modCfg.settings };
        const next = action === 'enableall' ? [...service.EVENTS] : [];
        const after = await settings.setModuleSetting(interaction.guildId, 'logging', 'enabledEvents', next);
        service.invalidateConfig(interaction.guildId);
        await audit.log(interaction.guildId, interaction.user.id, `config.logging.${action}`, 'module:logging', before, after);
        return responses.replySimple(
          interaction,
          action === 'enableall'
            ? '📜 All events are now **enabled**.'
            : '📜 All events are now **disabled** (destinations kept).',
          { ephemeral: true },
        );
      } catch (err) {
        ctx.logger.warn('[logging] log: handler:', err?.message || err);
        return responses.replyError(interaction, 'That action failed.');
      }
    },
  },

  hooks: {
    async messageDelete(ctx, message) {
      try {
        await service.logMessageDelete(ctx, message);
      } catch (err) {
        ctx.logger.warn('[logging] messageDelete:', err?.message || err);
      }
    },
    async messageUpdate(ctx, oldMessage, newMessage) {
      try {
        await service.logMessageUpdate(ctx, oldMessage, newMessage);
      } catch (err) {
        ctx.logger.warn('[logging] messageUpdate:', err?.message || err);
      }
    },
    async guildMemberAdd(ctx, member) {
      try {
        await service.logMemberJoin(ctx, member);
      } catch (err) {
        ctx.logger.warn('[logging] guildMemberAdd:', err?.message || err);
      }
    },
    async guildMemberRemove(ctx, member) {
      try {
        await service.logMemberLeave(ctx, member);
      } catch (err) {
        ctx.logger.warn('[logging] guildMemberRemove:', err?.message || err);
      }
    },
    async guildBanAdd(ctx, ban) {
      try {
        await service.logBanAdd(ctx, ban);
      } catch (err) {
        ctx.logger.warn('[logging] guildBanAdd:', err?.message || err);
      }
    },
    async guildMemberUpdate(ctx, oldMember, newMember) {
      try {
        await service.logMemberUpdate(ctx, oldMember, newMember);
      } catch (err) {
        ctx.logger.warn('[logging] guildMemberUpdate:', err?.message || err);
      }
    },
    async voiceStateUpdate(ctx, oldState, newState) {
      try {
        await service.logVoiceState(ctx, oldState, newState);
      } catch (err) {
        ctx.logger.warn('[logging] voiceStateUpdate:', err?.message || err);
      }
    },
    async channelDelete(ctx, channel) {
      try {
        await service.logChannelDelete(ctx, channel);
      } catch (err) {
        ctx.logger.warn('[logging] channelDelete:', err?.message || err);
      }
    },
  },
};
