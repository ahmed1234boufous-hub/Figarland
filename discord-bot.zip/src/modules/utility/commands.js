'use strict';

const {
  EmbedBuilder,
  ApplicationCommandOptionType,
  ChannelType,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { respond, replyError, replySimple } = require('../../core/responses');
const permissions = require('../../core/permissions');
const embedsCore = require('../../core/embeds');
const settings = require('../../core/settings');
const service = require('./service');
const config = require('../../config');

const STR = ApplicationCommandOptionType.String;
const INT = ApplicationCommandOptionType.Integer;
const USER = ApplicationCommandOptionType.User;
const CH = ApplicationCommandOptionType.Channel;
const ROLE = ApplicationCommandOptionType.Role;
const BOOL = ApplicationCommandOptionType.Boolean;
const SUB = ApplicationCommandOptionType.Subcommand;

function rel(ts) {
  return `<t:${Math.floor(ts / 1000)}:R>`;
}

function fmtDate(ts) {
  return `<t:${Math.floor(ts / 1000)}:f> (${rel(ts)})`;
}

function hexColor(role) {
  if (!role.color) return 'Default';
  return `#${role.color.toString(16).padStart(6, '0')}`;
}

function channelTypeName(type) {
  const names = {
    [ChannelType.GuildText]: 'Text',
    [ChannelType.GuildVoice]: 'Voice',
    [ChannelType.GuildCategory]: 'Category',
    [ChannelType.GuildAnnouncement]: 'Announcement',
    [ChannelType.GuildStageVoice]: 'Stage',
    [ChannelType.GuildForum]: 'Forum',
    [ChannelType.GuildDirectory]: 'Directory',
    [ChannelType.PublicThread]: 'Public thread',
    [ChannelType.PrivateThread]: 'Private thread',
    [ChannelType.AnnouncementThread]: 'Announcement thread',
  };
  return names[type] || `Type ${type}`;
}

function getModSettings(guildId) {
  return settings.getModuleConfig(guildId, 'utility');
}

async function listUserReminders(ctx, interaction, cmdCfg) {
  const rows = await ctx.db.reminder.findMany({
    where: { guildId: interaction.guildId, userId: interaction.user.id, delivered: false },
    orderBy: { at: 'asc' },
    take: 10,
  });
  const components = [];
  const selectRow = service.reminderSelectRow(rows);
  if (selectRow) components.push(selectRow);
  return respond(
    interaction,
    cmdCfg.responses.success,
    {},
    rows.length ? 'Here are your upcoming reminders.' : 'You have no upcoming reminders. Create one with `/remind create`.',
    { embeds: [service.reminderListEmbed(rows, interaction.user.username)], components, ephemeralDefault: true },
  );
}

const commands = [
  // ── /userinfo ──────────────────────────────────────────────────────────────
  {
    name: 'userinfo',
    description: 'Show detailed information about a member.',
    cooldown: 3,
    options: [{ name: 'user', description: 'Member to inspect (default: you)', type: USER, required: false }],
    async run(ctx, interaction, cmdCfg) {
      const user = interaction.options.getUser('user') || interaction.user;
      const member = interaction.options.getMember('user') || interaction.member;
      const fields = [
        { name: 'ID', value: user.id, inline: true },
        { name: 'Type', value: user.bot ? '🤖 Bot' : '👤 User', inline: true },
        { name: 'Username', value: user.username || 'Unknown', inline: true },
      ];
      if (member) {
        fields.push({ name: 'Display name', value: member.displayName || user.username, inline: true });
        if (member.joinedTimestamp) fields.push({ name: 'Joined server', value: fmtDate(member.joinedTimestamp), inline: true });
        fields.push({
          name: 'Roles',
          value: `${Math.max(0, member.roles.cache.size - 1)} (top: ${member.roles.highest?.name || 'none'})`,
          inline: true,
        });
        if (member.premiumSinceTimestamp) fields.push({ name: 'Boosting since', value: rel(member.premiumSinceTimestamp), inline: true });
      } else {
        fields.push({ name: 'In this server', value: 'No (member not cached)', inline: true });
      }
      fields.push({ name: 'Account created', value: fmtDate(user.createdTimestamp), inline: true });

      const embed = new EmbedBuilder()
        .setTitle(`👤 ${user.username}`)
        .setColor(config.embedColor)
        .setThumbnail(user.displayAvatarURL({ size: 256, extension: 'png' }))
        .addFields(fields);
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>` }, `Information about **${user.username}**.`, {
        embeds: [embed],
      });
    },
  },

  // ── /serverinfo ────────────────────────────────────────────────────────────
  {
    name: 'serverinfo',
    description: 'Show detailed information about this server.',
    cooldown: 3,
    async run(ctx, interaction, cmdCfg) {
      const guild = interaction.guild;
      const channels = guild.channels.cache;
      const counts = {
        text: channels.filter((c) => c.type === ChannelType.GuildText).size,
        voice: channels.filter((c) => c.type === ChannelType.GuildVoice).size,
        category: channels.filter((c) => c.type === ChannelType.GuildCategory).size,
        other: channels.filter((c) => ![ChannelType.GuildText, ChannelType.GuildVoice, ChannelType.GuildCategory].includes(c.type)).size,
      };
      const embed = new EmbedBuilder()
        .setTitle(`🏠 ${guild.name}`)
        .setColor(config.embedColor)
        .setThumbnail(guild.iconURL({ size: 256, extension: 'png' }) || undefined)
        .addFields(
          { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true },
          { name: 'Created', value: fmtDate(guild.createdTimestamp), inline: true },
          { name: 'Members', value: `${guild.memberCount}`, inline: true },
          {
            name: 'Channels',
            value: `${channels.size} total — ${counts.text} text, ${counts.voice} voice, ${counts.category} categories${counts.other ? `, ${counts.other} other` : ''}`,
            inline: false,
          },
          { name: 'Roles', value: `${guild.roles.cache.size}`, inline: true },
          {
            name: 'Boosts',
            value: `Level ${guild.premiumTier} — ${guild.premiumSubscriptionCount ?? 0} boost(s)`,
            inline: true,
          },
          { name: 'Features', value: `${guild.features.length} server feature(s)`, inline: true },
        )
        .setFooter({ text: `Guild ID: ${guild.id}` });
      return respond(interaction, cmdCfg.responses.success, { server: guild.name }, `Information about **${guild.name}**.`, {
        embeds: [embed],
      });
    },
  },

  // ── /avatar ────────────────────────────────────────────────────────────────
  {
    name: 'avatar',
    description: 'Show the avatar of a member.',
    cooldown: 3,
    options: [
      { name: 'user', description: 'Member (default: you)', type: USER, required: false },
      {
        name: 'size',
        description: 'Image size',
        type: INT,
        required: false,
        choices: [
          { name: '256', value: 256 },
          { name: '512', value: 512 },
          { name: '1024', value: 1024 },
        ],
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const user = interaction.options.getUser('user') || interaction.user;
      const size = interaction.options.getInteger('size') || 1024;
      const url = user.displayAvatarURL({ size, extension: 'png' });
      const embed = new EmbedBuilder()
        .setTitle(`🖼️ ${user.username} — avatar (${size}px)`)
        .setColor(config.embedColor)
        .setImage(url);
      return respond(interaction, cmdCfg.responses.success, {}, url, { embeds: [embed] });
    },
  },

  // ── /banner ────────────────────────────────────────────────────────────────
  {
    name: 'banner',
    description: 'Show the profile banner of a user.',
    cooldown: 3,
    options: [{ name: 'user', description: 'User (default: you)', type: USER, required: false }],
    async run(ctx, interaction, cmdCfg) {
      const user = interaction.options.getUser('user') || interaction.user;
      const fetched = await user.fetch(true).catch(() => user);
      const url = fetched.bannerURL ? fetched.bannerURL({ size: 1024 }) : null;
      if (!url) {
        return replySimple(interaction, `🎨 **${user.username}** has no banner set.`, { ephemeral: true });
      }
      const embed = new EmbedBuilder().setTitle(`🎨 ${user.username} — banner`).setColor(config.embedColor).setImage(url);
      return respond(interaction, cmdCfg.responses.success, {}, url, { embeds: [embed] });
    },
  },

  // ── /roleinfo ──────────────────────────────────────────────────────────────
  {
    name: 'roleinfo',
    description: 'Show detailed information about a role.',
    cooldown: 3,
    options: [{ name: 'role', description: 'Role to inspect', type: ROLE, required: true }],
    async run(ctx, interaction, cmdCfg) {
      const role = interaction.options.getRole('role', true);
      const embed = new EmbedBuilder()
        .setTitle(`🏷️ @${role.name}`)
        .setColor(role.color || config.embedColor)
        .addFields(
          { name: 'ID', value: role.id, inline: true },
          { name: 'Color', value: hexColor(role), inline: true },
          { name: 'Position', value: `${role.position}`, inline: true },
          { name: 'Members', value: `${role.members.size}`, inline: true },
          { name: 'Permissions', value: `${role.permissions.toArray().length}`, inline: true },
          { name: 'Created', value: fmtDate(role.createdTimestamp), inline: true },
          { name: 'Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
          { name: 'Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
          { name: 'Managed', value: role.managed ? 'Yes (integration)' : 'No', inline: true },
        );
      return respond(interaction, cmdCfg.responses.success, { role: `<@&${role.id}>` }, `Information about **@${role.name}**.`, {
        embeds: [embed],
      });
    },
  },

  // ── /channelinfo ───────────────────────────────────────────────────────────
  {
    name: 'channelinfo',
    description: 'Show detailed information about a channel.',
    cooldown: 3,
    options: [{ name: 'channel', description: 'Channel to inspect (default: this one)', type: CH, required: false }],
    async run(ctx, interaction, cmdCfg) {
      const channel = interaction.options.getChannel('channel') || interaction.channel;
      const fields = [
        { name: 'ID', value: channel.id, inline: true },
        { name: 'Type', value: channelTypeName(channel.type), inline: true },
        { name: 'Created', value: fmtDate(channel.createdTimestamp), inline: true },
      ];
      if (channel.parent) fields.push({ name: 'Category', value: channel.parent.name, inline: true });
      if (channel.topic) fields.push({ name: 'Topic', value: channel.topic.slice(0, 1024), inline: false });
      if (typeof channel.nsfw === 'boolean') fields.push({ name: 'NSFW', value: channel.nsfw ? 'Yes' : 'No', inline: true });
      const embed = new EmbedBuilder()
        .setTitle(`#️⃣ ${channel.name}`)
        .setColor(config.embedColor)
        .addFields(fields);
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>` }, `Information about **#${channel.name}**.`, {
        embeds: [embed],
      });
    },
  },

  // ── /botinfo ───────────────────────────────────────────────────────────────
  {
    name: 'botinfo',
    description: 'Show statistics and status of this bot.',
    cooldown: 5,
    async run(ctx, interaction, cmdCfg) {
      const client = interaction.client;
      const moduleCount = ctx.registry.getModules().length;
      const commandCount = ctx.registry.getModules().reduce((n, m) => n + (m.commands?.length || 0), 0);
      const memMb = (process.memoryUsage().heapUsed / 1048576).toFixed(1);
      const embed = new EmbedBuilder()
        .setTitle(`🤖 ${client.user.username}`)
        .setColor(config.embedColor)
        .setThumbnail(client.user.displayAvatarURL({ size: 256, extension: 'png' }))
        .addFields(
          { name: 'Version', value: '1.0.0', inline: true },
          { name: 'Uptime', value: service.humanizeUptime(process.uptime()), inline: true },
          { name: 'WebSocket ping', value: `${Math.max(0, Math.round(client.ws.ping || 0))} ms`, inline: true },
          { name: 'Servers', value: `${client.guilds.cache.size}`, inline: true },
          { name: 'Modules', value: `${moduleCount}`, inline: true },
          { name: 'Commands', value: `${commandCount}`, inline: true },
          { name: 'Memory', value: `${memMb} MB`, inline: true },
          { name: 'Node.js', value: process.version, inline: true },
        )
        .setFooter({ text: `Bot ID: ${client.user.id}` });
      return respond(interaction, cmdCfg.responses.success, {}, `Bot status at a glance.`, { embeds: [embed] });
    },
  },

  // ── /membercount ───────────────────────────────────────────────────────────
  {
    name: 'membercount',
    description: 'Show the current member count of this server.',
    cooldown: 3,
    async run(ctx, interaction, cmdCfg) {
      const guild = interaction.guild;
      const total = guild.memberCount;
      const cached = guild.members.cache;
      const bots = cached.filter((m) => m.user.bot).size;
      const humans = Math.max(0, total - bots);
      const embed = new EmbedBuilder()
        .setTitle(`👥 ${total} members`)
        .setColor(config.embedColor)
        .setDescription(`**${total}** members in **${guild.name}**`)
        .addFields(
          { name: 'Humans', value: `${humans}`, inline: true },
          { name: 'Bots', value: `${bots}`, inline: true },
        )
        .setFooter({ text: 'Humans/bots split is based on the cached member list' });
      return respond(interaction, cmdCfg.responses.success, { membercount: `${total}` }, `**${total}** members and counting.`, {
        embeds: [embed],
      });
    },
  },

  // ── /inviteinfo ────────────────────────────────────────────────────────────
  {
    name: 'inviteinfo',
    description: 'Inspect a Discord invite link or code.',
    cooldown: 5,
    options: [{ name: 'code', description: 'Invite code or full invite link', type: STR, required: true, maxLength: 200 }],
    async run(ctx, interaction, cmdCfg) {
      const raw = interaction.options.getString('code', true).trim();
      const code = raw.includes('/') ? raw.split('/').filter(Boolean).pop() : raw;
      const invite = await interaction.client.fetchInvite(code).catch(() => null);
      if (!invite) {
        return replyError(interaction, 'That invite is invalid, expired, or could not be fetched.');
      }
      const fields = [
        { name: 'Code', value: `\`${invite.code}\``, inline: true },
        { name: 'Server', value: invite.guild ? invite.guild.name : 'Unknown', inline: true },
        { name: 'Channel', value: invite.channel ? `<#${invite.channel.id}>` : 'Unknown', inline: true },
        { name: 'Inviter', value: invite.inviter ? `<@${invite.inviter.id}>` : 'Unknown', inline: true },
        { name: 'Uses', value: `${invite.uses ?? 0} / ${invite.maxUses || '∞'}`, inline: true },
        {
          name: 'Expires',
          value: invite.expiresTimestamp ? rel(invite.expiresTimestamp) : 'Never',
          inline: true,
        },
      ];
      const embed = new EmbedBuilder()
        .setTitle(`📨 Invite \`${invite.code}\``)
        .setColor(config.embedColor)
        .addFields(fields);
      if (invite.guild?.iconURL) embed.setThumbnail(invite.guild.iconURL({ size: 128, extension: 'png' }) || undefined);
      return respond(interaction, cmdCfg.responses.success, { code: invite.code }, `Details for invite \`${invite.code}\`.`, {
        embeds: [embed],
      });
    },
  },

  // ── /ping ──────────────────────────────────────────────────────────────────
  {
    name: 'ping',
    description: 'Check the bot latency and websocket status.',
    cooldown: 2,
    async run(ctx, interaction, cmdCfg) {
      const sent = Date.now();
      const msg = await interaction.reply({ content: '🏓 Pinging…', flags: 64, fetchReply: true }).catch(() => null);
      const roundtrip = msg ? msg.createdTimestamp - sent : null;
      const ws = Math.max(0, Math.round(interaction.client.ws.ping || 0));
      const embed = new EmbedBuilder()
        .setTitle('🏓 Pong')
        .setColor(config.embedColor)
        .addFields(
          { name: 'WebSocket', value: `${ws} ms`, inline: true },
          { name: 'Roundtrip', value: roundtrip !== null ? `${roundtrip} ms` : 'Unknown', inline: true },
        );
      return respond(interaction, cmdCfg.responses.success, { ws: `${ws}`, roundtrip: roundtrip !== null ? `${roundtrip}` : '?' }, `🏓 Pong — API ${ws} ms.`, {
        embeds: [embed],
      });
    },
  },

  // ── /afk ───────────────────────────────────────────────────────────────────
  {
    name: 'afk',
    description: 'Set an AFK status — people who mention you will be told.',
    cooldown: 3,
    options: [{ name: 'reason', description: 'Why you are AFK', type: STR, required: false, maxLength: 200 }],
    async run(ctx, interaction, cmdCfg) {
      const reason = (interaction.options.getString('reason') || 'AFK').trim().slice(0, 200) || 'AFK';
      await ctx.db.afkEntry.upsert({
        where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
        create: { guildId: interaction.guildId, userId: interaction.user.id, reason },
        update: { reason, since: new Date() },
      });
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ut:afkoff').setLabel('Turn off AFK').setStyle(ButtonStyle.Secondary).setEmoji('👋'),
      );
      return respond(
        interaction,
        cmdCfg.responses.success,
        { reason },
        `💤 AFK set: **${reason}**. Send any message to remove it.`,
        { components: [row] },
      );
    },
  },

  // ── /remind ────────────────────────────────────────────────────────────────
  {
    name: 'remind',
    description: 'Set, list or cancel reminders.',
    cooldown: 3,
    options: [
      {
        name: 'create',
        description: 'Create a new reminder',
        type: SUB,
        options: [
          { name: 'duration', description: 'When — e.g. 30m, 2h, 1d, 1h30m (max 30 days)', type: STR, required: true, maxLength: 32 },
          { name: 'text', description: 'What to remind you about', type: STR, required: true, maxLength: 500 },
          { name: 'dm', description: 'Send the reminder as a DM instead of in this channel', type: BOOL, required: false },
        ],
      },
      { name: 'list', description: 'List your upcoming reminders', type: SUB, options: [] },
      {
        name: 'cancel',
        description: 'Cancel one of your reminders',
        type: SUB,
        options: [{ name: 'id', description: 'Reminder ID (see /remind list)', type: INT, required: true, minValue: 1 }],
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand(true);

      if (sub === 'list') return listUserReminders(ctx, interaction, cmdCfg);

      if (sub === 'cancel') {
        const id = interaction.options.getInteger('id', true);
        const row = await ctx.db.reminder.findUnique({ where: { id } }).catch(() => null);
        if (!row || row.guildId !== interaction.guildId || row.userId !== interaction.user.id) {
          return replyError(interaction, `Reminder **#${id}** does not exist or is not yours.`);
        }
        if (row.delivered) return replyError(interaction, 'That reminder was already delivered.');
        await ctx.db.reminder.delete({ where: { id } });
        return respond(interaction, cmdCfg.responses.success, {}, `🗑️ Reminder **#${id}** cancelled.`, { ephemeralDefault: true });
      }

      // create
      const modCfg = await getModSettings(interaction.guildId);
      const limit = Math.max(1, parseInt(modCfg.settings.reminderLimitPerUser, 10) || 10);
      const pending = await ctx.db.reminder.count({ where: { guildId: interaction.guildId, userId: interaction.user.id, delivered: false } });
      if (pending >= limit) {
        return replyError(interaction, `You already have **${pending}** pending reminder(s) — the limit is **${limit}**. Cancel one with \`/remind list\` first.`);
      }
      const durationMs = service.parseDurationMs(interaction.options.getString('duration', true));
      if (!durationMs) {
        return replyError(interaction, 'Could not read that duration. Use forms like `30m`, `2h`, `1d` or `1h30m` (max 30 days).');
      }
      const text = interaction.options.getString('text', true).trim().slice(0, 500);
      const dm = interaction.options.getBoolean('dm') || false;
      const at = new Date(Date.now() + durationMs);
      const row = await ctx.db.reminder.create({
        data: {
          guildId: interaction.guildId,
          userId: interaction.user.id,
          content: text,
          at,
          channelId: dm ? null : interaction.channel.id,
          dm,
          delivered: false,
        },
      });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { ts: Math.floor(at.getTime() / 1000), duration: service.formatDuration(durationMs), id: `${row.id}` },
        `⏰ Reminder **#${row.id}** set — I will remind you ${rel(at.getTime())} (${service.formatDuration(durationMs)} from now).`,
        { ephemeralDefault: true },
      );
    },
  },

  // ── /embed ─────────────────────────────────────────────────────────────────
  {
    name: 'embed',
    description: 'Post a custom embed message in this channel.',
    requiredPerms: ['ManageMessages'],
    cooldown: 3,
    options: [
      { name: 'title', description: 'Embed title', type: STR, required: true, maxLength: 256 },
      { name: 'description', description: 'Embed description', type: STR, required: true, maxLength: 4000 },
      { name: 'color', description: 'Hex color without # (e.g. 5865F2)', type: STR, required: false, maxLength: 7 },
      { name: 'image_url', description: 'Image URL for the embed', type: STR, required: false, maxLength: 500 },
      { name: 'footer', description: 'Footer text', type: STR, required: false, maxLength: 256 },
    ],
    async run(ctx, interaction, cmdCfg) {
      const title = interaction.options.getString('title', true).slice(0, 256);
      const description = interaction.options.getString('description', true).slice(0, 4096);
      const colorRaw = interaction.options.getString('color');
      const imageUrl = interaction.options.getString('image_url');
      const footer = interaction.options.getString('footer');

      let color;
      if (colorRaw) {
        color = embedsCore.normalizeColor(colorRaw);
        if (color === undefined) return replyError(interaction, 'That color is not a valid hex value (e.g. `5865F2`).');
      }
      if (imageUrl && !/^https?:\/\//i.test(imageUrl)) {
        return replyError(interaction, 'The image URL must start with `http://` or `https://`.');
      }

      const embed = new EmbedBuilder().setTitle(title).setDescription(description).setColor(color ?? config.embedColor);
      if (imageUrl) embed.setImage(imageUrl);
      if (footer) embed.setFooter({ text: footer });
      embed.setTimestamp();

      return respond(interaction, cmdCfg.responses.success, {}, 'Embed posted.', { embeds: [embed] });
    },
  },

  // ── /say ───────────────────────────────────────────────────────────────────
  {
    name: 'say',
    description: 'Send a message as the bot through a configured say role.',
    cooldown: 3,
    options: [
      { name: 'text', description: 'Message to send', type: STR, required: true, maxLength: 2000 },
      {
        name: 'channel',
        description: 'Target channel (default: this one)',
        type: CH,
        required: false,
        channelTypes: [ChannelType.GuildText, ChannelType.GuildAnnouncement],
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const sayRoles = Array.isArray(modCfg.settings.sayRoles) ? modCfg.settings.sayRoles : [];
      if (!sayRoles.length) {
        return replyError(interaction, '/say is not configured yet — an administrator must add **Say roles** in the Utility dashboard.');
      }
      const isAdmin = permissions.memberHas(interaction.member, 'ManageGuild');
      const hasSayRole = interaction.member?.roles?.cache?.some((r) => sayRoles.includes(r.id));
      if (!isAdmin && !hasSayRole) {
        return replyError(interaction, 'You need one of the configured **say roles** (or **Manage Server**) to use this command.');
      }

      const text = interaction.options.getString('text', true).slice(0, 2000);
      const target = interaction.options.getChannel('channel') || interaction.channel;
      if (!target || typeof target.send !== 'function') {
        return replyError(interaction, 'I cannot send messages in that channel.');
      }
      if (!permissions.botHas(interaction.guild, 'SendMessages') || !target.permissionsFor(interaction.guild.members.me)?.has(PermissionFlagsBits.SendMessages)) {
        return replyError(interaction, `I do not have **Send Messages** permission in <#${target.id}>.`);
      }

      await target.send({ content: text }).catch((err) => {
        throw new Error(`Discord refused the message: ${err?.message || err}`);
      });
      await ctx.audit.log(interaction.guildId, interaction.user.id, 'utility.say', `channel:${target.id}`, null, { text });
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${target.id}>` }, `✅ Message sent to <#${target.id}>.`, {
        ephemeralDefault: true,
      });
    },
  },
];

module.exports = { commands };
