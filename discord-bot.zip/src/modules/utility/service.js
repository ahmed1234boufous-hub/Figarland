'use strict';

const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');
const db = require('../../core/db');
const config = require('../../config');
const { replySimple, replyError } = require('../../core/responses');

/**
 * utility/service.js — shared helpers for the Utility module:
 * duration parsing, reminder menu building, reminder delivery job,
 * the AFK message hook and the "ut:" component handler.
 */

const MAX_REMINDER_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

// AFK mention notifications: key `${guildId}:${afkUserId}:${mentionerId}` → last notify timestamp
const afkNotifyAt = new Map();
const AFK_NOTIFY_COOLDOWN_MS = 30 * 1000;

// ─────────────────────────────── Duration helpers ────────────────────────────

/**
 * Parse a human duration like "30m", "2h", "1d", "1h30m", "90s".
 * Accepts repeated s/m/h/d tokens; nothing else may remain.
 * @returns {number|null} milliseconds (capped at 30 days) or null when invalid
 */
function parseDurationMs(raw) {
  if (!raw) return null;
  const s = String(raw).trim().toLowerCase();
  if (!s) return null;
  const token = /(\d+)\s*(s|m|h|d)/g;
  let total = 0;
  let matched = false;
  let m;
  // eslint-disable-next-line no-cond-assign
  while ((m = token.exec(s))) {
    const n = parseInt(m[1], 10);
    if (!Number.isFinite(n) || n <= 0) return null;
    const unit = m[2];
    const mult = unit === 's' ? 1000 : unit === 'm' ? 60000 : unit === 'h' ? 3600000 : 86400000;
    total += n * mult;
    matched = true;
    if (total > MAX_REMINDER_MS) return null;
  }
  if (!matched) return null;
  const leftover = s.replace(/(\d+)\s*(s|m|h|d)/g, '').trim();
  if (leftover) return null;
  if (total <= 0 || total > MAX_REMINDER_MS) return null;
  return total;
}

/** Humanize a millisecond duration ("1d 2h 5m"). */
function formatDuration(ms) {
  let s = Math.max(1, Math.round(ms / 1000));
  const d = Math.floor(s / 86400); s -= d * 86400;
  const h = Math.floor(s / 3600); s -= h * 3600;
  const m = Math.floor(s / 60); s -= m * 60;
  const parts = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  if (s || !parts.length) parts.push(`${s}s`);
  return parts.join(' ');
}

/** Humanize a process uptime in seconds ("3d 4h 12m"). */
function humanizeUptime(seconds) {
  return formatDuration(seconds * 1000);
}

// ─────────────────────────────── Reminder helpers ────────────────────────────

function reminderSelectRow(rows) {
  if (!rows || !rows.length) return null;
  const row = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('ut:remindcancel')
      .setPlaceholder('Cancel one of your reminders…')
      .addOptions(
        rows.slice(0, 10).map((r) => {
          const due = Math.floor(new Date(r.at).getTime() / 1000);
          return {
            label: `#${r.id} ${(r.content || 'reminder').slice(0, 80)}`,
            description: `due <t:${due}:R>`.slice(0, 100),
            value: String(r.id),
          };
        }),
      ),
  );
  return row;
}

function reminderListEmbed(rows, username) {
  const embed = new EmbedBuilder()
    .setTitle('⏰ Your upcoming reminders')
    .setColor(config.embedColor)
    .setDescription(
      rows.length
        ? rows
            .map((r) => {
              const due = Math.floor(new Date(r.at).getTime() / 1000);
              return `\`#${r.id}\` <t:${due}:R> — ${String(r.content || '').slice(0, 120)}${r.dm ? ' *(DM)*' : ''}`;
            })
            .join('\n')
        : 'No upcoming reminders.',
    )
    .setFooter({ text: username ? `Requested by ${username}` : 'Use /remind create to add one' });
  return embed;
}

// ─────────────────────────────── Scheduler job ───────────────────────────────

/** Deliver every reminder whose time has come (run every 30s by the scheduler). */
async function deliverDueReminders(ctx) {
  const due = await db.reminder.findMany({
    where: { delivered: false, at: { lte: new Date() } },
    orderBy: { at: 'asc' },
    take: 25,
  });
  for (const r of due) {
    let ok = false;
    try {
      const text = `⏰ reminder: ${String(r.content || '').slice(0, 1500)}`;
      if (r.dm) {
        const user = await ctx.client.users.fetch(r.userId).catch(() => null);
        if (user) ok = await user.send(text).then(() => true).catch(() => false);
      } else if (r.channelId) {
        const channel = await ctx.client.channels.fetch(r.channelId).catch(() => null);
        if (channel && typeof channel.send === 'function') {
          ok = await channel.send({ content: `<@${r.userId}> ${text}` }).then(() => true).catch(() => false);
        }
      }
    } catch (err) {
      ctx.logger.warn(`[reminders] delivery failed for #${r.id}: ${err?.message || err}`);
    }
    await db.reminder.update({ where: { id: r.id }, data: { delivered: true } }).catch(() => {});
    if (!ok) ctx.logger.warn(`[reminders] reminder #${r.id} marked delivered but could not be sent (channel/DM gone).`);
  }
}

// ─────────────────────────────── AFK hook logic ──────────────────────────────

function sweepAfkNotify(now) {
  for (const [k, v] of afkNotifyAt) if (now - v > AFK_NOTIFY_COOLDOWN_MS * 20) afkNotifyAt.delete(k);
}

/**
 * messageCreate hook body: welcome the author back from AFK and announce
 * mentioned AFK members (once per afkUser/mentioner pair per 30s).
 */
async function handleAfkMessage(ctx, message) {
  if (!message.guild || !message.author || message.author.bot) return;
  const mentioned = [...(message.mentions?.users?.values() || [])].map((u) => u.id).slice(0, 5);
  const selfId = message.author.id;
  if (!mentioned.length && !selfId) return;

  const ids = [...new Set([selfId, ...mentioned])];
  const entries = await db.afkEntry.findMany({ where: { guildId: message.guild.id, userId: { in: ids } } });
  if (!entries.length) return;

  const byUser = new Map(entries.map((e) => [e.userId, e]));

  // Author returning from AFK → remove the entry.
  const self = byUser.get(selfId);
  if (self) {
    await db.afkEntry.delete({ where: { guildId_userId: { guildId: message.guild.id, userId: selfId } } }).catch(() => {});
    await message
      .reply({ content: `👋 Welcome back <@${selfId}>, AFK removed.`, allowedMentions: { repliedUser: false, parse: [] } })
      .catch(() => {});
  }

  // Mentioned AFK members → announce once per pair per 30s.
  const now = Date.now();
  if (afkNotifyAt.size > 5000) sweepAfkNotify(now);
  let announced = 0;
  for (const entry of entries) {
    if (announced >= 3) break;
    if (entry.userId === selfId) continue;
    const key = `${message.guild.id}:${entry.userId}:${selfId}`;
    const last = afkNotifyAt.get(key) || 0;
    if (now - last < AFK_NOTIFY_COOLDOWN_MS) continue;
    afkNotifyAt.set(key, now);
    const since = Math.floor(new Date(entry.since).getTime() / 1000);
    const embed = new EmbedBuilder()
      .setDescription(`💤 <@${entry.userId}> went AFK <t:${since}:R>: ${String(entry.reason || 'AFK').slice(0, 500)}`)
      .setColor(config.embedColor);
    // eslint-disable-next-line no-await-in-loop
    await message.reply({ embeds: [embed], allowedMentions: { parse: [] } }).catch(() => {});
    announced += 1;
  }
}

// ─────────────────────────────── ut: components ──────────────────────────────

async function handleComponent(ctx, interaction, rest) {
  if (rest === 'afkoff') {
    const row = await db.afkEntry
      .findUnique({ where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } } })
      .catch(() => null);
    if (!row) return replySimple(interaction, 'You are not AFK right now.', { ephemeral: true });
    await db.afkEntry.delete({ where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } } }).catch(() => {});
    return replySimple(interaction, '👋 AFK removed — welcome back!', { ephemeral: true });
  }

  if (rest === 'remindcancel') {
    const id = parseInt(interaction.values?.[0], 10);
    if (!Number.isFinite(id)) return replyError(interaction, 'That reminder could not be found.');
    const row = await db.reminder.findUnique({ where: { id } }).catch(() => null);
    if (!row || row.guildId !== interaction.guildId) return replyError(interaction, 'That reminder does not exist (anymore).');
    if (row.userId !== interaction.user.id) return replyError(interaction, 'You can only cancel your own reminders.');
    if (row.delivered) return replyError(interaction, 'That reminder was already delivered.');
    await db.reminder.delete({ where: { id } }).catch(() => {});
    return replySimple(interaction, `🗑️ Reminder **#${id}** cancelled.`, { ephemeral: true });
  }

  return replySimple(interaction, 'Unknown utility action.', { ephemeral: true });
}

module.exports = {
  MAX_REMINDER_MS,
  parseDurationMs,
  formatDuration,
  humanizeUptime,
  reminderSelectRow,
  reminderListEmbed,
  deliverDueReminders,
  handleAfkMessage,
  handleComponent,
};
