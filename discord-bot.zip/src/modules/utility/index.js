'use strict';

const { commands } = require('./commands');
const dashboard = require('./dashboard');
const service = require('./service');

/**
 * utility — information commands, AFK status, reminders, embed builder and /say.
 */

module.exports = {
  key: 'utility',
  name: 'Utility & Information',
  emoji: '🧰',
  dashboardCommandName: 'utility-dashboard',

  settingsSchema: [
    { key: 'sayRoles', label: 'Say roles', type: 'roles', desc: 'Members with one of these roles (or Manage Server) may use /say.' },
    { key: 'reminderLimitPerUser', label: 'Reminder limit per user', type: 'number', desc: 'Maximum simultaneous pending reminders per member.' },
    { key: 'dashboardRoles', label: 'Dashboard access roles', type: 'roles', desc: 'Roles (besides administrators) allowed to open this dashboard.' },
  ],

  defaults: {
    enabled: true,
    settings: {
      sayRoles: [],
      reminderLimitPerUser: 10,
      dashboardRoles: [],
    },
    commands: {
      userinfo: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      serverinfo: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      avatar: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      banner: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      roleinfo: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      channelinfo: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      botinfo: { cooldown: 5, responses: { success: { text: '', ephemeral: false } } },
      membercount: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      inviteinfo: { cooldown: 5, responses: { success: { text: '', ephemeral: false } } },
      ping: { cooldown: 2, responses: { success: { text: '', ephemeral: true } } },
      afk: { cooldown: 3, responses: { success: { text: '💤 AFK set: **{reason}**.\nI will tell people who mention you. Send any message (or use the button below) to remove it.', ephemeral: true } } },
      remind: { cooldown: 3, responses: { success: { text: '⏰ Reminder set — I will ping you <t:{ts}:R>.', ephemeral: true } } },
      embed: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      say: { cooldown: 3, responses: { success: { text: '✅ Message sent to {channel}.', ephemeral: true } } },
    },
  },

  commands,

  dashboard,

  componentHandlers: {
    'ut:': service.handleComponent,
  },

  hooks: {
    async messageCreate(ctx, message) {
      try {
        await service.handleAfkMessage(ctx, message);
      } catch (err) {
        ctx.logger?.error?.('[utility:messageCreate]', err?.message || err);
      }
    },
  },

  schedulerJobs: [
    {
      name: 'reminders',
      intervalMs: 30000,
      run: (ctx) => service.deliverDueReminders(ctx),
    },
  ],
};
