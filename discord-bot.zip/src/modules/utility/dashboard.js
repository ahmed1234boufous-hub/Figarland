'use strict';

const db = require('../../core/db');

/**
 * utility/dashboard.js — summary lines for the shared dashboard framework.
 * (Reminders are also manageable via /remind list.)
 */

module.exports = {
  async summaryLines(guild, modCfg) {
    const [afkCount, pendingReminders] = await Promise.all([
      db.afkEntry.count({ where: { guildId: guild.id } }),
      db.reminder.count({ where: { guildId: guild.id, delivered: false } }),
    ]);
    const sayRoles = Array.isArray(modCfg.settings?.sayRoles) ? modCfg.settings.sayRoles : [];
    return [
      ['AFK entries', `${afkCount}`],
      ['Pending reminders', `${pendingReminders}`],
      ['Say roles', sayRoles.length ? `${sayRoles.length} role(s)` : '*(none — /say is disabled)*'],
    ];
  },
};
