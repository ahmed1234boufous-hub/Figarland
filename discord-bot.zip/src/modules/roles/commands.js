'use strict';

const { ApplicationCommandOptionType, PermissionFlagsBits, ChannelType } = require('discord.js');
const audit = require('../../core/audit');
const config = require('../../config');
const { respond, replyError } = require('../../core/responses');
const service = require('./service');

const SUB = ApplicationCommandOptionType.Subcommand;
const STR = ApplicationCommandOptionType.String;
const ROLE = ApplicationCommandOptionType.Role;
const BOOL = ApplicationCommandOptionType.Boolean;

const MODES = [
  { name: 'buttons', value: 'buttons' },
  { name: 'select', value: 'select' },
];
const STYLES = [
  { name: 'Primary', value: 'Primary' },
  { name: 'Secondary', value: 'Secondary' },
  { name: 'Success', value: 'Success' },
  { name: 'Danger', value: 'Danger' },
];

function emojiString(value) {
  const raw = (value || '').trim();
  if (!raw) return null;
  if (/^<a?:\w+:\d+>$/.test(raw) || /^\p{Extended_Pictographic}$/u.test(raw)) return raw;
  return null;
}

async function updatePanelMessage(guild, panel) {
  try {
    if (!panel.messageId) return { ok: false, missing: true };
    const channel = guild.channels.cache.get(panel.channelId) || (await guild.channels.fetch(panel.channelId).catch(() => null));
    if (!channel || !channel.isTextBased()) return { ok: false, missing: true };
    const message = await channel.messages.fetch(panel.messageId).catch(() => null);
    if (!message) return { ok: false, missing: true };
    await message.edit(service.buildPanelPayload(panel));
    return { ok: true };
  } catch {
    return { ok: false, missing: true };
  }
}

const commands = [
  {
    name: 'roles',
    description: 'Create and manage reaction role panels.',
    cooldown: 3,
    requiredPerms: ['ManageGuild'],
    options: [
      {
        name: 'panel',
        description: 'Create a reaction role panel message in this channel',
        type: SUB,
        options: [
          { name: 'name', description: 'Panel name (used by /roles add and friends)', type: STR, required: true, maxLength: 80 },
          { name: 'mode', description: 'How members pick roles', type: STR, required: true, choices: MODES },
        ],
      },
      {
        name: 'add',
        description: 'Add a role option to a panel',
        type: SUB,
        options: [
          { name: 'panel', description: 'Panel name', type: STR, required: true, maxLength: 80 },
          { name: 'role', description: 'Role to offer', type: ROLE, required: true },
          { name: 'label', description: 'Button or menu label', type: STR, required: true, maxLength: 80 },
          { name: 'emoji', description: 'Emoji in front of the label (unicode or custom)', type: STR, required: false, maxLength: 32 },
          { name: 'style', description: 'Button style (buttons mode)', type: STR, required: false, choices: STYLES },
          { name: 'description', description: 'Menu option description (select mode)', type: STR, required: false, maxLength: 100 },
        ],
      },
      {
        name: 'remove',
        description: 'Remove a role option from a panel',
        type: SUB,
        options: [
          { name: 'panel', description: 'Panel name', type: STR, required: true, maxLength: 80 },
          { name: 'role', description: 'Role to remove', type: ROLE, required: true },
        ],
      },
      {
        name: 'edit',
        description: 'Edit a role option on a panel',
        type: SUB,
        options: [
          { name: 'panel', description: 'Panel name', type: STR, required: true, maxLength: 80 },
          { name: 'role', description: 'Role whose option to edit', type: ROLE, required: true },
          { name: 'label', description: 'New label', type: STR, required: false, maxLength: 80 },
          { name: 'emoji', description: 'New emoji (send none to remove)', type: STR, required: false, maxLength: 32 },
          { name: 'style', description: 'New button style', type: STR, required: false, choices: STYLES },
        ],
      },
      { name: 'list', description: 'List all reaction role panels', type: SUB, options: [] },
      { name: 'delete', description: 'Delete a panel (its message is left in place)', type: SUB, options: [{ name: 'panel', description: 'Panel name', type: STR, required: true, maxLength: 80 }] },
      {
        name: 'singlechoice',
        description: 'Allow only one role from a panel at a time',
        type: SUB,
        options: [
          { name: 'panel', description: 'Panel name', type: STR, required: true, maxLength: 80 },
          { name: 'enabled', description: 'Enable or disable single-choice', type: BOOL, required: true },
        ],
      },
      { name: 'repost', description: 'Repost a panel message and bind the panel to it', type: SUB, options: [{ name: 'panel', description: 'Panel name', type: STR, required: true, maxLength: 80 }] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand(false);
      switch (sub) {
        case 'panel':
          return runPanel(ctx, interaction, cmdCfg);
        case 'add':
          return runAdd(ctx, interaction, cmdCfg);
        case 'remove':
          return runRemove(ctx, interaction, cmdCfg);
        case 'edit':
          return runEdit(ctx, interaction, cmdCfg);
        case 'list':
          return runList(ctx, interaction, cmdCfg);
        case 'delete':
          return runDelete(ctx, interaction, cmdCfg);
        case 'singlechoice':
          return runSingleChoice(ctx, interaction, cmdCfg);
        case 'repost':
          return runRepost(ctx, interaction, cmdCfg);
        default:
          return replyError(interaction, 'Unknown subcommand.');
      }
    },
  },
];

/** /roles panel — create the panel record and post its message. */
async function runPanel(ctx, interaction, cmdCfg) {
  const name = interaction.options.getString('name', true).trim();
  const mode = service.normalizeMode(interaction.options.getString('mode', true));
  const panels = await service.getPanels(interaction.guildId);

  if (service.findPanel(panels, name)) return replyError(interaction, `A panel named **${name}** already exists — pick another name or delete it first.`);
  if (interaction.channel.type !== ChannelType.GuildText) return replyError(interaction, 'Panels can only be posted in text channels.');

  await interaction.deferReply({ flags: 64 });

  const panel = {
    id: service.newPanelId(),
    name,
    channelId: interaction.channelId,
    messageId: null,
    mode,
    singleChoice: false,
    options: [],
  };
  const message = await interaction.channel.send(service.buildPanelPayload(panel)).catch(() => null);
  if (!message) return replyError(interaction, 'I could not post the panel message in this channel — check my permissions.');
  panel.messageId = message.id;

  await service.savePanels(interaction.guildId, [...panels, panel]);
  await audit.log(interaction.guildId, interaction.user.id, 'config.panel.create', 'module:roles', null, { panelId: panel.id, name, mode });

  return respond(
    interaction,
    cmdCfg.responses.success,
    { channelname: `#${interaction.channel.name}` },
    `✅ Panel **${name}** created (mode: **${mode}**). Add roles with \`/roles add panel:${name} ...\`.`,
    { ephemeralDefault: true },
  );
}

/** /roles add — append a role option and refresh the panel message. */
async function runAdd(ctx, interaction, cmdCfg) {
  const panels = await service.getPanels(interaction.guildId);
  const panel = service.findPanel(panels, interaction.options.getString('panel', true));
  if (!panel) return replyError(interaction, `No panel with that name exists — see \`/roles list\`.`);

  const role = interaction.options.getRole('role', true);
  const label = interaction.options.getString('label', true).trim();
  const emoji = emojiString(interaction.options.getString('emoji'));
  const styleName = interaction.options.getString('style');
  const description = interaction.options.getString('description');

  if (!label) return replyError(interaction, 'The label cannot be empty.');
  if (panel.options.length >= service.MAX_OPTIONS) return replyError(interaction, `A panel supports at most **${service.MAX_OPTIONS}** options.`);
  if (panel.options.some((o) => o.roleId === role.id)) return replyError(interaction, `<@&${role.id}> is already an option on this panel — use \`/roles edit\` instead.`);
  const assignable = service.checkRoleAssignable(interaction.guild, role);
  if (!assignable.ok) return replyError(interaction, assignable.reason);
  if (role.id === interaction.guild.id) return replyError(interaction, 'The @everyone role cannot be used as a reaction role option.');

  const option = {
    roleId: role.id,
    label,
    emoji: emoji || null,
    style: service.styleFromName(styleName),
    description: panel.mode === 'select' ? description || null : null,
  };

  const before = { panels };
  const nextPanels = panels.map((p) => (p.id === panel.id ? { ...p, options: [...p.options, option] } : p));
  await service.savePanels(interaction.guildId, nextPanels);
  const updated = nextPanels.find((p) => p.id === panel.id);
  const result = await updatePanelMessage(interaction.guild, updated);
  await audit.log(interaction.guildId, interaction.user.id, 'config.panel.option.add', 'module:roles', before, { panels: nextPanels });

  const suffix = result.ok ? '' : result.missing ? '\n⚠️ The panel message could not be found — use `/roles repost` to repost it.' : '';
  const descNote = panel.mode === 'buttons' && description ? ' (description ignored in buttons mode)' : '';
  return respond(
    interaction,
    cmdCfg.responses.success,
    { role: `<@&${role.id}>` },
    `✅ Added ${emoji || ''} **${label}** (<@&${role.id}>) to panel **${panel.name}**.${descNote}${suffix}`,
    { ephemeralDefault: true },
  );
}

/** /roles remove — drop a role option and refresh the panel message. */
async function runRemove(ctx, interaction, cmdCfg) {
  const panels = await service.getPanels(interaction.guildId);
  const panel = service.findPanel(panels, interaction.options.getString('panel', true));
  if (!panel) return replyError(interaction, `No panel with that name exists — see \`/roles list\`.`);

  const role = interaction.options.getRole('role', true);
  if (!panel.options.some((o) => o.roleId === role.id)) return replyError(interaction, `<@&${role.id}> is not an option on this panel.`);

  const before = { panels };
  const nextPanels = panels.map((p) => (p.id === panel.id ? { ...p, options: p.options.filter((o) => o.roleId !== role.id) } : p));
  await service.savePanels(interaction.guildId, nextPanels);
  const updated = nextPanels.find((p) => p.id === panel.id);
  const result = await updatePanelMessage(interaction.guild, updated);
  await audit.log(interaction.guildId, interaction.user.id, 'config.panel.option.remove', 'module:roles', before, { panels: nextPanels });

  const suffix = result.missing ? '\n⚠️ The panel message could not be found — use `/roles repost` to repost it.' : '';
  return respond(interaction, cmdCfg.responses.success, { role: `<@&${role.id}>` }, `➖ Removed <@&${role.id}> from panel **${panel.name}**.${suffix}`, { ephemeralDefault: true });
}

/** /roles edit — update label/emoji/style of an existing option. */
async function runEdit(ctx, interaction, cmdCfg) {
  const panels = await service.getPanels(interaction.guildId);
  const panel = service.findPanel(panels, interaction.options.getString('panel', true));
  if (!panel) return replyError(interaction, `No panel with that name exists — see \`/roles list\`.`);

  const role = interaction.options.getRole('role', true);
  const option = panel.options.find((o) => o.roleId === role.id);
  if (!option) return replyError(interaction, `<@&${role.id}> is not an option on this panel — add it with \`/roles add\`.`);

  const label = interaction.options.getString('label');
  const rawEmoji = interaction.options.getString('emoji');
  const styleName = interaction.options.getString('style');

  if (label !== null && label !== undefined && !label.trim()) {
    return replyError(interaction, 'The label cannot be empty.');
  }
  let nextEmoji;
  if (rawEmoji !== null && rawEmoji !== undefined) {
    const trimmed = rawEmoji.trim();
    if (trimmed.toLowerCase() === 'none') nextEmoji = null;
    else {
      const cleaned = emojiString(trimmed);
      if (!cleaned) {
        return replyError(interaction, 'That emoji is not valid — use a unicode emoji, a custom emoji like `<:name:id>`, or `none` to remove it.');
      }
      nextEmoji = cleaned;
    }
  }

  const before = { panels };
  const nextPanels = panels.map((p) => {
    if (p.id !== panel.id) return p;
    return {
      ...p,
      options: p.options.map((o) => {
        if (o.roleId !== role.id) return o;
        const next = { ...o };
        if (label && label.trim()) next.label = label.trim();
        if (nextEmoji !== undefined) next.emoji = nextEmoji;
        if (styleName) next.style = service.styleFromName(styleName);
        return next;
      }),
    };
  });
  await service.savePanels(interaction.guildId, nextPanels);
  const updated = nextPanels.find((p) => p.id === panel.id);
  const result = await updatePanelMessage(interaction.guild, updated);
  await audit.log(interaction.guildId, interaction.user.id, 'config.panel.option.edit', 'module:roles', before, { panels: nextPanels });

  const suffix = result.missing ? '\n⚠️ The panel message could not be found — use `/roles repost` to repost it.' : '';
  return respond(interaction, cmdCfg.responses.success, { role: `<@&${role.id}>` }, `✏️ Updated the <@&${role.id}> option on panel **${panel.name}**.${suffix}`, { ephemeralDefault: true });
}

/** /roles list — all panels with mode, channel and option counts. */
async function runList(ctx, interaction, cmdCfg) {
  const panels = await service.getPanels(interaction.guildId);
  if (!panels.length) {
    return respond(interaction, cmdCfg.responses.success, {}, 'No reaction role panels exist yet — create one with `/roles panel`.', { ephemeralDefault: true });
  }
  const embed = new EmbedBuilder().setTitle('🎭 Reaction role panels').setColor(config.embedColor);
  embed.setDescription(
    panels
      .slice(0, 15)
      .map(
        (p) =>
          `**${p.name}** \`${p.id}\`\n` +
          `• Mode: ${p.mode}${p.singleChoice ? ' • single-choice' : ''} • ${p.options.length} option(s)\n` +
          `• Channel: <#${p.channelId}> • [jump](https://discord.com/channels/${interaction.guildId}/${p.channelId}/${p.messageId})`,
      )
      .join('\n\n'),
  );
  return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed], ephemeralDefault: true });
}

/** /roles delete — drop the record, leave the message in place. */
async function runDelete(ctx, interaction, cmdCfg) {
  const panels = await service.getPanels(interaction.guildId);
  const panel = service.findPanel(panels, interaction.options.getString('panel', true));
  if (!panel) return replyError(interaction, `No panel with that name exists — see \`/roles list\`.`);

  const before = { panels };
  await service.savePanels(interaction.guildId, panels.filter((p) => p.id !== panel.id));
  await audit.log(interaction.guildId, interaction.user.id, 'config.panel.delete', 'module:roles', before, { panels: panels.filter((p) => p.id !== panel.id) });
  return respond(
    interaction,
    cmdCfg.responses.success,
    {},
    `🗑 Panel **${panel.name}** deleted. Its message was left in place — delete it manually or run \`/roles panel\` to recreate.`,
    { ephemeralDefault: true },
  );
}

/** /roles singlechoice — toggle the one-role-at-a-time flag. */
async function runSingleChoice(ctx, interaction, cmdCfg) {
  const panels = await service.getPanels(interaction.guildId);
  const panel = service.findPanel(panels, interaction.options.getString('panel', true));
  if (!panel) return replyError(interaction, `No panel with that name exists — see \`/roles list\`.`);

  const enabled = interaction.options.getBoolean('enabled', true);
  const before = { panels };
  const nextPanels = panels.map((p) => (p.id === panel.id ? { ...p, singleChoice: enabled } : p));
  await service.savePanels(interaction.guildId, nextPanels);
  const updated = nextPanels.find((p) => p.id === panel.id);
  const result = await updatePanelMessage(interaction.guild, updated);
  await audit.log(interaction.guildId, interaction.user.id, 'config.panel.singlechoice', 'module:roles', before, { panels: nextPanels });

  const suffix = result.missing ? '\n⚠️ The panel message could not be found — use `/roles repost` to repost it.' : '';
  return respond(
    interaction,
    cmdCfg.responses.success,
    {},
    `${enabled ? '🔒' : '🔓'} Panel **${panel.name}** is now ${enabled ? '**single-choice** (one role at a time)' : '**multi-choice**'}.${suffix}`,
    { ephemeralDefault: true },
  );
}

/** /roles repost — post the panel message again and rebind messageId. */
async function runRepost(ctx, interaction, cmdCfg) {
  const panels = await service.getPanels(interaction.guildId);
  const panel = service.findPanel(panels, interaction.options.getString('panel', true));
  if (!panel) return replyError(interaction, `No panel with that name exists — see \`/roles list\`.`);

  await interaction.deferReply({ flags: 64 });
  const message = await interaction.channel.send(service.buildPanelPayload(panel)).catch(() => null);
  if (!message) return replyError(interaction, 'I could not post the panel message in this channel — check my permissions.');

  const before = { panels };
  const nextPanels = panels.map((p) => (p.id === panel.id ? { ...p, channelId: interaction.channelId, messageId: message.id } : p));
  await service.savePanels(interaction.guildId, nextPanels);
  await audit.log(interaction.guildId, interaction.user.id, 'config.panel.repost', 'module:roles', before, { panels: nextPanels });
  return respond(interaction, cmdCfg.responses.success, {}, `📤 Panel **${panel.name}** reposted and bound to this message.`, { ephemeralDefault: true });
}

module.exports = { commands };
