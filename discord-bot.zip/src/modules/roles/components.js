'use strict';

const settings = require('../../core/settings');
const { replyError, replySimple } = require('../../core/responses');
const service = require('./service');

/**
 * roles/components.js — rr:<panelId>:<roleId> buttons and rr:sel:<panelId>
 * select menus. Buttons toggle; selects sync (add picked, remove unpicked
 * panel roles). Single-choice panels remove the previous role first.
 */

async function ensureModuleEnabled(interaction) {
  const modCfg = await settings.getModuleConfig(interaction.guildId, 'roles');
  return modCfg.enabled ? modCfg : null;
}

async function resolvePanel(interaction, panelId) {
  const panels = await service.getPanels(interaction.guildId);
  const panel = panels.find((p) => p.id === panelId);
  if (!panel) {
    await replyError(interaction, 'This reaction role panel no longer exists.');
    return null;
  }
  return panel;
}

/** rr:<panelId>:<roleId> — toggle one role. */
async function handleButton(ctx, interaction, panelId, roleId) {
  const panel = await resolvePanel(interaction, panelId);
  if (!panel) return;
  if (!panel.options.some((o) => o.roleId === roleId)) {
    return replyError(interaction, 'That role is no longer part of this panel.');
  }

  const guild = interaction.guild;
  const member = interaction.member;
  if (!member) return replyError(interaction, 'Member data unavailable — please try again.');

  const has = member.roles.cache.has(roleId);
  const added = [];
  const removed = [];
  const failed = [];

  if (has) {
    const result = await service.applyRoleChange(guild, member, roleId, false, 'Reaction role toggle');
    if (result.ok) removed.push(roleId);
    else failed.push(result.reason);
  } else {
    if (panel.singleChoice) {
      for (const other of panel.options.map((o) => o.roleId)) {
        if (other === roleId || !member.roles.cache.has(other)) continue;
        // eslint-disable-next-line no-await-in-loop
        const result = await service.applyRoleChange(guild, member, other, false, 'Reaction role single-choice switch');
        if (result.ok) removed.push(other);
        else failed.push(result.reason);
      }
    }
    const result = await service.applyRoleChange(guild, member, roleId, true, 'Reaction role toggle');
    if (result.ok) added.push(roleId);
    else failed.push(result.reason);
  }

  const parts = [];
  if (added.length) parts.push(`Gave you: ${added.map((id) => `<@&${id}>`).join(' ')}`);
  if (removed.length) parts.push(`Removed: ${removed.map((id) => `<@&${id}>`).join(' ')}`);
  if (failed.length) parts.push(`Failed: ${failed.join(' • ')}`);
  return replySimple(interaction, parts.join('\n') || 'No changes made.', { ephemeral: true });
}

/** rr:sel:<panelId> — sync member roles with the selected values. */
async function handleSelect(ctx, interaction, panelId) {
  const panel = await resolvePanel(interaction, panelId);
  if (!panel) return;

  const guild = interaction.guild;
  const member = interaction.member;
  if (!member) return replyError(interaction, 'Member data unavailable — please try again.');

  const panelRoleIds = panel.options.map((o) => o.roleId);
  const picked = (interaction.values || []).filter((value) => panelRoleIds.includes(value));
  const toAdd = picked.filter((id) => !member.roles.cache.has(id));
  const toRemove = panelRoleIds.filter((id) => member.roles.cache.has(id) && !picked.includes(id));

  const added = [];
  const removed = [];
  const failed = [];

  for (const roleId of toRemove) {
    // eslint-disable-next-line no-await-in-loop
    const result = await service.applyRoleChange(guild, member, roleId, false, 'Reaction role menu sync');
    if (result.ok) removed.push(roleId);
    else failed.push(result.reason);
  }
  for (const roleId of toAdd) {
    // eslint-disable-next-line no-await-in-loop
    const result = await service.applyRoleChange(guild, member, roleId, true, 'Reaction role menu sync');
    if (result.ok) added.push(roleId);
    else failed.push(result.reason);
  }

  const parts = [];
  if (added.length) parts.push(`Gave you: ${added.map((id) => `<@&${id}>`).join(' ')}`);
  if (removed.length) parts.push(`Removed: ${removed.map((id) => `<@&${id}>`).join(' ')}`);
  if (failed.length) parts.push(`Failed: ${failed.join(' • ')}`);
  return replySimple(interaction, parts.join('\n') || 'Your roles already match that selection.', { ephemeral: true });
}

/** Route rr:* component interactions. rest = customId without the 'rr:' prefix. */
async function handleComponent(ctx, interaction, rest) {
  const modCfg = await ensureModuleEnabled(interaction);
  if (!modCfg) return replyError(interaction, 'The reaction role system is currently disabled.');

  if (rest.startsWith('sel:')) return handleSelect(ctx, interaction, rest.slice('sel:'.length));

  const [panelId, roleId] = rest.split(':');
  if (!panelId || !roleId) return replyError(interaction, 'Unknown reaction role action.');
  return handleButton(ctx, interaction, panelId, roleId);
}

module.exports = { handleComponent };
