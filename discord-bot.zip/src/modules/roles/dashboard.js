'use strict';

const service = require('./service');

/** roles/dashboard.js — summary lines for the module dashboard overview. */
module.exports = {
  async summaryLines(guild, modCfg) {
    const panels = Array.isArray(modCfg.settings?.panels) ? modCfg.settings.panels : [];
    const totalOptions = panels.reduce((acc, p) => acc + (p.options?.length || 0), 0);
    const singleChoice = panels.filter((p) => p.singleChoice).length;
    return [
      ['Panels', `${panels.length}`],
      ['Role options', `${totalOptions}`],
      ['Single-choice panels', `${singleChoice}`],
    ];
  },
};
