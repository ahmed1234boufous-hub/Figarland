'use strict';

const { commands } = require('./commands');
const components = require('./components');
const dashboard = require('./dashboard');

/**
 * roles — reaction role panels backed by ModuleConfig('roles') settings.panels.
 *
 * Component prefix: 'rr:' (rr:<panelId>:<roleId> buttons and
 * rr:sel:<panelId> select menus).
 */

module.exports = {
  key: 'roles',
  name: 'Reaction Roles',
  emoji: '🎭',
  dashboardCommandName: 'roles-dashboard',

  // Panels live in settings.panels but are managed through /roles subcommands
  // (storing objects), so there are no dashboard-editable scalar settings.
  settingsSchema: [],

  defaults: {
    enabled: true,
    settings: {
      panels: [],
    },
    commands: {
      roles: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
    },
  },

  commands,

  dashboard,

  componentHandlers: { 'rr:': components.handleComponent },
};
