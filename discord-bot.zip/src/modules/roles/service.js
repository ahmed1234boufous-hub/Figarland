'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  PermissionFlagsBits,
} = require('discord.js');
const settings = require('../../core/settings');
const config = require('../../config');

/**
 * roles/service.js — reaction role panel storage (ModuleConfig('roles')
 * settings.panels), component builders and role-assignment safety checks.
 */

const MAX_OPTIONS = 25;

const STYLE_BY_NAME = { Primary: ButtonStyle.Primary, Secondary: ButtonStyle.Secondary, Success: ButtonStyle.Success, Danger: ButtonStyle.Danger };
const NAME_BY_STYLE = { [ButtonStyle.Primary]: 'Primary', [ButtonStyle.Secondary]: 'Secondary', [ButtonStyle.Success]: 'Success', [ButtonStyle.Danger]: 'Danger' };

function styleFromName(name) {
  return STYLE_BY_NAME[name] || ButtonStyle.Secondary;
}

function normalizeMode(mode) {
  return mode === 'select' ? 'select' : 'buttons';
}

function newPanelId() {
  return `p${Date.now().toString(36)}`;
}

async function getPanels(guildId) {
  const modCfg = await settings.getModuleConfig(guildId, 'roles');
  const panels = modCfg.settings?.panels;
  return Array.isArray(panels) ? panels : [];
}

/** Persist the full panels array back into ModuleConfig('roles'). */
async function savePanels(guildId, panels) {
  await settings.setModuleSetting(guildId, 'roles', 'panels', panels);
  return panels;
}

function findPanel(panels, nameOrId) {
  const needle = String(nameOrId || '').trim();
  if (!needle) return null;
  return panels.find((p) => p.id === needle) || panels.find((p) => p.name.toLowerCase() === needle.toLowerCase()) || null;
}

// ───────────────────────────── Panel rendering ───────────────────────────────

function describePanelLine(panel, option) {
  const emoji = option.emoji ? `${option.emoji} ` : '';
  const desc = panel.mode === 'select' && option.description ? ` — ${option.description}` : '';
  return `${emoji}<@&${option.roleId}> \u2022 ${option.label}${desc}`;
}

function buildPanelEmbed(panel) {
  const lines = panel.options.length ? panel.options.map((o) => describePanelLine(panel, o)) : ['No roles yet — add some with `/roles add`.'];
  return new EmbedBuilder()
    .setTitle(`${panel.name}`.slice(0, 256))
    .setColor(config.embedColor)
    .setDescription(
      [
        panel.mode === 'select' ? 'Pick your roles from the menu below.' : 'Click a button below to get or remove the role.',
        '',
        ...lines,
      ].join('\n'),
    )
    .setFooter({ text: [panel.mode === 'select' ? 'Select menu' : 'Buttons', panel.singleChoice ? 'One role at a time' : null].filter(Boolean).join(' • ') });
}

/** Apply an emoji to a builder without failing on malformed input. */
function applyEmoji(builder, emoji) {
  if (!emoji) return builder;
  try {
    return builder.setEmoji(emoji);
  } catch {
    return builder;
  }
}

/** Buttons: 5 per row, 25 total. Select: one StringSelectMenu, 25 options. */
function buildComponents(panel) {
  const options = (panel.options || []).slice(0, MAX_OPTIONS);
  if (!options.length) return [];

  if (panel.mode === 'select') {
    const menu = new StringSelectMenuBuilder()
      .setCustomId(`rr:sel:${panel.id}`)
      .setPlaceholder(panel.singleChoice ? 'Pick one role…' : 'Pick your roles…')
      .setMinValues(0)
      .setMaxValues(panel.singleChoice ? 1 : Math.min(MAX_OPTIONS, options.length));
    for (const o of options) {
      const data = { label: String(o.label).slice(0, 100), value: o.roleId };
      if (o.description) data.description = String(o.description).slice(0, 100);
      if (o.emoji) data.emoji = o.emoji; // invalid emoji data is rejected by setOptions guard below
      try {
        menu.addOptions(data);
      } catch {
        /* skip an option with malformed data rather than failing the panel */
      }
    }
    return [new ActionRowBuilder().addComponents(menu)];
  }

  const rows = [];
  for (let i = 0; i < options.length && rows.length < 5; i += 5) {
    const row = new ActionRowBuilder();
    for (const option of options.slice(i, i + 5)) {
      let button = new ButtonBuilder()
        .setCustomId(`rr:${panel.id}:${option.roleId}`)
        .setLabel(String(option.label).slice(0, 80))
        .setStyle(option.style >= 1 && option.style <= 4 ? option.style : ButtonStyle.Secondary);
      button = applyEmoji(button, option.emoji);
      row.addComponents(button);
    }
    rows.push(row);
  }
  return rows;
}

/** Build the full message payload for a panel (embed + components). */
function buildPanelPayload(panel) {
  return { embeds: [buildPanelEmbed(panel)], components: buildComponents(panel) };
}

// ─────────────────────────── Role safety helpers ─────────────────────────────

/**
 * Verify the bot may assign this role.
 * @returns {{ ok: boolean, reason?: string }}
 */
function checkRoleAssignable(guild, role) {
  if (!role) return { ok: false, reason: 'That role no longer exists.' };
  if (role.id === guild.id) return { ok: false, reason: 'The @everyone role cannot be assigned.' };
  if (role.managed) return { ok: false, reason: `<@&${role.id}> is managed by an integration and cannot be assigned.` };
  if (role.position >= guild.members.me.roles.highest.position) {
    return { ok: false, reason: `<@&${role.id}> is above my highest role — move my role higher in Server Settings.` };
  }
  return { ok: true };
}

/**
 * Add or remove one role with full safety checks.
 * @returns {{ ok: boolean, reason?: string }}
 */
async function applyRoleChange(guild, member, roleId, add, reason) {
  const role = guild.roles.cache.get(roleId);
  const assignable = checkRoleAssignable(guild, role);
  if (!assignable.ok) return assignable;
  const has = member.roles.cache.has(roleId);
  try {
    if (add && !has) await member.roles.add(roleId, reason);
    else if (!add && has) await member.roles.remove(roleId, reason);
    return { ok: true };
  } catch (err) {
    return { ok: false, reason: `Could not ${add ? 'add' : 'remove'} <@&${roleId}>: ${err?.message || 'unknown error'}` };
  }
}

module.exports = {
  MAX_OPTIONS,
  NAME_BY_STYLE,
  styleFromName,
  normalizeMode,
  newPanelId,
  getPanels,
  savePanels,
  findPanel,
  buildPanelEmbed,
  buildComponents,
  buildPanelPayload,
  checkRoleAssignable,
  applyRoleChange,
};
