'use strict';

const db = require('../../core/db');

module.exports = {
  async summaryLines(guild, modCfg) {
    const s = modCfg.settings || {};
    const [users, walletAgg, bankAgg] = await Promise.all([
      db.economyUser.count({ where: { guildId: guild.id } }),
      db.economyUser.aggregate({ _sum: { wallet: true }, where: { guildId: guild.id } }),
      db.economyUser.aggregate({ _sum: { bank: true }, where: { guildId: guild.id } }),
    ]);
    return [
      ['Currency', `${s.currencySymbol || ''} ${s.currencyName || 'coins'}`.trim()],
      ['Tracked users', `${users}`],
      ['In circulation', `${s.currencySymbol || ''} ${(walletAgg._sum.wallet || 0) + (bankAgg._sum.bank || 0)}`.trim()],
      ['Gambling', s.gamblingEnabled ? 'Enabled' : 'Disabled'],
    ];
  },
};
