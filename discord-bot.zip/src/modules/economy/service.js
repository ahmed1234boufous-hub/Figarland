'use strict';

const db = require('../../core/db');

/**
 * Economy service — balances, payouts, transaction ledger and formatting.
 * Balances are clamped so they can never go negative.
 */

function randInt(min, max) {
  if (!Number.isFinite(min) || !Number.isFinite(max)) return 0;
  const lo = Math.ceil(Math.min(min, max));
  const hi = Math.floor(Math.max(min, max));
  if (hi <= lo) return Math.max(0, lo);
  return Math.floor(Math.random() * (hi - lo + 1)) + lo;
}

function clampAmount(n) {
  const v = Math.floor(Number(n) || 0);
  return v < 0 ? 0 : v;
}

/** Fetch or lazily create an economy user (new wallets start at startBalance). */
async function getUser(guildId, userId, startBalance = 0) {
  return db.economyUser.upsert({
    where: { guildId_userId: { guildId, userId } },
    create: { guildId, userId, wallet: clampAmount(startBalance) },
    update: {},
  });
}

async function findRow(guildId, userId) {
  return db.economyUser.findUnique({ where: { guildId_userId: { guildId, userId } } });
}

/** Set a wallet to an exact (clamped) value. */
async function setWallet(guildId, userId, value) {
  const wallet = clampAmount(value);
  await db.economyUser.update({ where: { guildId_userId: { guildId, userId } }, data: { wallet } }).catch(() => {});
  return wallet;
}

/** Append a row to the transaction ledger. Never throws. */
async function logTx({ guildId, fromId = null, toId = null, amount, type, note = null }) {
  try {
    return await db.transaction.create({
      data: { guildId, fromId, toId, amount: Math.round(amount), type, note: note || null },
    });
  } catch {
    return null;
  }
}

// ── Time helpers (daily/weekly use UTC calendar days) ────────────────────────

function utcDay(ts) {
  const d = new Date(ts);
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
}

function nextUtcMidnight(ts) {
  const d = new Date(ts);
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1);
}

function fmtDuration(ms) {
  let s = Math.max(0, Math.ceil(ms / 1000));
  const d = Math.floor(s / 86400);
  s -= d * 86400;
  const h = Math.floor(s / 3600);
  s -= h * 3600;
  const m = Math.floor(s / 60);
  s -= m * 60;
  const parts = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  if (!d && !h && s) parts.push(`${s}s`);
  return parts.join(' ') || '0s';
}

/** Parse a deposit/withdraw amount: a positive number or the word "all". */
function parseAmount(raw, current) {
  const text = String(raw || '').trim().toLowerCase();
  if (text === 'all' || text === 'max') return current;
  const n = Number(text);
  if (!Number.isFinite(n)) return null;
  return Math.floor(n);
}

// ── Flavor text (safe, non-branded) ─────────────────────────────────────────

const WORK_LINES = [
  'You sorted through a mountain of paperwork and earned {amount}.',
  'You fixed a wobbly table for a neighbour and earned {amount}.',
  'You helped carry boxes all afternoon and earned {amount}.',
  'You watered the community garden and earned {amount}.',
  'You tested board games for a local shop and earned {amount}.',
  'You proofread a friend\u2019s essay and earned {amount}.',
  'You cleaned out a dusty garage and earned {amount}.',
  'You taught someone the basics of chess and earned {amount}.',
  'You folded a hundred pizza boxes and earned {amount}.',
  'You assembled flat-pack furniture without leftovers and earned {amount}.',
];

const CRIME_WIN_LINES = [
  'You refurbished a thrift-store find and flipped it for {amount}.',
  'You won a hot-dog eating contest and pocketed {amount}.',
  'You found a forgotten gift card in an old coat — worth {amount}.',
  'Your jigsaw puzzle championship run paid out {amount}.',
  'You traded up from a paperclip to a bicycle kit and gained {amount}.',
];

const CRIME_FAIL_LINES = [
  'Your street magic trick did not impress the crowd — down {amount}.',
  'You invested in a suspicious timeshare and lost {amount}.',
  'Your homemade candle business melted away {amount}.',
  'A pigeon made off with your sandwich and your {amount}.',
  'You backed the wrong llama in a race and lost {amount}.',
];

function pickLine(lines, replacements) {
  const raw = lines[randInt(0, lines.length - 1)] || '';
  return raw.replaceAll('{amount}', replacements.amount).replaceAll('{symbol}', replacements.symbol);
}

module.exports = {
  randInt,
  clampAmount,
  getUser,
  findRow,
  setWallet,
  logTx,
  utcDay,
  nextUtcMidnight,
  fmtDuration,
  parseAmount,
  pickLine,
  WORK_LINES,
  CRIME_WIN_LINES,
  CRIME_FAIL_LINES,
};
