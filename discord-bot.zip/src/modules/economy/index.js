'use strict';

const { commands, buildBalanceEmbed } = require('./commands');
const service = require('./service');
const dashboard = require('./dashboard');

module.exports = {
  key: 'economy',
  name: 'Economy',
  emoji: '💰',
  dashboardCommandName: 'economy-dashboard',

  settingsSchema: [
    { key: 'currencyName', label: 'Currency name', type: 'text', desc: 'Displayed in balances and shops.' },
    { key: 'currencySymbol', label: 'Currency symbol', type: 'text', desc: 'Emoji or short prefix shown before amounts.' },
    { key: 'startBalance', label: 'Starting balance', type: 'number', desc: 'Wallet amount for first-time members.' },
    { key: 'dailyMin', label: 'Daily min', type: 'number', desc: 'Lower bound of the random daily payout.' },
    { key: 'dailyMax', label: 'Daily max', type: 'number', desc: 'Upper bound of the random daily payout.' },
    { key: 'weeklyMin', label: 'Weekly min', type: 'number', desc: 'Lower bound of the random weekly payout.' },
    { key: 'weeklyMax', label: 'Weekly max', type: 'number', desc: 'Upper bound of the random weekly payout.' },
    { key: 'workMin', label: 'Work min', type: 'number', desc: 'Lower bound of the random work payout.' },
    { key: 'workMax', label: 'Work max', type: 'number', desc: 'Upper bound of the random work payout.' },
    { key: 'payLimit', label: 'Pay limit', type: 'number', desc: 'Maximum amount a single /pay may transfer.' },
    { key: 'gamblingEnabled', label: 'Gambling enabled', type: 'boolean', desc: 'Allows /coinflip bets.' },
    { key: 'robEnabled', label: 'Robbing enabled', type: 'boolean', desc: 'Allows /rob attempts.' },
    { key: 'crimeEnabled', label: 'Crime enabled', type: 'boolean', desc: 'Allows /crime schemes.' },
    { key: 'workCooldownMinutes', label: 'Work cooldown (minutes)', type: 'number', desc: 'Time between two /work shifts.' },
  ],

  defaults: {
    enabled: true,
    settings: {
      currencyName: 'coins',
      currencySymbol: '🪙',
      startBalance: 100,
      dailyMin: 100,
      dailyMax: 200,
      weeklyMin: 500,
      weeklyMax: 1000,
      workMin: 50,
      workMax: 150,
      payLimit: 10000,
      gamblingEnabled: true,
      robEnabled: true,
      crimeEnabled: true,
      workCooldownMinutes: 60,
      dashboardRoles: [],
    },
    commands: {
      balance: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      daily: { cooldown: 3, responses: { success: { text: '🎁 {symbol}**{amount}** claimed — daily streak **{streak}** day(s).', ephemeral: false } } },
      weekly: { cooldown: 3, responses: { success: { text: '📦 You opened the weekly crate: {symbol}**{amount}**!', ephemeral: false } } },
      work: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      deposit: { cooldown: 3, responses: { success: { text: '🏦 Deposited {symbol}**{amount}** into your bank.', ephemeral: true } } },
      withdraw: { cooldown: 3, responses: { success: { text: '🏧 Withdrew {symbol}**{amount}** from your bank.', ephemeral: true } } },
      pay: { cooldown: 3, responses: { success: { text: '💸 Sent {symbol}**{amount}** to {target}.', ephemeral: false } } },
      shop: { cooldown: 3, responses: { success: { text: '', ephemeral: true } } },
      buy: { cooldown: 5, responses: { success: { text: '', ephemeral: true } } },
      inventory: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      coinflip: { cooldown: 5, responses: { success: { text: '', ephemeral: false } } },
      rob: { cooldown: 300, responses: { success: { text: '', ephemeral: false } } },
      crime: { cooldown: 600, responses: { success: { text: '', ephemeral: false } } },
    },
  },

  commands,

  dashboard,

  componentHandlers: {
    'eco:': async (ctx, interaction, rest) => {
      try {
        if ((rest || '') !== 'bal') return;
        const modCfg = await ctx.settings.getModuleConfig(interaction.guildId, 'economy');
        const s = modCfg.settings;
        const row = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);
        const embed = buildBalanceEmbed(interaction.user, row, s);
        await interaction.update({ embeds: [embed], components: interaction.message.components }).catch(() => {});
      } catch (err) {
        ctx.logger.warn(`[economy] component failed: ${err?.message || err}`);
      }
    },
  },

  modalHandlers: {},

  hooks: {},

  schedulerJobs: [],
};
