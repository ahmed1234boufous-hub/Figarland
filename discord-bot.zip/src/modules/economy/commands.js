'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
} = require('discord.js');
const { respond, replyError } = require('../../core/responses');
const settings = require('../../core/settings');
const audit = require('../../core/audit');
const config = require('../../config');
const db = require('../../core/db');
const service = require('./service');

const STR = ApplicationCommandOptionType.String;
const INT = ApplicationCommandOptionType.Integer;
const USER = ApplicationCommandOptionType.User;
const ROLE = ApplicationCommandOptionType.Role;

function trunc(text, n) {
  const s = String(text || '');
  return s.length > n ? `${s.slice(0, n - 1)}…` : s;
}

function fmt(n) {
  return `${Math.floor(n)}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/** Balance embed shared by /balance and the eco:bal refresh button. */
function buildBalanceEmbed(user, row, s) {
  return new EmbedBuilder()
    .setTitle(`💰 ${user.username} — ${s.currencyName}`)
    .setColor(config.embedColor)
    .setThumbnail(user.displayAvatarURL({ size: 256, extension: 'png' }))
    .addFields(
      { name: 'Wallet', value: `${s.currencySymbol} ${fmt(row.wallet)}`, inline: true },
      { name: 'Bank', value: `${s.currencySymbol} ${fmt(row.bank)}`, inline: true },
      { name: 'Net worth', value: `${s.currencySymbol} ${fmt(row.wallet + row.bank)}`, inline: true },
    )
    .setFooter({ text: `Daily streak: ${row.dailyStreak} day(s)` });
}

async function getModSettings(guildId) {
  const modCfg = await settings.getModuleConfig(guildId, 'economy');
  return modCfg;
}

const commands = [
  {
    name: 'balance',
    description: "Show your wallet and bank balance (or another member's).",
    cooldown: 3,
    options: [{ name: 'user', description: 'Member to inspect (default: you)', type: USER, required: false }],
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      const target = interaction.options.getUser('user') || interaction.user;
      const row = await service.getUser(interaction.guildId, target.id, s.startBalance);
      const embed = buildBalanceEmbed(target, row, s);
      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('eco:bal').setLabel('Refresh my balance').setStyle(ButtonStyle.Secondary),
      );
      return respond(
        interaction,
        cmdCfg.responses.success,
        { user: `<@${target.id}>`, amount: row.wallet, currency: s.currencyName, symbol: s.currencySymbol },
        null,
        { embeds: [embed], components: [buttons] },
      );
    },
  },
  {
    name: 'daily',
    description: 'Claim your daily reward and build up a streak.',
    cooldown: 3,
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      const now = Date.now();
      const row = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);
      if (row.lastDaily && service.utcDay(row.lastDaily.getTime()) >= service.utcDay(now)) {
        const left = service.nextUtcMidnight(now) - now;
        return replyError(interaction, `You already claimed your daily reward — come back in **${service.fmtDuration(left)}**.`);
      }
      const claimedYesterday = row.lastDaily && service.utcDay(row.lastDaily.getTime()) === service.utcDay(now - 86400000);
      const streak = claimedYesterday ? row.dailyStreak + 1 : 1;
      const payout = service.randInt(s.dailyMin, s.dailyMax) + Math.min(500, streak * 10);
      await db.economyUser.update({
        where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
        data: { wallet: { increment: payout }, lastDaily: new Date(now), dailyStreak: streak },
      });
      await service.logTx({ guildId: interaction.guildId, toId: interaction.user.id, amount: payout, type: 'daily', note: `streak ${streak}` });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { symbol: s.currencySymbol, currency: s.currencyName, amount: payout, streak, user: `<@${interaction.user.id}>` },
        `🎁 You claimed ${s.currencySymbol} **${fmt(payout)}**! Daily streak: **${streak}** day(s).`,
      );
    },
  },
  {
    name: 'weekly',
    description: 'Claim your weekly reward crate.',
    cooldown: 3,
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      const now = Date.now();
      const row = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);
      const week = 7 * 86400000;
      if (row.lastWeekly && now - row.lastWeekly.getTime() < week) {
        const left = week - (now - row.lastWeekly.getTime());
        return replyError(interaction, `You already claimed your weekly reward — come back in **${service.fmtDuration(left)}**.`);
      }
      const payout = service.randInt(s.weeklyMin, s.weeklyMax);
      await db.economyUser.update({
        where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
        data: { wallet: { increment: payout }, lastWeekly: new Date(now) },
      });
      await service.logTx({ guildId: interaction.guildId, toId: interaction.user.id, amount: payout, type: 'weekly' });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { symbol: s.currencySymbol, currency: s.currencyName, amount: payout, user: `<@${interaction.user.id}>` },
        `📦 You opened the weekly crate and found ${s.currencySymbol} **${fmt(payout)}**!`,
      );
    },
  },
  {
    name: 'work',
    description: 'Earn some honest currency with a odd job.',
    cooldown: 3,
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      const now = Date.now();
      const row = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);
      const cooldownMs = Math.max(0, parseInt(s.workCooldownMinutes, 10) || 0) * 60000;
      if (row.lastWork && cooldownMs > 0 && now - row.lastWork.getTime() < cooldownMs) {
        const left = cooldownMs - (now - row.lastWork.getTime());
        return replyError(interaction, `You are still tired from your last shift — next shift in **${service.fmtDuration(left)}**.`);
      }
      const payout = service.randInt(s.workMin, s.workMax);
      await db.economyUser.update({
        where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
        data: { wallet: { increment: payout }, lastWork: new Date(now) },
      });
      await service.logTx({ guildId: interaction.guildId, toId: interaction.user.id, amount: payout, type: 'work' });
      const line = service.pickLine(service.WORK_LINES, { amount: `${s.currencySymbol} ${fmt(payout)}`, symbol: s.currencySymbol });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { symbol: s.currencySymbol, currency: s.currencyName, amount: payout, user: `<@${interaction.user.id}>` },
        `🧰 ${line}`,
      );
    },
  },
  {
    name: 'deposit',
    description: 'Move currency from your wallet into the bank.',
    cooldown: 3,
    options: [{ name: 'amount', description: "Amount to deposit, or \"all\"", type: STR, required: true }],
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      const row = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);
      const amount = service.parseAmount(interaction.options.getString('amount', true), row.wallet);
      if (amount === null || amount <= 0) return replyError(interaction, 'Enter a positive number, or `all`.');
      if (row.wallet <= 0) return replyError(interaction, 'Your wallet is empty.');
      if (amount > row.wallet) return replyError(interaction, `You only have ${s.currencySymbol} **${fmt(row.wallet)}** in your wallet.`);
      await db.economyUser.update({
        where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
        data: { wallet: { decrement: amount }, bank: { increment: amount } },
      });
      await service.logTx({ guildId: interaction.guildId, fromId: interaction.user.id, toId: interaction.user.id, amount, type: 'deposit' });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { symbol: s.currencySymbol, amount, currency: s.currencyName },
        `🏦 Deposited ${s.currencySymbol} **${fmt(amount)}** into your bank.`,
      );
    },
  },
  {
    name: 'withdraw',
    description: 'Move currency from your bank back to your wallet.',
    cooldown: 3,
    options: [{ name: 'amount', description: "Amount to withdraw, or \"all\"", type: STR, required: true }],
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      const row = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);
      const amount = service.parseAmount(interaction.options.getString('amount', true), row.bank);
      if (amount === null || amount <= 0) return replyError(interaction, 'Enter a positive number, or `all`.');
      if (row.bank <= 0) return replyError(interaction, 'Your bank is empty.');
      if (amount > row.bank) return replyError(interaction, `You only have ${s.currencySymbol} **${fmt(row.bank)}** in the bank.`);
      await db.economyUser.update({
        where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
        data: { wallet: { increment: amount }, bank: { decrement: amount } },
      });
      await service.logTx({ guildId: interaction.guildId, fromId: interaction.user.id, toId: interaction.user.id, amount, type: 'withdraw' });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { symbol: s.currencySymbol, amount, currency: s.currencyName },
        `🏧 Withdrew ${s.currencySymbol} **${fmt(amount)}** from your bank.`,
      );
    },
  },
  {
    name: 'pay',
    description: 'Send currency to another member.',
    cooldown: 3,
    options: [
      { name: 'user', description: 'Member to pay', type: USER, required: true },
      { name: 'amount', description: 'Amount to send', type: INT, required: true, minValue: 1 },
    ],
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      const target = interaction.options.getUser('user', true);
      const amount = interaction.options.getInteger('amount', true);
      if (target.bot) return replyError(interaction, 'You cannot pay bots.');
      if (target.id === interaction.user.id) return replyError(interaction, 'You cannot pay yourself.');
      if (amount > s.payLimit) {
        return replyError(interaction, `The maximum you can send at once is ${s.currencySymbol} **${fmt(s.payLimit)}**.`);
      }
      const sender = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);
      if (sender.wallet < amount) {
        return replyError(interaction, `You only have ${s.currencySymbol} **${fmt(sender.wallet)}** in your wallet.`);
      }
      await service.getUser(interaction.guildId, target.id, s.startBalance);
      await db.economyUser.update({
        where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
        data: { wallet: { decrement: amount } },
      });
      await db.economyUser.update({
        where: { guildId_userId: { guildId: interaction.guildId, userId: target.id } },
        data: { wallet: { increment: amount } },
      });
      await service.logTx({ guildId: interaction.guildId, fromId: interaction.user.id, toId: target.id, amount, type: 'pay', note: 'sent' });
      await service.logTx({ guildId: interaction.guildId, fromId: interaction.user.id, toId: target.id, amount, type: 'pay', note: 'received' });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { symbol: s.currencySymbol, amount, target: `<@${target.id}>`, currency: s.currencyName },
        `💸 Sent ${s.currencySymbol} **${fmt(amount)}** to <@${target.id}>.`,
      );
    },
  },
  {
    name: 'shop',
    description: 'Browse the server shop or manage its items.',
    cooldown: 3,
    options: [
      { name: 'list', description: 'List all active shop items', type: 1, options: [] },
      {
        name: 'add',
        description: 'Add a new item to the shop',
        type: 1,
        options: [
          { name: 'name', description: 'Item name', type: STR, required: true },
          { name: 'price', description: 'Price in currency', type: INT, required: true, minValue: 1 },
          { name: 'description', description: 'Short item description', type: STR, required: false, maxLength: 200 },
          { name: 'stock', description: 'Stock count (-1 = unlimited)', type: INT, required: false, minValue: -1 },
          { name: 'role_reward', description: 'Role granted on purchase', type: ROLE, required: false },
          { name: 'per_user_limit', description: 'How often one member can buy it (0 = unlimited)', type: INT, required: false, minValue: 0 },
        ],
      },
      {
        name: 'remove',
        description: 'Remove an item from the shop',
        type: 1,
        options: [{ name: 'name', description: 'Item name', type: STR, required: true }],
      },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand();
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;

      if (sub === 'list') {
        const items = await db.shopItem.findMany({ where: { guildId: interaction.guildId, active: true }, orderBy: { price: 'asc' } });
        if (!items.length) {
          return respond(interaction, cmdCfg.responses.success, {}, '🛒 The shop is empty — staff can add items with `/shop add`.', {});
        }
        const lines = items.slice(0, 25).map((item) => {
          const stock = item.stock < 0 ? 'Unlimited' : `${item.stock} in stock`;
          const reward = item.roleRewardId ? ` • role <@&${item.roleRewardId}>` : '';
          const limit = item.perUserLimit > 0 ? ` • limit ${item.perUserLimit}/member` : '';
          return `**${item.name}** — ${s.currencySymbol} ${fmt(item.price)} • ${stock}${reward}${limit}`;
        });
        const embed = new EmbedBuilder()
          .setTitle(`🛒 Server shop — ${s.currencyName}`)
          .setColor(config.embedColor)
          .setDescription(lines.join('\n').slice(0, 4000))
          .setFooter({ text: `Buy with /buy item:<name> • ${items.length} item(s)` });
        return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
      }

      if (sub === 'add') {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
          return replyError(interaction, 'You need the **Manage Server** permission to manage the shop.');
        }
        const name = interaction.options.getString('name', true).trim();
        const price = interaction.options.getInteger('price', true);
        const description = interaction.options.getString('description') || '';
        const stock = interaction.options.getInteger('stock');
        const roleReward = interaction.options.getRole('role_reward');
        const perUserLimit = interaction.options.getInteger('per_user_limit');

        if (roleReward) {
          if (roleReward.managed) return replyError(interaction, 'That role is managed by an integration and cannot be a reward.');
          if (roleReward.position >= interaction.guild.members.me.roles.highest.position) {
            return replyError(interaction, 'That role is above my highest role — I would not be able to grant it.');
          }
        }
        const activeItems = await db.shopItem.findMany({ where: { guildId: interaction.guildId, active: true }, select: { name: true } });
        if (activeItems.some((i) => i.name.toLowerCase() === name.toLowerCase())) {
          return replyError(interaction, `An active item named **${name}** already exists.`);
        }

        const item = await db.shopItem.create({
          data: {
            guildId: interaction.guildId,
            name,
            description,
            price,
            stock: stock ?? -1,
            roleRewardId: roleReward?.id || null,
            perUserLimit: perUserLimit ?? 0,
          },
        });
        await audit.log(interaction.guildId, interaction.user.id, 'config.shop.add', 'economy:shop', null, {
          id: item.id,
          name,
          price,
          stock: item.stock,
          roleRewardId: item.roleRewardId,
          perUserLimit: item.perUserLimit,
        });
        return respond(
          interaction,
          cmdCfg.responses.success,
          { item: name, amount: price, symbol: s.currencySymbol },
          `✅ Added **${name}** to the shop for ${s.currencySymbol} **${fmt(price)}** (stock: ${item.stock < 0 ? 'unlimited' : item.stock}).`,
        );
      }

      // remove
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
        return replyError(interaction, 'You need the **Manage Server** permission to manage the shop.');
      }
      const name = interaction.options.getString('name', true).trim();
      const items = await db.shopItem.findMany({ where: { guildId: interaction.guildId, active: true } });
      const item = items.find((i) => i.name.toLowerCase() === name.toLowerCase());
      if (!item) return replyError(interaction, `No active item named **${name}** exists.`);
      await db.shopItem.update({ where: { id: item.id }, data: { active: false } });
      await audit.log(interaction.guildId, interaction.user.id, 'config.shop.remove', 'economy:shop', { id: item.id, name: item.name }, null);
      return respond(interaction, cmdCfg.responses.success, { item: item.name, symbol: s.currencySymbol }, `🗑️ Removed **${item.name}** from the shop (past purchases are kept).`);
    },
  },
  {
    name: 'buy',
    description: 'Buy an item from the server shop.',
    cooldown: 5,
    options: [{ name: 'item', description: 'Name of the item to buy', type: STR, required: true }],
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      const wanted = interaction.options.getString('item', true).trim().toLowerCase();
      const items = await db.shopItem.findMany({ where: { guildId: interaction.guildId, active: true } });
      const item = items.find((i) => i.name.toLowerCase() === wanted);
      if (!item) return replyError(interaction, 'That item is not in the shop — check `/shop list`.');
      if (item.stock === 0) return replyError(interaction, `**${item.name}** is out of stock.`);
      if (item.perUserLimit > 0) {
        const bought = await db.purchase.aggregate({
          _sum: { qty: true },
          where: { guildId: interaction.guildId, userId: interaction.user.id, itemId: item.id },
        });
        if ((bought._sum.qty || 0) + 1 > item.perUserLimit) {
          return replyError(interaction, `You already reached the purchase limit for **${item.name}** (${item.perUserLimit}).`);
        }
      }
      const row = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);
      if (row.wallet < item.price) {
        return replyError(interaction, `You need ${s.currencySymbol} **${fmt(item.price)}** but only have ${s.currencySymbol} **${fmt(row.wallet)}** in your wallet.`);
      }

      await db.economyUser.update({
        where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
        data: { wallet: { decrement: item.price } },
      });
      if (item.stock > 0) {
        await db.shopItem.update({ where: { id: item.id }, data: { stock: { decrement: 1 } } }).catch(() => {});
      }
      await db.purchase.create({
        data: { guildId: interaction.guildId, userId: interaction.user.id, itemId: item.id, qty: 1, pricePaid: item.price },
      });
      await service.logTx({ guildId: interaction.guildId, fromId: interaction.user.id, amount: item.price, type: 'shop', note: item.name });

      let roleNote = '';
      if (item.roleRewardId) {
        const role = interaction.guild.roles.cache.get(item.roleRewardId);
        const me = interaction.guild.members.me;
        if (role && !role.managed && me && role.position < me.roles.highest.position) {
          await interaction.member.roles.add(role.id, 'Shop purchase').catch(() => {});
          roleNote = ` Role <@&${role.id}> assigned.`;
        } else {
          roleNote = ' (The role reward could not be assigned — please contact a staff member.)';
        }
      }
      return respond(
        interaction,
        cmdCfg.responses.success,
        { item: item.name, amount: item.price, symbol: s.currencySymbol, currency: s.currencyName },
        `🛒 You bought **${item.name}** for ${s.currencySymbol} **${fmt(item.price)}**.${roleNote}`,
      );
    },
  },
  {
    name: 'inventory',
    description: 'Show the items you have purchased.',
    cooldown: 3,
    async run(ctx, interaction, cmdCfg) {
      const rows = await db.purchase.groupBy({
        by: ['itemId'],
        _sum: { qty: true },
        where: { guildId: interaction.guildId, userId: interaction.user.id },
      });
      if (!rows.length) {
        return respond(interaction, cmdCfg.responses.success, {}, '🎒 Your inventory is empty — visit `/shop list`.', {});
      }
      const items = await db.shopItem.findMany({ where: { id: { in: rows.map((r) => r.itemId) } } });
      const nameById = new Map(items.map((i) => [i.id, i.name]));
      const lines = rows.map((r) => `• **${nameById.get(r.itemId) || 'Unknown item'}** ×${r._sum.qty || 0}`);
      const embed = new EmbedBuilder()
        .setTitle(`🎒 Inventory — ${interaction.user.username}`)
        .setColor(config.embedColor)
        .setDescription(lines.join('\n').slice(0, 4000))
        .setFooter({ text: `${rows.length} item type(s)` });
      return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
    },
  },
  {
    name: 'coinflip',
    description: 'Bet currency on a coin flip — double or nothing.',
    cooldown: 5,
    options: [{ name: 'bet', description: 'Amount to bet', type: INT, required: true, minValue: 1, maxValue: 10000 }],
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      if (!s.gamblingEnabled) return replyError(interaction, 'Gambling is disabled on this server.');
      const bet = interaction.options.getInteger('bet', true);
      const row = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);
      if (row.wallet < bet) {
        return replyError(interaction, `You only have ${s.currencySymbol} **${fmt(row.wallet)}** in your wallet.`);
      }
      const won = Math.random() < 0.5;
      await db.economyUser.update({
        where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
        data: { wallet: won ? { increment: bet } : { decrement: bet } },
      }).catch(() => {});
      // Wallet could have been just below bet due to clamping elsewhere; re-read to be safe.
      const fresh = await service.findRow(interaction.guildId, interaction.user.id);
      if (fresh && fresh.wallet < 0) await service.setWallet(interaction.guildId, interaction.user.id, 0);
      await service.logTx({
        guildId: interaction.guildId,
        fromId: won ? null : interaction.user.id,
        toId: won ? interaction.user.id : null,
        amount: bet,
        type: 'gamble',
        note: won ? 'won' : 'lost',
      });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { symbol: s.currencySymbol, amount: bet, currency: s.currencyName },
        won
          ? `🪙 **Heads!** You won ${s.currencySymbol} **${fmt(bet)}**!`
          : `💨 **Tails!** You lost ${s.currencySymbol} **${fmt(bet)}**. Better luck next time.`,
      );
    },
  },
  {
    name: 'rob',
    description: 'Try to rob another member — high risk, decent reward.',
    cooldown: 300,
    options: [{ name: 'user', description: 'Member to rob', type: USER, required: true }],
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      if (!s.robEnabled) return replyError(interaction, 'Robbing is disabled on this server.');
      const target = interaction.options.getUser('user', true);
      if (target.bot) return replyError(interaction, 'You cannot rob bots.');
      if (target.id === interaction.user.id) return replyError(interaction, 'You cannot rob yourself.');

      const targetRow = await service.findRow(interaction.guildId, target.id);
      if (!targetRow || targetRow.wallet < 100) {
        return replyError(interaction, 'That member is too poor to be worth robbing (needs at least 100 in their wallet).');
      }
      const robber = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);

      if (Math.random() < 0.4) {
        const low = Math.max(1, Math.ceil(targetRow.wallet * 0.1));
        const high = Math.max(low, Math.floor(targetRow.wallet * 0.3));
        const steal = service.randInt(low, high);
        await db.economyUser.update({
          where: { guildId_userId: { guildId: interaction.guildId, userId: target.id } },
          data: { wallet: { decrement: steal } },
        }).catch(() => {});
        await db.economyUser.update({
          where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
          data: { wallet: { increment: steal } },
        });
        await service.logTx({ guildId: interaction.guildId, fromId: target.id, toId: interaction.user.id, amount: steal, type: 'rob', note: 'success' });
        return respond(
          interaction,
          cmdCfg.responses.success,
          { symbol: s.currencySymbol, amount: steal, target: `<@${target.id}>`, currency: s.currencyName },
          `🕵️ You successfully robbed <@${target.id}> and got away with ${s.currencySymbol} **${fmt(steal)}**!`,
        );
      }

      const fine = Math.min(100, robber.wallet);
      if (fine > 0) {
        await db.economyUser.update({
          where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
          data: { wallet: { decrement: fine } },
        }).catch(() => {});
      }
      await service.logTx({ guildId: interaction.guildId, fromId: interaction.user.id, amount: fine, type: 'rob', note: 'fine' });
      return respond(
        interaction,
        cmdCfg.responses.success,
        { symbol: s.currencySymbol, amount: fine, target: `<@${target.id}>`, currency: s.currencyName },
        `🚔 You got caught red-handed! You paid a fine of ${s.currencySymbol} **${fmt(fine)}**.`,
      );
    },
  },
  {
    name: 'crime',
    description: 'Try your luck at a risky (but legal-ish) scheme.',
    cooldown: 600,
    async run(ctx, interaction, cmdCfg) {
      const modCfg = await getModSettings(interaction.guildId);
      const s = modCfg.settings;
      if (!s.crimeEnabled) return replyError(interaction, 'Crime is disabled on this server.');
      const row = await service.getUser(interaction.guildId, interaction.user.id, s.startBalance);

      if (Math.random() < 0.55) {
        const gain = service.randInt(200, 600);
        await db.economyUser.update({
          where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
          data: { wallet: { increment: gain } },
        });
        await service.logTx({ guildId: interaction.guildId, toId: interaction.user.id, amount: gain, type: 'crime', note: 'success' });
        const line = service.pickLine(service.CRIME_WIN_LINES, { amount: `${s.currencySymbol} ${fmt(gain)}`, symbol: s.currencySymbol });
        return respond(
          interaction,
          cmdCfg.responses.success,
          { symbol: s.currencySymbol, amount: gain, currency: s.currencyName },
          `🤑 ${line}`,
        );
      }

      const wanted = service.randInt(50, 200);
      const loss = Math.min(wanted, row.wallet);
      if (loss > 0) {
        await db.economyUser.update({
          where: { guildId_userId: { guildId: interaction.guildId, userId: interaction.user.id } },
          data: { wallet: { decrement: loss } },
        }).catch(() => {});
      }
      await service.logTx({ guildId: interaction.guildId, fromId: interaction.user.id, amount: loss, type: 'crime', note: 'failed' });
      const line = service.pickLine(service.CRIME_FAIL_LINES, { amount: `${s.currencySymbol} ${fmt(loss)}`, symbol: s.currencySymbol });
      return respond(interaction, cmdCfg.responses.success, { symbol: s.currencySymbol, amount: loss, currency: s.currencyName }, `😬 ${line}`);
    },
  },
];

module.exports = { commands, buildBalanceEmbed };
