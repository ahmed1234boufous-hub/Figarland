'use strict';

const db = require('../../core/db');

/**
 * Moderation service — case creation, lookups and statistics.
 * Case numbers are per-guild sequential (max + 1 inside a transaction).
 */

async function createCase({ guildId, type, targetUser, moderatorId, reason, durationMs = null, expiresAt = null, active = true }) {
  const agg = await db.modCase.aggregate({ _max: { caseNumber: true }, where: { guildId } });
  const caseNumber = (agg._max.caseNumber || 0) + 1;
  return db.modCase.create({
    data: {
      guildId,
      caseNumber,
      type,
      targetUserId: targetUser.id,
      targetTag: targetUser.tag || null,
      moderatorId,
      reason: reason || null,
      durationMs,
      expiresAt,
      active,
    },
  });
}

async function getCase(guildId, caseNumber) {
  return db.modCase.findUnique({ where: { guildId_caseNumber: { guildId, caseNumber } } });
}

async function listCases(guildId, { userId = null, type = null, moderatorId = null, take = 10 } = {}) {
  const where = { guildId };
  if (userId) where.targetUserId = userId;
  if (type) where.type = type;
  if (moderatorId) where.moderatorId = moderatorId;
  return db.modCase.findMany({ where, orderBy: { createdAt: 'desc' }, take });
}

async function countActiveWarnings(guildId, userId) {
  return db.modCase.count({ where: { guildId, targetUserId: userId, type: 'warn', active: true } });
}

async function deactivateWarnings(guildId, userId, limit = null) {
  const where = { guildId, targetUserId: userId, type: 'warn', active: true };
  if (limit) {
    const rows = await db.modCase.findMany({ where, orderBy: { createdAt: 'desc' }, take: limit });
    await db.modCase.updateMany({ where: { id: { in: rows.map((r) => r.id) } }, data: { active: false } });
    return rows.length;
  }
  const res = await db.modCase.updateMany({ where, data: { active: false } });
  return res.count;
}

async function stats(guildId, moderatorId = null) {
  const where = { guildId };
  if (moderatorId) where.moderatorId = moderatorId;
  const rows = await db.modCase.groupBy({ by: ['type'], _count: { _all: true }, where });
  return rows.map((r) => ({ type: r.type, count: r._count._all }));
}

async function topModerators(guildId, take = 5) {
  const rows = await db.modCase.groupBy({ by: ['moderatorId'], _count: { _all: true }, where: { guildId } });
  return rows.sort((a, b) => b._count._all - a._count._all).slice(0, take).map((r) => ({ moderatorId: r.moderatorId, count: r._count._all }));
}

async function recentCases(guildId, take = 5) {
  return db.modCase.findMany({ where: { guildId }, orderBy: { createdAt: 'desc' }, take });
}

module.exports = { createCase, getCase, listCases, countActiveWarnings, deactivateWarnings, stats, topModerators, recentCases };
