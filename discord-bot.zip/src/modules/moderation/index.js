'use strict';

const { commands } = require('./commands');
const dashboard = require('./dashboard');

module.exports = {
  key: 'moderation',
  name: 'Moderation',
  emoji: '🛡️',
  dashboardCommandName: 'moderation-dashboard',

  settingsSchema: [
    { key: 'logChannel', label: 'Mod log channel', type: 'channel', desc: 'Every moderation case is logged here.' },
    { key: 'dmOnAction', label: 'DM members on action', type: 'boolean', desc: 'DM the target when banned/kicked/warned.' },
    { key: 'requireReason', label: 'Require reasons', type: 'boolean', desc: 'Refuse warnings without a reason.' },
  ],

  defaults: {
    enabled: true,
    settings: {
      logChannel: null,
      dmOnAction: true,
      requireReason: true,
    },
    commands: {
      ban: { cooldown: 5, responses: { success: { text: '🔨 **{target}** has been banned. Case `#{case}`\nReason: {reason}', ephemeral: false } } },
      softban: { cooldown: 5, responses: { success: { text: '🔨 **{target}** has been softbanned (messages purged). Case `#{case}`', ephemeral: false } } },
      unban: { cooldown: 3, responses: { success: { text: '✅ **{target}** has been unbanned. Case `#{case}`', ephemeral: false } } },
      kick: { cooldown: 5, responses: { success: { text: '👢 **{target}** has been kicked. Case `#{case}`\nReason: {reason}', ephemeral: false } } },
      timeout: { cooldown: 3, responses: { success: { text: '🔇 **{target}** has been timed out for **{duration}**. Case `#{case}`', ephemeral: false } } },
      untimeout: { cooldown: 3, responses: { success: { text: '🔊 **{target}** timeout removed. Case `#{case}`', ephemeral: false } } },
      warn: { cooldown: 3, responses: { success: { text: '⚠️ **{target}** has been warned. Case `#{case}`', ephemeral: false } } },
      warnings: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      clearwarnings: { cooldown: 5, responses: { success: { text: '🧹 Warnings cleared for **{target}**.', ephemeral: true } } },
      purge: { cooldown: 5, responses: { success: { text: '🧹 Deleted **{amount}** message(s).', ephemeral: true } } },
      slowmode: { cooldown: 3, responses: { success: { text: '⏱️ Slowmode updated in {channel}.', ephemeral: false } } },
      lock: { cooldown: 3, responses: { success: { text: '🔒 {channel} has been locked. Case `#{case}`', ephemeral: false } } },
      unlock: { cooldown: 3, responses: { success: { text: '🔓 {channel} has been unlocked.', ephemeral: false } } },
      nick: { cooldown: 3, responses: { success: { text: '✏️ Nickname updated for **{target}**.', ephemeral: false } } },
      role: { cooldown: 3, responses: { success: { text: '✅ Role updated for **{target}**. Case `#{case}`', ephemeral: false } } },
      case: { cooldown: 2, responses: { success: { text: '', ephemeral: false } } },
      cases: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
      modstats: { cooldown: 5, responses: { success: { text: '', ephemeral: false } } },
    },
  },

  commands,

  dashboard,
};
