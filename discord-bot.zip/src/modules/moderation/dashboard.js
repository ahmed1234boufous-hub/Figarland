'use strict';

const service = require('./service');
const db = require('../../core/db');
const { trunc } = require('../../core/dashboards');

module.exports = {
  async summaryLines(guild, modCfg) {
    const [totalCases, activeWarns] = await Promise.all([
      db.modCase.count({ where: { guildId: guild.id } }),
      db.modCase.count({ where: { guildId: guild.id, type: 'warn', active: true } }),
    ]);
    return [
      ['Total cases', `${totalCases}`],
      ['Active warnings', `${activeWarns}`],
      ['Mod log channel', modCfg.settings?.logChannel ? `<#${modCfg.settings.logChannel}>` : '*(not set — Advanced)*'],
    ];
  },
  service,
  trunc,
};
