'use strict';

const { PermissionFlagsBits, ApplicationCommandOptionType, ChannelType } = require('discord.js');
const { EmbedBuilder } = require('discord.js');
const service = require('./service');
const { respond, replyError } = require('../../core/responses');
const permissions = require('../../core/permissions');
const audit = require('../../core/audit');
const config = require('../../config');

const STR = ApplicationCommandOptionType.String;
const INT = ApplicationCommandOptionType.Integer;
const USER = ApplicationCommandOptionType.User;
const CH = ApplicationCommandOptionType.Channel;
const BOOL = ApplicationCommandOptionType.Boolean;

const DURATIONS = [
  { name: '60 seconds', value: '60' },
  { name: '5 minutes', value: '300' },
  { name: '10 minutes', value: '600' },
  { name: '1 hour', value: '3600' },
  { name: '1 day', value: '86400' },
  { name: '3 days', value: '259200' },
  { name: '1 week', value: '604800' },
];

function caseEmbed(cse, guild) {
  const embed = new EmbedBuilder()
    .setTitle(`📋 Case #${cse.caseNumber} — ${cse.type}`)
    .setColor(config.embedColor)
    .addFields(
      { name: 'Target', value: `<@${cse.targetUserId}> (${cse.targetTag || 'unknown'})`, inline: true },
      { name: 'Moderator', value: `<@${cse.moderatorId}>`, inline: true },
      { name: 'Date', value: `<t:${Math.floor(cse.createdAt.getTime() / 1000)}:f>`, inline: true },
      { name: 'Reason', value: cse.reason || '*No reason provided*' },
      { name: 'Status', value: cse.active ? 'Active' : 'Inactive', inline: true },
    );
  if (cse.durationMs) embed.addFields({ name: 'Duration', value: `${Math.round(cse.durationMs / 1000)}s`, inline: true });
  if (guild) embed.setFooter({ text: guild.name });
  return embed;
}

const commands = [
  {
    name: 'ban',
    description: 'Permanently ban a member from the server.',
    requiredPerms: ['BanMembers'],
    cooldown: 5,
    options: [
      { name: 'user', description: 'Member to ban', type: USER, required: true },
      { name: 'reason', description: 'Reason for the ban', type: STR, required: false, maxLength: 500 },
      { name: 'delete_days', description: 'Also delete messages from the last N days', type: INT, required: false, minValue: 0, maxValue: 7 },
    ],
    async run(ctx, interaction, cmdCfg) {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason') || null;
      const deleteDays = interaction.options.getInteger('delete_days') || 0;
      const member = interaction.options.getMember('user');

      const h = permissions.checkTargetHierarchy(interaction, member);
      if (!h.ok) return replyError(interaction, h.reason);
      const bh = permissions.checkBotHierarchy(interaction.guild, member);
      if (!bh.ok) return replyError(interaction, bh.reason);
      if (!permissions.botHas(interaction.guild, 'BanMembers')) return replyError(interaction, 'I need the **Ban Members** permission.');

      const cse = await service.createCase({ guildId: interaction.guildId, type: 'ban', targetUser: user, moderatorId: interaction.user.id, reason });
      await interaction.guild.members.ban(user.id, { deleteMessageSeconds: deleteDays * 86400, reason: `${reason} (by ${interaction.user.tag})` }).catch((err) => {
        throw new Error(`Discord refused the ban: ${err?.message || err}`);
      });

      if (cmdCfg.settings.dmOnAction !== false && member) {
        await member.send(`You were banned from **${interaction.guild.name}**.${reason ? ` Reason: ${reason}` : ''}`).catch(() => {});
      }
      await logToChannel(ctx, interaction, cse);
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>`, reason: reason || 'No reason', case: cse.caseNumber, moderator: `<@${interaction.user.id}>` }, `🔨 **<@${user.id}>** has been banned. Case \`#${cse.caseNumber}\`.`);
    },
  },
  {
    name: 'softban',
    description: 'Ban and immediately unban a member to remove their recent messages.',
    requiredPerms: ['BanMembers'],
    cooldown: 5,
    options: [
      { name: 'user', description: 'Member to softban', type: USER, required: true },
      { name: 'reason', description: 'Reason for the softban', type: STR, required: false, maxLength: 500 },
    ],
    async run(ctx, interaction, cmdCfg) {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason') || null;
      const member = interaction.options.getMember('user');
      const h = permissions.checkTargetHierarchy(interaction, member);
      if (!h.ok) return replyError(interaction, h.reason);
      const bh = permissions.checkBotHierarchy(interaction.guild, member);
      if (!bh.ok) return replyError(interaction, bh.reason);

      const cse = await service.createCase({ guildId: interaction.guildId, type: 'softban', targetUser: user, moderatorId: interaction.user.id, reason });
      await interaction.guild.members.ban(user.id, { deleteMessageSeconds: 86400, reason: `Softban: ${reason}` }).catch((err) => {
        throw new Error(`Discord refused the ban: ${err?.message || err}`);
      });
      await interaction.guild.members.unban(user.id, 'Softban unban').catch(() => {});
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>`, case: cse.caseNumber, reason: reason || 'No reason' }, `🔨 **<@${user.id}>** has been softbanned (messages purged). Case \`#${cse.caseNumber}\`.`);
    },
  },
  {
    name: 'unban',
    description: 'Remove a server ban using a user ID.',
    requiredPerms: ['BanMembers'],
    cooldown: 3,
    options: [
      { name: 'user_id', description: 'Discord ID of the banned user', type: STR, required: true },
      { name: 'reason', description: 'Reason for the unban', type: STR, required: false, maxLength: 500 },
    ],
    async run(ctx, interaction, cmdCfg) {
      const raw = interaction.options.getString('user_id', true).trim();
      if (!/^\d{5,25}$/.test(raw)) return replyError(interaction, 'That does not look like a valid Discord user ID.');
      const reason = interaction.options.getString('reason') || null;
      await interaction.guild.members.unban(raw, reason || 'Unban').catch(() => {
        throw new Error('No active ban found for that ID.');
      });
      const cse = await service.createCase({ guildId: interaction.guildId, type: 'unban', targetUser: { id: raw, tag: null }, moderatorId: interaction.user.id, reason });
      return respond(interaction, cmdCfg.responses.success, { target: `<@${raw}>`, case: cse.caseNumber }, `✅ **<@${raw}>** has been unbanned. Case \`#${cse.caseNumber}\`.`);
    },
  },
  {
    name: 'kick',
    description: 'Remove a member from the server without banning them.',
    requiredPerms: ['KickMembers'],
    cooldown: 5,
    options: [
      { name: 'user', description: 'Member to kick', type: USER, required: true },
      { name: 'reason', description: 'Reason for the kick', type: STR, required: false, maxLength: 500 },
    ],
    async run(ctx, interaction, cmdCfg) {
      const member = interaction.options.getMember('user');
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason') || null;
      if (!member) return replyError(interaction, 'That user is not in this server.');
      const h = permissions.checkTargetHierarchy(interaction, member);
      if (!h.ok) return replyError(interaction, h.reason);
      const bh = permissions.checkBotHierarchy(interaction.guild, member);
      if (!bh.ok) return replyError(interaction, bh.reason);
      if (!permissions.botHas(interaction.guild, 'KickMembers')) return replyError(interaction, 'I need the **Kick Members** permission.');

      const cse = await service.createCase({ guildId: interaction.guildId, type: 'kick', targetUser: user, moderatorId: interaction.user.id, reason });
      if (cmdCfg.settings.dmOnAction !== false) await member.send(`You were kicked from **${interaction.guild.name}**.${reason ? ` Reason: ${reason}` : ''}`).catch(() => {});
      await member.kick(reason || 'Kicked').catch((err) => {
        throw new Error(`Discord refused the kick: ${err?.message || err}`);
      });
      await logToChannel(ctx, interaction, cse);
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>`, case: cse.caseNumber, reason: reason || 'No reason' }, `👢 **<@${user.id}>** has been kicked. Case \`#${cse.caseNumber}\`.`);
    },
  },
  {
    name: 'timeout',
    description: 'Prevent a member from interacting for a specified duration.',
    requiredPerms: ['ModerateMembers'],
    cooldown: 3,
    options: [
      { name: 'user', description: 'Member to time out', type: USER, required: true },
      { name: 'duration', description: 'How long', type: STR, required: true, choices: DURATIONS },
      { name: 'reason', description: 'Reason for the timeout', type: STR, required: false, maxLength: 500 },
    ],
    async run(ctx, interaction, cmdCfg) {
      const member = interaction.options.getMember('user');
      const user = interaction.options.getUser('user', true);
      const seconds = parseInt(interaction.options.getString('duration', true), 10);
      const reason = interaction.options.getString('reason') || null;
      if (!member) return replyError(interaction, 'That user is not in this server.');
      const h = permissions.checkTargetHierarchy(interaction, member);
      if (!h.ok) return replyError(interaction, h.reason);
      const bh = permissions.checkBotHierarchy(interaction.guild, member);
      if (!bh.ok) return replyError(interaction, bh.reason);

      const cse = await service.createCase({ guildId: interaction.guildId, type: 'timeout', targetUser: user, moderatorId: interaction.user.id, reason, durationMs: seconds * 1000 });
      await member.timeout(seconds * 1000, reason || 'Timed out').catch((err) => {
        throw new Error(`Discord refused the timeout: ${err?.message || err}`);
      });
      await logToChannel(ctx, interaction, cse);
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>`, duration: DURATIONS.find((d) => d.value === String(seconds))?.name || `${seconds}s`, case: cse.caseNumber }, `🔇 **<@${user.id}>** has been timed out for **${DURATIONS.find((d) => d.value === String(seconds))?.name || `${seconds}s`}**. Case \`#${cse.caseNumber}\`.`);
    },
  },
  {
    name: 'untimeout',
    description: 'Remove an active timeout from a member.',
    requiredPerms: ['ModerateMembers'],
    cooldown: 3,
    options: [{ name: 'user', description: 'Member to un-timeout', type: USER, required: true }],
    async run(ctx, interaction, cmdCfg) {
      const member = interaction.options.getMember('user');
      const user = interaction.options.getUser('user', true);
      if (!member) return replyError(interaction, 'That user is not in this server.');
      const cse = await service.createCase({ guildId: interaction.guildId, type: 'untimeout', targetUser: user, moderatorId: interaction.user.id, reason: 'Timeout removed' });
      await member.timeout(null).catch((err) => {
        throw new Error(`Discord refused: ${err?.message || err}`);
      });
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>`, case: cse.caseNumber }, `🔊 **<@${user.id}>** timeout removed. Case \`#${cse.caseNumber}\`.`);
    },
  },
  {
    name: 'warn',
    description: 'Issue a formal warning and create a moderation case.',
    requiredPerms: ['ModerateMembers'],
    cooldown: 3,
    options: [
      { name: 'user', description: 'Member to warn', type: USER, required: true },
      { name: 'reason', description: 'Reason for the warning', type: STR, required: true, maxLength: 500 },
    ],
    async run(ctx, interaction, cmdCfg) {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);
      if (user.bot) return replyError(interaction, 'You cannot warn bots.');
      if (cmdCfg.settings.requireReason !== false && !reason.trim()) return replyError(interaction, 'A reason is required by server policy.');

      const cse = await service.createCase({ guildId: interaction.guildId, type: 'warn', targetUser: user, moderatorId: interaction.user.id, reason });
      const active = await service.countActiveWarnings(interaction.guildId, user.id);
      if (cmdCfg.settings.dmOnAction !== false) {
        const member = interaction.guild.members.cache.get(user.id);
        await member?.send(`⚠️ You received a warning in **${interaction.guild.name}**: ${reason} (warning ${active}).`).catch(() => {});
      }
      await logToChannel(ctx, interaction, cse);
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>`, case: cse.caseNumber, reason }, `⚠️ **<@${user.id}>** has been warned (total active: **${active}**). Case \`#${cse.caseNumber}\`.`);
    },
  },
  {
    name: 'warnings',
    description: 'Display a member’s active and historical warnings.',
    requiredPerms: ['ModerateMembers'],
    cooldown: 3,
    options: [{ name: 'user', description: 'Member to inspect', type: USER, required: true }],
    async run(ctx, interaction, cmdCfg) {
      const user = interaction.options.getUser('user', true);
      const rows = await service.listCases(interaction.guildId, { userId: user.id, type: 'warn', take: 15 });
      const activeCount = await service.countActiveWarnings(interaction.guildId, user.id);
      const embed = new EmbedBuilder()
        .setTitle(`⚠️ Warnings — ${user.tag || user.username}`)
        .setColor(config.embedColor)
        .setDescription(rows.length ? rows.map((r) => `${r.active ? '🟢' : '⚪'} \`#${r.caseNumber}\` <t:${Math.floor(r.createdAt.getTime() / 1000)}:R> — ${r.reason || '*no reason*'} (<@${r.moderatorId}>)`).join('\n') : 'This member has no warnings.')
        .setFooter({ text: `Active warnings: ${activeCount}` });
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>` }, null, { embeds: [embed] });
    },
  },
  {
    name: 'clearwarnings',
    description: 'Clear some or all warnings for a member.',
    requiredPerms: ['ModerateMembers'],
    cooldown: 5,
    options: [
      { name: 'user', description: 'Member whose warnings to clear', type: USER, required: true },
      { name: 'count', description: 'How many recent warnings to clear (empty = all)', type: INT, required: false, minValue: 1, maxValue: 100 },
    ],
    async run(ctx, interaction, cmdCfg) {
      if (!interaction.memberPermissions.has(PermissionFlagsBits.ModerateMembers) && !interaction.memberPermissions.has(PermissionFlagsBits.Administrator)) {
        return replyError(interaction, 'Clearing warnings requires elevated permissions.');
      }
      const user = interaction.options.getUser('user', true);
      const count = interaction.options.getInteger('count');
      const cleared = await service.deactivateWarnings(interaction.guildId, user.id, count || null);
      await service.createCase({ guildId: interaction.guildId, type: 'clearwarnings', targetUser: user, moderatorId: interaction.user.id, reason: `Cleared ${cleared} warning(s)` });
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>` }, `🧹 Cleared **${cleared}** warning(s) for **<@${user.id}>**.`);
    },
  },
  {
    name: 'purge',
    description: 'Bulk-delete recent messages with optional filters.',
    requiredPerms: ['ManageMessages'],
    cooldown: 5,
    options: [
      { name: 'amount', description: 'Messages to delete (1-500)', type: INT, required: true, minValue: 1, maxValue: 500 },
      { name: 'user', description: 'Only messages from this user', type: USER, required: false },
      { name: 'contains', description: 'Only messages containing this text', type: STR, required: false, maxLength: 200 },
      { name: 'bots', description: 'Only bot messages?', type: BOOL, required: false },
    ],
    async run(ctx, interaction, cmdCfg) {
      await interaction.deferReply({ flags: 64 });
      const amount = interaction.options.getInteger('amount', true);
      const user = interaction.options.getUser('user');
      const contains = interaction.options.getString('contains');
      const botsOnly = interaction.options.getBoolean('bots') || false;

      let deleted = 0;
      let remaining = amount;
      const twoWeeksAgo = Date.now() - 13 * 24 * 3600 * 1000;
      while (remaining > 0) {
        const fetched = await interaction.channel.messages.fetch({ limit: Math.min(100, remaining + 20) }).catch(() => null);
        if (!fetched?.size) break;
        const candidates = [...fetched.values()].filter((m) => {
          if (m.pinned) return false;
          if (m.createdTimestamp < twoWeeksAgo) return false;
          if (user && m.author.id !== user.id) return false;
          if (botsOnly && !m.author.bot) return false;
          if (contains && !m.content.toLowerCase().includes(contains.toLowerCase())) return false;
          return true;
        });
        if (!candidates.length) break;
        // eslint-disable-next-line no-await-in-loop
        const del = await interaction.channel.bulkDelete(candidates.slice(0, remaining), true).catch(() => null);
        if (!del?.size) break;
        deleted += del.size;
        remaining -= del.size;
        if (fetched.size < 50) break;
      }
      await service.createCase({ guildId: interaction.guildId, type: 'purge', targetUser: user || { id: interaction.user.id, tag: null }, moderatorId: interaction.user.id, reason: `Purged ${deleted} messages in #${interaction.channel.name}` });
      return respond(interaction, cmdCfg.responses.success, { target: user ? `<@${user.id}>` : 'everyone' }, `🧹 Deleted **${deleted}** message(s).`, { ephemeralDefault: true });
    },
  },
  {
    name: 'slowmode',
    description: 'Set or remove a channel’s slowmode interval.',
    requiredPerms: ['ManageChannels'],
    cooldown: 3,
    options: [
      { name: 'seconds', description: 'Slowmode in seconds (0 to disable, max 21600)', type: INT, required: true, minValue: 0, maxValue: 21600 },
      { name: 'channel', description: 'Target channel (default: current)', type: CH, required: false },
    ],
    async run(ctx, interaction, cmdCfg) {
      const channel = interaction.options.getChannel('channel') || interaction.channel;
      if (channel.type !== ChannelType.GuildText) return replyError(interaction, 'Slowmode can only be set on text channels.');
      const seconds = interaction.options.getInteger('seconds', true);
      await channel.setRateLimitPerUser(seconds, `Slowmode by ${interaction.user.tag}`).catch((err) => {
        throw new Error(`Discord refused: ${err?.message || err}`);
      });
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>` }, seconds === 0 ? `⏱️ Slowmode disabled in <#${channel.id}>.` : `⏱️ Slowmode set to **${seconds}s** in <#${channel.id}>.`);
    },
  },
  {
    name: 'lock',
    description: 'Prevent ordinary members from sending messages in a channel.',
    requiredPerms: ['ManageChannels'],
    cooldown: 3,
    options: [
      { name: 'channel', description: 'Channel to lock (default: current)', type: CH, required: false },
      { name: 'reason', description: 'Reason for locking', type: STR, required: false, maxLength: 300 },
    ],
    async run(ctx, interaction, cmdCfg) {
      const channel = interaction.options.getChannel('channel') || interaction.channel;
      if (!permissions.botHas(interaction.guild, 'ManageChannels')) return replyError(interaction, 'I need the **Manage Channels** permission.');
      await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: false }, { reason: `Locked by ${interaction.user.tag}` }).catch((err) => {
        throw new Error(`Discord refused: ${err?.message || err}`);
      });
      const cse = await service.createCase({ guildId: interaction.guildId, type: 'lock', targetUser: { id: interaction.user.id, tag: null }, moderatorId: interaction.user.id, reason: interaction.options.getString('reason') || `Locked #${channel.name}` });
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>`, case: cse.caseNumber }, `🔒 <#${channel.id}> has been locked. Case \`#${cse.caseNumber}\`.`);
    },
  },
  {
    name: 'unlock',
    description: 'Restore a channel’s normal send permissions.',
    requiredPerms: ['ManageChannels'],
    cooldown: 3,
    options: [{ name: 'channel', description: 'Channel to unlock (default: current)', type: CH, required: false }],
    async run(ctx, interaction, cmdCfg) {
      const channel = interaction.options.getChannel('channel') || interaction.channel;
      await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: null }, { reason: `Unlocked by ${interaction.user.tag}` }).catch((err) => {
        throw new Error(`Discord refused: ${err?.message || err}`);
      });
      return respond(interaction, cmdCfg.responses.success, { channel: `<#${channel.id}>` }, `🔓 <#${channel.id}> has been unlocked.`);
    },
  },
  {
    name: 'nick',
    description: 'Change a member’s server nickname.',
    requiredPerms: ['ManageNicknames'],
    cooldown: 3,
    options: [
      { name: 'user', description: 'Member to rename', type: USER, required: true },
      { name: 'nickname', description: 'New nickname (empty to reset)', type: STR, required: false, maxLength: 32 },
    ],
    async run(ctx, interaction, cmdCfg) {
      const member = interaction.options.getMember('user');
      const user = interaction.options.getUser('user', true);
      const nick = interaction.options.getString('nickname');
      if (!member) return replyError(interaction, 'That user is not in this server.');
      const h = permissions.checkTargetHierarchy(interaction, member);
      if (!h.ok) return replyError(interaction, h.reason);
      await member.setNickname(nick || null, `Nickname changed by ${interaction.user.tag}`).catch((err) => {
        throw new Error(`Discord refused: ${err?.message || err}`);
      });
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>` }, nick ? `✏️ Nickname of **<@${user.id}>** set to **${nick}**.` : `✏️ Nickname of **<@${user.id}>** reset.`);
    },
  },
  {
    name: 'role',
    description: 'Add or remove a role from a member (hierarchy checked).',
    requiredPerms: ['ManageRoles'],
    cooldown: 3,
    options: [
      { name: 'user', description: 'Target member', type: USER, required: true },
      { name: 'role', description: 'Role to add or remove', type: ApplicationCommandOptionType.Role, required: true },
      { name: 'mode', description: 'Add or remove', type: STR, required: false, choices: [{ name: 'add', value: 'add' }, { name: 'remove', value: 'remove' }] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const member = interaction.options.getMember('user');
      const user = interaction.options.getUser('user', true);
      const role = interaction.options.getRole('role', true);
      const mode = interaction.options.getString('mode') || 'add';
      if (!member) return replyError(interaction, 'That user is not in this server.');
      const h = permissions.checkTargetHierarchy(interaction, member);
      if (!h.ok) return replyError(interaction, h.reason);
      if (role.position >= interaction.guild.members.me.roles.highest.position) return replyError(interaction, 'That role is above my highest role.');
      const already = member.roles.cache.has(role.id);
      if (mode === 'add' && already) return replyError(interaction, 'The member already has that role.');
      if (mode === 'remove' && !already) return replyError(interaction, 'The member does not have that role.');

      await member.roles[mode === 'add' ? 'add' : 'remove'](role.id, `By ${interaction.user.tag}`).catch((err) => {
        throw new Error(`Discord refused: ${err?.message || err}`);
      });
      const cse = await service.createCase({ guildId: interaction.guildId, type: `role-${mode}`, targetUser: user, moderatorId: interaction.user.id, reason: `${mode} role ${role.name}` });
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>`, case: cse.caseNumber }, `✅ ${mode === 'add' ? 'Added' : 'Removed'} **@${role.name}** ${mode === 'add' ? 'to' : 'from'} **<@${user.id}>**. Case \`#${cse.caseNumber}\`.`);
    },
  },
  {
    name: 'case',
    description: 'Show the details of one moderation case.',
    requiredPerms: ['ModerateMembers'],
    cooldown: 2,
    options: [{ name: 'number', description: 'Case number', type: INT, required: true, minValue: 1 }],
    async run(ctx, interaction, cmdCfg) {
      const cse = await service.getCase(interaction.guildId, interaction.options.getInteger('number', true));
      if (!cse) return replyError(interaction, `Case \`#${interaction.options.getInteger('number', true)}\` does not exist in this server.`);
      return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [caseEmbed(cse, interaction.guild)] });
    },
  },
  {
    name: 'cases',
    description: 'List a member’s moderation cases.',
    requiredPerms: ['ModerateMembers'],
    cooldown: 3,
    options: [
      { name: 'user', description: 'Member whose cases to list', type: USER, required: true },
      { name: 'type', description: 'Filter by case type', type: STR, required: false, choices: ['ban', 'kick', 'timeout', 'warn', 'softban', 'unban', 'purge', 'lock'].map((t) => ({ name: t, value: t })) },
    ],
    async run(ctx, interaction, cmdCfg) {
      const user = interaction.options.getUser('user', true);
      const type = interaction.options.getString('type');
      const rows = await service.listCases(interaction.guildId, { userId: user.id, type, take: 10 });
      const embed = new EmbedBuilder()
        .setTitle(`📋 Cases — ${user.tag || user.username}${type ? ` (${type})` : ''}`)
        .setColor(config.embedColor)
        .setDescription(rows.length ? rows.map((r) => `\`#${r.caseNumber}\` **${r.type}** <t:${Math.floor(r.createdAt.getTime() / 1000)}:R> by <@${r.moderatorId}>${r.reason ? ` — ${r.reason.slice(0, 60)}` : ''}`).join('\n') : 'No cases found.');
      return respond(interaction, cmdCfg.responses.success, { target: `<@${user.id}>` }, null, { embeds: [embed] });
    },
  },
  {
    name: 'modstats',
    description: 'Show moderation activity statistics.',
    requiredPerms: ['ModerateMembers'],
    cooldown: 5,
    options: [{ name: 'moderator', description: 'Show stats for one moderator', type: USER, required: false }],
    async run(ctx, interaction, cmdCfg) {
      const moderator = interaction.options.getUser('moderator');
      const embed = new EmbedBuilder().setTitle('📊 Moderation statistics').setColor(config.embedColor);
      if (moderator) {
        const rows = await service.stats(interaction.guildId, moderator.id);
        const total = rows.reduce((a, r) => a + r.count, 0);
        embed.setDescription(rows.length ? rows.map((r) => `**${r.type}**: ${r.count}`).join('\n') : 'No cases yet.').setFooter({ text: `Moderator: ${moderator.tag} • Total: ${total}` });
      } else {
        const top = await service.topModerators(interaction.guildId, 5);
        const totalRows = await service.stats(interaction.guildId);
        embed.setDescription(top.length ? top.map((t, i) => `**${i + 1}.** <@${t.moderatorId}> — ${t.count} case(s)`).join('\n') : 'No cases yet.');
        embed.addFields({ name: 'All cases by type', value: totalRows.map((r) => `${r.type}: ${r.count}`).join(', ') || 'None' });
      }
      return respond(interaction, cmdCfg.responses.success, {}, null, { embeds: [embed] });
    },
  },
];

async function logToChannel(ctx, interaction, cse) {
  try {
    const modCfg = await ctx.settings.getModuleConfig(interaction.guildId, 'moderation');
    const channelId = modCfg.settings?.logChannel;
    if (!channelId) return;
    const channel = interaction.guild.channels.cache.get(channelId);
    if (!channel) return;
    const { EmbedBuilder } = require('discord.js');
    await channel.send({ embeds: [caseEmbed(cse, interaction.guild)] }).catch(() => {});
  } catch {
    /* logging is best-effort */
  }
}

module.exports = { commands, caseEmbed, logToChannel };
