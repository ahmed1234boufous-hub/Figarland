'use strict';

const db = require('../../core/db');

/** tickets/dashboard.js — summary lines for the module dashboard overview. */
module.exports = {
  async summaryLines(guild, modCfg) {
    const [open, panels] = await Promise.all([
      db.ticket.count({ where: { guildId: guild.id, status: 'open' } }).catch(() => 0),
      db.ticketPanel.count({ where: { guildId: guild.id } }).catch(() => 0),
    ]);
    return [
      ['Open tickets', `${open}`],
      ['Panels', `${panels}`],
      ['Log channel', modCfg.settings?.logChannel ? `<#${modCfg.settings.logChannel}>` : '*(not set — Advanced)*'],
    ];
  },
};
