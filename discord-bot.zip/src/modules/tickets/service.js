'use strict';

const {
  AttachmentBuilder,
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const db = require('../../core/db');
const settings = require('../../core/settings');
const config = require('../../config');

/**
 * tickets/service.js — ticket data access, channel provisioning, transcripts
 * and the shared close/reopen pipeline used by commands, components and the
 * auto-close scheduler job.
 */

const PRIORITIES = ['low', 'normal', 'high', 'urgent'];

// channelId → ticket id | null. Filled lazily by the messageCreate hook.
const channelCache = new Map();

function cacheTicketChannel(channelId, ticketId) {
  if (channelCache.size > 20000) channelCache.clear();
  channelCache.set(channelId, ticketId);
}

function cachedTicketChannel(channelId) {
  return channelCache.has(channelId) ? channelCache.get(channelId) : undefined;
}

function parsePriority(value) {
  return PRIORITIES.includes(value) ? value : 'normal';
}

async function getTicketByChannel(channelId) {
  return db.ticket.findUnique({ where: { channelId } });
}

async function getTicket(guildId, channelId) {
  const ticket = await getTicketByChannel(channelId);
  if (!ticket || ticket.guildId !== guildId) return null;
  return ticket;
}

async function countOpenTickets(guildId, userId) {
  return db.ticket.count({ where: { guildId, userId, status: 'open' } });
}

async function getPanel(panelId) {
  const id = parseInt(panelId, 10);
  if (!Number.isFinite(id)) return null;
  return db.ticketPanel.findUnique({ where: { id } });
}

/** Merge panel-level staff roles with the module-wide staff roles. */
async function staffRoleIds(guild, panel) {
  const modCfg = await settings.getModuleConfig(guild.id, 'tickets');
  const ids = [];
  for (const roleId of settings.parse(panel?.staffRoleIdsJson, [])) if (!ids.includes(roleId)) ids.push(roleId);
  for (const roleId of modCfg.settings?.staffRoleIds || []) if (!ids.includes(roleId)) ids.push(roleId);
  return ids.filter((id) => guild.roles.cache.has(id));
}

/** Staff = ManageGuild permission or holder of a configured staff role. */
function isStaff(member, staffRoleIds) {
  if (!member) return false;
  if (member.permissions?.has(PermissionFlagsBits.ManageGuild)) return true;
  return staffRoleIds.some((id) => member.roles.cache.has(id));
}

function sanitizeChannelName(name) {
  const cleaned = String(name || '')
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 90);
  return cleaned || 'ticket';
}

function buildChannelName(panel, counter) {
  const number = String(counter).padStart(4, '0');
  return sanitizeChannelName((panel.namingTemplate || 'ticket-{number}').replace('{number}', number));
}

function topicFor(ticket) {
  return `Ticket #${ticket.id} | Opener: ${ticket.userId} | Status: ${ticket.status} | Priority: ${ticket.priority}`;
}

/** Atomically increment and return the panel's ticket counter. */
async function nextTicketNumber(panelId) {
  const updated = await db.ticketPanel.update({ where: { id: panelId }, data: { counter: { increment: 1 } } });
  return updated.counter;
}

async function createTicketChannel({ guild, panel, counter, openerId, staffRoles }) {
  const name = buildChannelName(panel, counter);
  const overwrites = [
    {
      id: guild.roles.everyone.id,
      deny: [PermissionFlagsBits.ViewChannel],
    },
    {
      id: openerId,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.ReadMessageHistory],
    },
    {
      id: guild.members.me.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageChannels,
      ],
    },
  ];
  for (const roleId of staffRoles) {
    if (roleId === guild.roles.everyone.id || roleId === openerId) continue;
    overwrites.push({
      id: roleId,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
  }
  return guild.channels.create({
    name,
    type: ChannelType.GuildText,
    parent: panel.categoryId || null,
    topic: `Ticket | Opener: ${openerId} | Status: open | Priority: normal`,
    permissionOverwrites: overwrites,
    reason: 'Ticket opened',
  });
}

// ───────────────────────────── Intro embed helpers ───────────────────────────

function buildIntroEmbed({ panel, ticket, answers = [] }) {
  const embed = new EmbedBuilder()
    .setTitle(`Ticket #${ticket.id} - ${panel.title}`.slice(0, 256))
    .setColor(config.embedColor)
    .setDescription('Support has been notified. Please describe your issue in as much detail as possible.')
    .addFields(
      { name: 'Opened by', value: `<@${ticket.userId}>`, inline: true },
      { name: 'Claimed', value: ticket.claimedById ? `<@${ticket.claimedById}>` : 'Unclaimed', inline: true },
      { name: 'Priority', value: ticket.priority, inline: true },
      { name: 'Status', value: ticket.status === 'open' ? 'Open' : 'Closed', inline: true },
    )
    .setTimestamp(new Date(ticket.createdAt));
  for (let i = 0; i < answers.length; i += 1) {
    embed.addFields({
      name: `Q: ${String(answers[i].question).slice(0, 240)}`.slice(0, 256),
      value: `A: ${String(answers[i].answer || '*no answer*').slice(0, 1000)}`.slice(0, 1024),
    });
  }
  return embed;
}

function introButtons(ticket) {
  const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('tk:close').setLabel('Close').setStyle(ButtonStyle.Danger));
  row.addComponents(
    ticket.claimedById
      ? new ButtonBuilder().setCustomId('tk:unclaim').setLabel('Unclaim').setStyle(ButtonStyle.Secondary)
      : new ButtonBuilder().setCustomId('tk:claim').setLabel('Claim').setStyle(ButtonStyle.Secondary),
  );
  return [row];
}

function closedButtons() {
  return [
    new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('tk:reopen').setLabel('Reopen').setStyle(ButtonStyle.Success)),
  ];
}

async function sendIntroMessage({ channel, panel, ticket, answers = [] }) {
  const embed = buildIntroEmbed({ panel, ticket, answers });
  return channel.send({ content: `<@${ticket.userId}>`, embeds: [embed], components: introButtons(ticket) }).catch(() => null);
}

async function fetchIntroMessage(channel) {
  const fetched = await channel.messages.fetch({ after: '0', limit: 1 }).catch(() => null);
  const msg = fetched && fetched.size ? fetched.first() : null;
  if (!msg || msg.author.id !== channel.client.user.id || !msg.embeds.length) return null;
  return msg;
}

/** Replace a named field on the existing intro embed without touching Q&A fields. */
function setNamedField(embed, name, value) {
  const fields = embed.data?.fields || [];
  const index = fields.findIndex((f) => f.name === name);
  if (index === -1) return;
  embed.spliceFields(index, 1, { ...fields[index], value: String(value).slice(0, 1024) });
}

/** Update the ticket intro embed (claim/status) and its buttons in place. */
async function refreshIntroEmbed(channel, ticket) {
  const msg = await fetchIntroMessage(channel);
  if (!msg) return;
  try {
    const embed = EmbedBuilder.from(msg.embeds[0]);
    setNamedField(embed, 'Claimed', ticket.claimedById ? `<@${ticket.claimedById}>` : 'Unclaimed');
    setNamedField(embed, 'Status', ticket.status === 'open' ? 'Open' : 'Closed');
    const components = ticket.status === 'open' ? introButtons(ticket) : closedButtons();
    await msg.edit({ embeds: [embed], components });
  } catch {
    /* the intro message may have been deleted — nothing to update */
  }
}

// ─────────────────────────────── Transcripts ─────────────────────────────────

async function fetchMessages(channel, max = config.maxTranscriptMessages || 1000) {
  const all = [];
  let before;
  while (all.length < max) {
    // eslint-disable-next-line no-await-in-loop
    const batch = await channel.messages.fetch({ limit: Math.min(100, max - all.length), ...(before ? { before } : {}) }).catch(() => null);
    if (!batch || !batch.size) break;
    all.push(...batch.values());
    before = batch.last().id;
    if (batch.size < 100) break;
  }
  return all.sort((a, b) => a.createdTimestamp - b.createdTimestamp);
}

function buildTranscriptText(ticket, messages, guild) {
  const opened = new Date(ticket.createdAt).toISOString();
  const lines = [
    `Ticket #${ticket.id} transcript`,
    `Server: ${guild ? guild.name : ticket.guildId}`,
    `Opened by: ${ticket.userId}`,
    `Opened at: ${opened}`,
    `Status: ${ticket.status}`,
    `Messages: ${messages.length}`,
    ''.padEnd(60, '='),
    '',
  ];
  for (const m of messages) {
    const time = new Date(m.createdTimestamp).toISOString();
    const author = m.author ? `${m.author.tag} (${m.author.id})` : 'unknown';
    let content = (m.content || '').replace(/\r/g, '');
    if (m.attachments?.size) {
      const urls = [...m.attachments.values()].map((a) => a.url).join(' ');
      content = `${content}${content ? ' ' : ''}[attachment: ${urls}]`.trim();
    }
    if (!content && m.embeds?.length) content = '[embed]';
    lines.push(`[${time}] ${author}: ${content}`);
  }
  return lines.join('\n');
}

function buildTranscriptAttachment(ticket, messages, guild) {
  const text = buildTranscriptText(ticket, messages, guild);
  return new AttachmentBuilder(Buffer.from(text, 'utf8'), { name: `transcript-ticket-${ticket.id}.txt` });
}

// ─────────────────────────── Close / reopen pipeline ──────────────────────────

async function sendToLogChannel(guild, payload) {
  const modCfg = await settings.getModuleConfig(guild.id, 'tickets');
  const channelId = modCfg.settings?.logChannel;
  if (!channelId) return false;
  const channel = guild.channels.cache.get(channelId);
  if (!channel || !channel.isTextBased()) return false;
  return channel.send(payload).then(() => true).catch(() => false);
}

/**
 * Close a ticket: transcript → log channel (or the ticket channel), DB update,
 * remove the opener's overwrites, rename the channel, refresh the intro embed.
 * Never throws; returns a short summary for the caller's reply.
 */
async function closeTicket(ctx, { guild, channel, ticket, closedById = null, auto = false }) {
  const summary = { closed: true, transcriptSent: false, messages: 0 };

  const messages = await fetchMessages(channel).catch(() => null);
  if (messages) summary.messages = messages.length;

  const now = new Date();
  await db.ticket
    .update({
      where: { id: ticket.id },
      data: { status: 'closed', closedAt: now, lastActivityAt: now, claimedById: ticket.claimedById },
    })
    .catch((err) => ctx.logger.error('[tickets] close db update failed:', err?.message || err));
  cacheTicketChannel(channel.id, ticket.id);

  if (messages && messages.length) {
    const attachment = buildTranscriptAttachment(ticket, messages, guild);
    const embed = new EmbedBuilder()
      .setTitle(`Ticket #${ticket.id} closed`)
      .setColor(config.embedColor)
      .addFields(
        { name: 'Opener', value: `<@${ticket.userId}>`, inline: true },
        { name: 'Closed by', value: auto ? 'Auto-close (inactivity)' : closedById ? `<@${closedById}>` : 'Unknown', inline: true },
        { name: 'Duration', value: formatDuration(now.getTime() - ticket.createdAt.getTime()), inline: true },
        { name: 'Messages', value: `${messages.length}`, inline: true },
      )
      .setTimestamp(now);
    const payload = { embeds: [embed], files: [attachment] };
    const sent = await sendToLogChannel(guild, payload).catch(() => false);
    if (!sent) await channel.send(payload).catch(() => {});
    summary.transcriptSent = true;
  }

  await channel.permissionOverwrites.delete(ticket.userId, 'Ticket closed').catch(() => {});

  const baseName = channel.name.startsWith('closed-') ? channel.name.slice('closed-'.length) : channel.name;
  await channel.setName(sanitizeChannelName(`closed-${baseName}`), 'Ticket closed').catch(() => {});

  await refreshIntroEmbed(channel, { ...ticket, status: 'closed' }).catch(() => {});
  return summary;
}

/** Reopen a closed ticket: restore opener overwrites and status. */
async function reopenTicket(ctx, { guild, channel, ticket, reopenedById = null }) {
  const now = new Date();
  await db.ticket.update({ where: { id: ticket.id }, data: { status: 'open', closedAt: null, lastActivityAt: now } }).catch(() => {});
  cacheTicketChannel(channel.id, ticket.id);

  await channel.permissionOverwrites
    .edit(
      ticket.userId,
      {
        ViewChannel: true,
        SendMessages: true,
        AttachFiles: true,
        ReadMessageHistory: true,
      },
      { reason: 'Ticket reopened' },
    )
    .catch(() => {});

  const baseName = channel.name.startsWith('closed-') ? channel.name.slice('closed-'.length) : channel.name;
  await channel.setName(sanitizeChannelName(baseName), 'Ticket reopened').catch(() => {});

  await refreshIntroEmbed(channel, { ...ticket, status: 'open' }).catch(() => {});
  return true;
}

function formatDuration(ms) {
  if (!Number.isFinite(ms) || ms < 0) return 'Unknown';
  const minutes = Math.floor(ms / 60000);
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 48) return `${hours}h ${minutes % 60}m`;
  const days = Math.floor(hours / 24);
  return `${days}d ${hours % 24}h`;
}

// ─────────────────────────────── Auto-close job ──────────────────────────────

async function runAutoClose(ctx) {
  const groups = await db.ticket.groupBy({ by: ['guildId'], where: { status: 'open' } }).catch(() => []);
  for (const group of groups) {
    try {
      // eslint-disable-next-line no-await-in-loop
      const modCfg = await settings.getModuleConfig(group.guildId, 'tickets');
      if (!modCfg.enabled) continue;
      const hours = Number(modCfg.settings?.autoCloseHours) > 0 ? Number(modCfg.settings.autoCloseHours) : 48;
      const cutoff = new Date(Date.now() - hours * 3600 * 1000);
      // eslint-disable-next-line no-await-in-loop
      const stale = await db.ticket.findMany({
        where: { guildId: group.guildId, status: 'open', lastActivityAt: { lt: cutoff } },
        take: 25,
      });
      for (const ticket of stale) {
        try {
          // eslint-disable-next-line no-await-in-loop
          const guild = ctx.client.guilds.cache.get(ticket.guildId);
          if (!guild) continue;
          // eslint-disable-next-line no-await-in-loop
          const channel = await guild.channels.fetch(ticket.channelId).catch(() => null);
          if (!channel || !channel.isTextBased()) {
            // Channel is gone: close the record so it stops showing as open.
            // eslint-disable-next-line no-await-in-loop
            await db.ticket.update({ where: { id: ticket.id }, data: { status: 'closed', closedAt: new Date() } }).catch(() => {});
            continue;
          }
          // eslint-disable-next-line no-await-in-loop
          await channel
            .send({ content: `⏰ This ticket is being closed automatically after **${hours}h** of inactivity.` })
            .catch(() => {});
          // eslint-disable-next-line no-await-in-loop
          await closeTicket(ctx, { guild, channel, ticket, auto: true });
        } catch (err) {
          ctx.logger.warn('[tickets-autoclose]', err?.message || err);
        }
      }
    } catch (err) {
      ctx.logger.warn('[tickets-autoclose]', err?.message || err);
    }
  }
}

module.exports = {
  PRIORITIES,
  cacheTicketChannel,
  cachedTicketChannel,
  parsePriority,
  getTicket,
  getTicketByChannel,
  getPanel,
  countOpenTickets,
  staffRoleIds,
  isStaff,
  sanitizeChannelName,
  buildChannelName,
  topicFor,
  nextTicketNumber,
  createTicketChannel,
  buildIntroEmbed,
  introButtons,
  closedButtons,
  sendIntroMessage,
  refreshIntroEmbed,
  fetchMessages,
  buildTranscriptAttachment,
  buildTranscriptText,
  sendToLogChannel,
  closeTicket,
  reopenTicket,
  formatDuration,
  runAutoClose,
};
