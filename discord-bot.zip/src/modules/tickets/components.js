'use strict';

const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const db = require('../../core/db');
const settings = require('../../core/settings');
const { replyError, replySimple } = require('../../core/responses');
const service = require('./service');

/**
 * tickets/components.js — button handlers (tk:*) and the intake modal (tkm:*).
 * Every handler resolves its own permission/context checks and never throws
 * to the user.
 */

async function ensureModuleEnabled(interaction) {
  const modCfg = await settings.getModuleConfig(interaction.guildId, 'tickets');
  return modCfg.enabled ? modCfg : null;
}

/** Shared ticket-creation tail used by the panel button and the intake modal. */
async function createTicketAndReply(ctx, interaction, panel, questions, answers) {
  const modCfg = await ensureModuleEnabled(interaction);
  if (!modCfg) return replyError(interaction, 'The ticket system is currently disabled.');

  const guild = interaction.guild;
  if (!guild) return replyError(interaction, 'Tickets can only be used inside a server.');

  const openCount = await service.countOpenTickets(guild.id, interaction.user.id).catch(() => 0);
  if (openCount >= panel.maxOpenPerUser) {
    return replyError(interaction, `You already have **${openCount}** open ticket(s) — the limit is **${panel.maxOpenPerUser}**. Please close one before opening another.`);
  }

  const staffRoles = await service.staffRoleIds(guild, panel);
  let number;
  try {
    number = await service.nextTicketNumber(panel.id);
  } catch {
    return replyError(interaction, 'Could not allocate a ticket number — please try again.');
  }

  let channel;
  try {
    channel = await service.createTicketChannel({ guild, panel, counter: number, openerId: interaction.user.id, staffRoles });
  } catch {
    return replyError(interaction, 'I could not create the ticket channel. Please ask an administrator to check my permissions.');
  }

  const ticket = await db.ticket
    .create({
      data: {
        guildId: guild.id,
        panelId: panel.id,
        channelId: channel.id,
        userId: interaction.user.id,
        status: 'open',
        priority: 'normal',
        lastActivityAt: new Date(),
      },
    })
    .catch(async () => {
      await channel.delete('Ticket row failed').catch(() => {});
      return null;
    });
  if (!ticket) return replyError(interaction, 'The ticket could not be saved. Please try again.');

  service.cacheTicketChannel(channel.id, ticket.id);
  await service.sendIntroMessage({ channel, panel, ticket, answers });
  return replySimple(interaction, `✅ Your ticket is ready: <#${channel.id}>`, { ephemeral: true });
}

/** tk:open:<panelId> — panel button. Shows the intake modal or opens directly. */
async function handleOpen(ctx, interaction, panelId) {
  const modCfg = await ensureModuleEnabled(interaction);
  if (!modCfg) return replyError(interaction, 'The ticket system is currently disabled.');

  const panel = await service.getPanel(panelId);
  if (!panel || panel.guildId !== interaction.guildId) {
    return replyError(interaction, 'This ticket panel no longer exists. Please ask staff to repost it.');
  }

  const questions = settings.parse(panel.questionsJson, []);
  if (Array.isArray(questions) && questions.length) {
    const modal = new ModalBuilder().setCustomId(`tkm:intake:${panel.id}`).setTitle(String(panel.title).slice(0, 45));
    for (let i = 0; i < Math.min(5, questions.length); i += 1) {
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId(`q${i}`)
            .setLabel(String(questions[i]).slice(0, 45))
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
            .setMaxLength(1000),
        ),
      );
    }
    return interaction.showModal(modal);
  }

  await interaction.deferReply({ flags: 64 });
  return createTicketAndReply(ctx, interaction, panel, [], []);
}

/** tkm:intake:<panelId> — modal submit: collect answers, then open. */
async function handleIntakeModal(ctx, interaction, rest) {
  const panelId = rest.split(':')[1];
  const modCfg = await ensureModuleEnabled(interaction);
  if (!modCfg) return replyError(interaction, 'The ticket system is currently disabled.');

  const panel = await service.getPanel(panelId);
  if (!panel || panel.guildId !== interaction.guildId) {
    return replyError(interaction, 'This ticket panel no longer exists.');
  }

  await interaction.deferReply({ flags: 64 });

  const questions = settings.parse(panel.questionsJson, []).slice(0, 5);
  const answers = [];
  for (let i = 0; i < questions.length; i += 1) {
    let answer = '';
    try {
      answer = interaction.fields.getTextInputValue(`q${i}`) || '';
    } catch {
      answer = '';
    }
    answers.push({ question: questions[i], answer });
  }
  return createTicketAndReply(ctx, interaction, panel, questions, answers);
}

async function getTicketContext(interaction) {
  const ticket = await service.getTicket(interaction.guildId, interaction.channelId);
  if (!ticket) {
    await replyError(interaction, 'There is no ticket in this channel.');
    return null;
  }
  const panel = await service.getPanel(ticket.panelId);
  const guild = interaction.guild;
  const staffRoles = await service.staffRoleIds(guild, panel);
  return { ticket, panel, guild, staffRoles };
}

/** tk:close — ask for confirmation (used by button and /ticket close). */
async function handleCloseRequest(ctx, interaction) {
  const context = await getTicketContext(interaction);
  if (!context) return;
  const { ticket } = context;
  if (ticket.status !== 'open') return replyError(interaction, 'This ticket is already closed.');

  const staff = service.isStaff(interaction.member, context.staffRoles);
  if (!staff && ticket.userId !== interaction.user.id) {
    return replyError(interaction, 'Only the ticket opener or staff can close this ticket.');
  }

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tk:closeconfirm').setLabel('Close ticket').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('tk:closecancel').setLabel('Cancel').setStyle(ButtonStyle.Secondary),
  );
  return replySimple(interaction, 'Are you sure you want to close this ticket? A transcript will be saved.', { components: [row], ephemeral: true });
}

/** tk:closeconfirm — run the close pipeline. */
async function handleCloseConfirm(ctx, interaction) {
  const context = await getTicketContext(interaction);
  if (!context) return;
  const { ticket, guild, channel } = context;
  if (ticket.status !== 'open') return replySimple(interaction, 'This ticket is already closed.', { ephemeral: true });

  await interaction.deferReply({ flags: 64 });
  await service.closeTicket(ctx, { guild, channel, ticket, closedById: interaction.user.id });
  return replySimple(interaction, `🔒 Ticket closed by <@${interaction.user.id}>. The transcript has been saved.`, { ephemeral: true });
}

async function handleCloseCancel(ctx, interaction) {
  return replySimple(interaction, 'Close cancelled — the ticket stays open.', { ephemeral: true });
}

/** tk:claim — staff claims the ticket. */
async function handleClaim(ctx, interaction) {
  const context = await getTicketContext(interaction);
  if (!context) return;
  const { ticket, panel, guild, staffRoles } = context;
  if (!service.isStaff(interaction.member, staffRoles)) return replyError(interaction, 'Only support staff can claim tickets.');
  if (ticket.status !== 'open') return replyError(interaction, 'Closed tickets cannot be claimed.');
  if (ticket.claimedById) return replyError(interaction, `This ticket is already claimed by <@${ticket.claimedById}>.`);

  const updated = await db.ticket.update({ where: { id: ticket.id }, data: { claimedById: interaction.user.id } });
  if (panel) await service.refreshIntroEmbed(interaction.channel, updated);
  return replySimple(interaction, `✋ <@${interaction.user.id}> claimed this ticket and will handle it.`, { ephemeral: true });
}

/** tk:unclaim — staff releases the ticket. */
async function handleUnclaim(ctx, interaction) {
  const context = await getTicketContext(interaction);
  if (!context) return;
  const { ticket, panel, staffRoles } = context;
  if (!service.isStaff(interaction.member, staffRoles)) return replyError(interaction, 'Only support staff can unclaim tickets.');
  if (!ticket.claimedById) return replyError(interaction, 'This ticket is not claimed.');

  const updated = await db.ticket.update({ where: { id: ticket.id }, data: { claimedById: null } });
  if (panel) await service.refreshIntroEmbed(interaction.channel, updated);
  return replySimple(interaction, `👋 <@${interaction.user.id}> released this ticket back to the queue.`, { ephemeral: true });
}

/** tk:reopen — restore a closed ticket (button or /ticket reopen). */
async function handleReopen(ctx, interaction) {
  const context = await getTicketContext(interaction);
  if (!context) return;
  const { ticket, guild, channel, staffRoles } = context;
  if (ticket.status !== 'closed') return replyError(interaction, 'This ticket is not closed.');

  const staff = service.isStaff(interaction.member, staffRoles);
  if (!staff && ticket.userId !== interaction.user.id) {
    return replyError(interaction, 'Only the ticket opener or staff can reopen this ticket.');
  }

  await interaction.deferReply({ flags: 64 });
  await service.reopenTicket(ctx, { guild, channel, ticket, reopenedById: interaction.user.id });
  return replySimple(interaction, `🔓 Ticket reopened by <@${interaction.user.id}>.`, { ephemeral: true });
}

/** Route tk:* component interactions. rest = customId without the 'tk:' prefix. */
async function handleComponent(ctx, interaction, rest) {
  const [action, ...payloadParts] = rest.split(':');
  switch (action) {
    case 'open':
      return handleOpen(ctx, interaction, payloadParts[0]);
    case 'close':
      return handleCloseRequest(ctx, interaction);
    case 'closeconfirm':
      return handleCloseConfirm(ctx, interaction);
    case 'closecancel':
      return handleCloseCancel(ctx, interaction);
    case 'claim':
      return handleClaim(ctx, interaction);
    case 'unclaim':
      return handleUnclaim(ctx, interaction);
    case 'reopen':
      return handleReopen(ctx, interaction);
    default:
      return replyError(interaction, 'Unknown ticket action.');
  }
}

/** Route tkm:* modal submits. rest = customId without the 'tkm:' prefix. */
async function handleModal(ctx, interaction, rest) {
  const [action] = rest.split(':');
  if (action === 'intake') return handleIntakeModal(ctx, interaction, rest);
  return replyError(interaction, 'Unknown ticket form.');
}

module.exports = { handleComponent, handleModal, createTicketAndReply };
