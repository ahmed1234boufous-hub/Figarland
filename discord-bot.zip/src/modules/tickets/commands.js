'use strict';

const {
  ActionRowBuilder,
  ApplicationCommandOptionType,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits,
} = require('discord.js');
const db = require('../../core/db');
const settings = require('../../core/settings');
const audit = require('../../core/audit');
const config = require('../../config');
const { respond, replyError, replySimple } = require('../../core/responses');
const service = require('./service');
const components = require('./components');

const SUB = ApplicationCommandOptionType.Subcommand;
const STR = ApplicationCommandOptionType.String;
const INT = ApplicationCommandOptionType.Integer;
const USER = ApplicationCommandOptionType.User;
const ROLE = ApplicationCommandOptionType.Role;
const CH = ApplicationCommandOptionType.Channel;

async function requireGuildConfigured(interaction) {
  const modCfg = await settings.getModuleConfig(interaction.guildId, 'tickets');
  return modCfg;
}

async function staffGuard(ctx, interaction, cmdCfg) {
  const modCfg = await requireGuildConfigured(interaction);
  const panel = await db.ticketPanel.findFirst({ where: { guildId: interaction.guildId } }).catch(() => null);
  const staffRoles = await service.staffRoleIds(interaction.guild, panel);
  if (!service.isStaff(interaction.member, staffRoles)) {
    await replyError(interaction, 'Only support staff (staff roles or Manage Server) can use this subcommand.');
    return null;
  }
  return { modCfg, panel, staffRoles };
}

const commands = [
  {
    name: 'ticket',
    description: 'Open, manage and configure support tickets.',
    cooldown: 3,
    options: [
      { name: 'setup', description: 'Explain the ticket system and show the current configuration', type: SUB, options: [] },
      {
        name: 'panel',
        description: 'Create a ticket panel with an Open-a-ticket button in this channel',
        type: SUB,
        options: [
          { name: 'title', description: 'Panel title (e.g. Support)', type: STR, required: true, maxLength: 100 },
          { name: 'category', description: 'Category under which ticket channels are created', type: CH, required: true, channel_types: [ChannelType.GuildCategory] },
          { name: 'questions', description: 'Up to 5 intake questions separated by |', type: STR, required: false, maxLength: 1000 },
          { name: 'staff_role', description: 'Extra staff role for this panel', type: ROLE, required: false },
        ],
      },
      { name: 'close', description: 'Close the ticket in the current channel (with confirmation)', type: SUB, options: [] },
      { name: 'reopen', description: 'Reopen a closed ticket in the current channel', type: SUB, options: [] },
      { name: 'claim', description: 'Claim the ticket in the current channel as staff', type: SUB, options: [] },
      { name: 'unclaim', description: 'Release the ticket in the current channel', type: SUB, options: [] },
      { name: 'add', description: 'Grant a user access to this ticket', type: SUB, options: [{ name: 'user', description: 'User to add', type: USER, required: true }] },
      { name: 'remove', description: 'Revoke a user access to this ticket', type: SUB, options: [{ name: 'user', description: 'User to remove', type: USER, required: true }] },
      { name: 'rename', description: 'Rename this ticket channel', type: SUB, options: [{ name: 'name', description: 'New channel name', type: STR, required: true, maxLength: 90 }] },
      { name: 'transcript', description: 'Generate and attach a transcript of this ticket', type: SUB, options: [] },
      { name: 'transfer', description: 'Transfer the claim on this ticket to another staff member', type: SUB, options: [{ name: 'user', description: 'Staff member to transfer to', type: USER, required: true }] },
      {
        name: 'priority',
        description: 'Set the priority of this ticket',
        type: SUB,
        options: [
          {
            name: 'level',
            description: 'Priority level',
            type: STR,
            required: true,
            choices: service.PRIORITIES.map((p) => ({ name: p, value: p })),
          },
        ],
      },
      { name: 'stats', description: 'Ticket statistics for this server', type: SUB, options: [] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand(false);

      if (sub === 'setup') return runSetup(ctx, interaction, cmdCfg);
      if (sub === 'panel') return runPanel(ctx, interaction, cmdCfg);
      if (sub === 'close') return components.handleCloseRequest(ctx, interaction);
      if (sub === 'reopen') return components.handleReopen(ctx, interaction);
      if (sub === 'claim') return components.handleClaim(ctx, interaction);
      if (sub === 'unclaim') return components.handleUnclaim(ctx, interaction);
      if (sub === 'add') return runAdd(ctx, interaction, cmdCfg);
      if (sub === 'remove') return runRemove(ctx, interaction, cmdCfg);
      if (sub === 'rename') return runRename(ctx, interaction, cmdCfg);
      if (sub === 'transcript') return runTranscript(ctx, interaction, cmdCfg);
      if (sub === 'transfer') return runTransfer(ctx, interaction, cmdCfg);
      if (sub === 'priority') return runPriority(ctx, interaction, cmdCfg);
      if (sub === 'stats') return runStats(ctx, interaction, cmdCfg);
      return replyError(interaction, 'Unknown subcommand.');
    },
  },
];

/** /ticket setup — flow explanation + current configuration. */
async function runSetup(ctx, interaction, cmdCfg) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    return replyError(interaction, 'You need the **Manage Server** permission to view ticket setup.');
  }
  const modCfg = await requireGuildConfigured(interaction);
  const panels = await db.ticketPanel.count({ where: { guildId: interaction.guildId } }).catch(() => 0);
  const open = await db.ticket.count({ where: { guildId: interaction.guildId, status: 'open' } }).catch(() => 0);

  const embed = new EmbedBuilder()
    .setTitle('🎫 Ticket system setup')
    .setColor(config.embedColor)
    .setDescription(
      [
        '**How it works**',
        '1. Run `/ticket panel` in the channel that should host the button.',
        '2. Members click **Open a ticket** — a private channel is created for them.',
        '3. Staff use **Claim / Close / Reopen** buttons or `/ticket claim`, `/ticket close`.',
        '4. Closed tickets produce a transcript that is posted to the log channel.',
        '5. Idle tickets are closed automatically after the configured hours of inactivity.',
        '',
        '**Global settings** (edit via `/ticket-dashboard > Advanced`):',
        `- Log channel: ${modCfg.settings.logChannel ? `<#${modCfg.settings.logChannel}>` : '*(not set)*'}`,
        `- Auto-close after: **${modCfg.settings.autoCloseHours}h** of inactivity`,
        `- Staff roles: ${(modCfg.settings.staffRoleIds || []).length ? modCfg.settings.staffRoleIds.map((r) => `<@&${r}>`).join(' ') : '*(none)*'}`,
        '',
        `**Current state:** ${panels} panel(s) • ${open} open ticket(s)`,
      ].join('\n'),
    );
  return respond(interaction, cmdCfg.responses.success, { channel: `<#${interaction.channelId}>` }, null, { embeds: [embed], ephemeralDefault: true });
}

/** /ticket panel — create a TicketPanel row and post the panel message. */
async function runPanel(ctx, interaction, cmdCfg) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    return replyError(interaction, 'You need the **Manage Server** permission to create ticket panels.');
  }
  const title = interaction.options.getString('title', true);
  const category = interaction.options.getChannel('category', true);
  const rawQuestions = interaction.options.getString('questions');
  const staffRole = interaction.options.getRole('staff_role');

  if (category.type !== ChannelType.GuildCategory) {
    return replyError(interaction, 'The category must be a **category channel**.');
  }
  if (!ctx.permissions.botHas(interaction.guild, 'ManageChannels', 'ViewChannel', 'SendMessages')) {
    return replyError(interaction, 'I need the **Manage Channels**, **View Channel** and **Send Messages** permissions.');
  }

  let questions = [];
  if (rawQuestions) {
    questions = rawQuestions
      .split('|')
      .map((q) => q.trim())
      .filter(Boolean)
      .slice(0, 5);
    if (!questions.length) return replyError(interaction, 'Add at least one question separated by `|`, or leave the option empty.');
  }

  await interaction.deferReply({ flags: 64 });

  const panel = await db.ticketPanel
    .create({
      data: {
        guildId: interaction.guildId,
        channelId: interaction.channelId,
        title,
        categoryId: category.id,
        questionsJson: settings.stringify(questions),
        staffRoleIdsJson: settings.stringify(staffRole ? [staffRole.id] : []),
      },
    })
    .catch(() => null);
  if (!panel) return replyError(interaction, 'Could not save the panel — please try again.');

  const embed = new EmbedBuilder()
    .setTitle(title.slice(0, 256))
    .setColor(config.embedColor)
    .setDescription(
      [
        'Need help? Click the button below to open a private ticket with our support team.',
        questions.length ? `You will be asked **${questions.length}** quick question(s) first.` : '',
        `Ticket channels are created under **${category.name}**.`,
      ]
        .filter(Boolean)
        .join('\n'),
    )
    .setFooter({ text: 'Tickets • one click, private channel' });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`tk:open:${panel.id}`).setLabel('Open a ticket').setStyle(ButtonStyle.Primary),
  );

  const message = await interaction.channel.send({ embeds: [embed], components: [row] }).catch(() => null);
  if (!message) {
    await db.ticketPanel.delete({ where: { id: panel.id } }).catch(() => {});
    return replyError(interaction, 'I could not post the panel message in this channel — the panel was not created. Check my permissions and try again.');
  }
  await db.ticketPanel.update({ where: { id: panel.id }, data: { messageId: message.id } }).catch(() => {});

  await audit.log(interaction.guildId, interaction.user.id, 'config.panel.create', 'module:tickets', null, { ...panel, questionsCount: questions.length });

  return respond(
    interaction,
    cmdCfg.responses.success,
    { channel: `<#${interaction.channelId}>` },
    `✅ Panel created and posted in this channel (ID \`${panel.id}\`). Members can now open tickets.`,
    { ephemeralDefault: true },
  );
}

async function ticketChannelGuard(interaction) {
  const ticket = await service.getTicket(interaction.guildId, interaction.channelId);
  if (!ticket) {
    await replyError(interaction, 'This subcommand must be used inside a ticket channel.');
    return null;
  }
  return ticket;
}

/** /ticket add — grant a user access to the ticket channel. */
async function runAdd(ctx, interaction, cmdCfg) {
  const guard = await staffGuard(ctx, interaction, cmdCfg);
  if (!guard) return;
  const ticket = await ticketChannelGuard(interaction);
  if (!ticket) return;

  const user = interaction.options.getUser('user', true);
  await interaction.channel.permissionOverwrites
    .edit(user.id, { ViewChannel: true, SendMessages: true, AttachFiles: true, ReadMessageHistory: true }, { reason: `Added to ticket by ${interaction.user.tag}` })
    .catch(() => null);
  return respond(interaction, cmdCfg.responses.success, { user: `<@${user.id}>` }, `➕ <@${user.id}> can now view and write in this ticket.`, { ephemeralDefault: true });
}

/** /ticket remove — revoke a user's access to the ticket channel. */
async function runRemove(ctx, interaction, cmdCfg) {
  const guard = await staffGuard(ctx, interaction, cmdCfg);
  if (!guard) return;
  const ticket = await ticketChannelGuard(interaction);
  if (!ticket) return;

  const user = interaction.options.getUser('user', true);
  if (user.id === ticket.userId) return replyError(interaction, 'The ticket opener cannot be removed from their own ticket.');

  await interaction.channel.permissionOverwrites.delete(user.id, `Removed from ticket by ${interaction.user.tag}`).catch(() => {});
  return respond(interaction, cmdCfg.responses.success, { user: `<@${user.id}>` }, `➖ <@${user.id}> no longer has access to this ticket.`, { ephemeralDefault: true });
}

/** /ticket rename — rename the ticket channel. */
async function runRename(ctx, interaction, cmdCfg) {
  const guard = await staffGuard(ctx, interaction, cmdCfg);
  if (!guard) return;
  const ticket = await ticketChannelGuard(interaction);
  if (!ticket) return;

  const raw = interaction.options.getString('name', true);
  const name = service.sanitizeChannelName(raw);
  if (!name) return replyError(interaction, 'That name contains no usable characters.');
  await interaction.channel.setName(name, `Renamed by ${interaction.user.tag}`).catch(() => null);
  return respond(interaction, cmdCfg.responses.success, { channelname: name }, `✏️ Ticket channel renamed to **#${name}**.`, { ephemeralDefault: true });
}

/** /ticket transcript — regenerate and attach the transcript. */
async function runTranscript(ctx, interaction, cmdCfg) {
  await interaction.deferReply({ flags: 64 });
  const ticket = await service.getTicket(interaction.guildId, interaction.channelId);
  if (!ticket) return replyError(interaction, 'This subcommand must be used inside a ticket channel.');

  const messages = await service.fetchMessages(interaction.channel).catch(() => null);
  if (!messages) return replyError(interaction, 'Could not fetch this channel history.');
  const attachment = service.buildTranscriptAttachment(ticket, messages, interaction.guild);
  return respond(
    interaction,
    cmdCfg.responses.success,
    { amount: messages.length },
    `📄 Transcript with **${messages.length}** message(s) attached.`,
    { files: [attachment], ephemeralDefault: true },
  );
}

/** /ticket transfer — hand the claim to another staff member. */
async function runTransfer(ctx, interaction, cmdCfg) {
  const guard = await staffGuard(ctx, interaction, cmdCfg);
  if (!guard) return;
  const ticket = await ticketChannelGuard(interaction);
  if (!ticket) return;

  const member = interaction.options.getMember('user');
  const user = interaction.options.getUser('user', true);
  if (!member) return replyError(interaction, 'That user is not in this server.');
  if (!service.isStaff(member, guard.staffRoles)) return replyError(interaction, `<@${user.id}> does not have a staff role.`);

  const updated = await db.ticket.update({ where: { id: ticket.id }, data: { claimedById: user.id } });
  const panel = await service.getPanel(ticket.panelId);
  if (panel) await service.refreshIntroEmbed(interaction.channel, updated);
  return respond(interaction, cmdCfg.responses.success, { user: `<@${user.id}>` }, `🔁 Ticket claim transferred to <@${user.id}>.`, { ephemeralDefault: true });
}

/** /ticket priority — set priority and mirror it into the channel topic. */
async function runPriority(ctx, interaction, cmdCfg) {
  const guard = await staffGuard(ctx, interaction, cmdCfg);
  if (!guard) return;
  const ticket = await ticketChannelGuard(interaction);
  if (!ticket) return;

  const level = service.parsePriority(interaction.options.getString('level', true));
  const updated = await db.ticket.update({ where: { id: ticket.id }, data: { priority: level } });

  await interaction.channel.setTopic(service.topicFor(updated), `Priority set by ${interaction.user.tag}`).catch(() => {});
  const panel = await service.getPanel(ticket.panelId);
  if (panel) await service.refreshIntroEmbed(interaction.channel, updated);

  const emoji = { low: '🟢', normal: '🔵', high: '🟠', urgent: '🔴' }[level] || '';
  return respond(interaction, cmdCfg.responses.success, { level }, `${emoji} Ticket priority set to **${level}**.`, { ephemeralDefault: true });
}

/** /ticket stats — open/closed counts, average resolution, top claimers. */
async function runStats(ctx, interaction, cmdCfg) {
  const modCfg = await requireGuildConfigured(interaction);
  const panel = await db.ticketPanel.findFirst({ where: { guildId: interaction.guildId } }).catch(() => null);
  const staffRoles = await service.staffRoleIds(interaction.guild, panel);
  if (!service.isStaff(interaction.member, staffRoles)) {
    return replyError(interaction, 'Only support staff can view ticket statistics.');
  }

  await interaction.deferReply({ flags: 64 });
  const [statusGroups, closedTickets, claimGroups] = await Promise.all([
    db.ticket.groupBy({ by: ['status'], _count: { _all: true }, where: { guildId: interaction.guildId } }).catch(() => []),
    db.ticket
      .findMany({ where: { guildId: interaction.guildId, status: 'closed', closedAt: { not: null } }, select: { createdAt: true, closedAt: true } })
      .catch(() => []),
    db.ticket
      .groupBy({ by: ['claimedById'], _count: { _all: true }, where: { guildId: interaction.guildId, claimedById: { not: null } } })
      .catch(() => []),
  ]);

  const open = statusGroups.find((g) => g.status === 'open')?._count._all || 0;
  const closed = statusGroups.find((g) => g.status === 'closed')?._count._all || 0;
  const avgMs = closedTickets.length
    ? closedTickets.reduce((acc, t) => acc + (t.closedAt.getTime() - t.createdAt.getTime()), 0) / closedTickets.length
    : null;
  const top = claimGroups
    .filter((g) => g.claimedById)
    .sort((a, b) => b._count._all - a._count._all)
    .slice(0, 5);

  const embed = new EmbedBuilder()
    .setTitle('📊 Ticket statistics')
    .setColor(config.embedColor)
    .addFields(
      { name: 'Open', value: `${open}`, inline: true },
      { name: 'Closed', value: `${closed}`, inline: true },
      { name: 'Avg. resolution', value: avgMs === null ? 'No closed tickets yet' : service.formatDuration(avgMs), inline: true },
      {
        name: 'Claims per staff (top 5)',
        value: top.length ? top.map((t, i) => `**${i + 1}.** <@${t.claimedById}> — ${t._count._all} ticket(s)`).join('\n') : 'No claims recorded yet.',
      },
    );
  return respond(interaction, cmdCfg.responses.success, { open, closed }, null, { embeds: [embed], ephemeralDefault: true });
}

module.exports = { commands };
