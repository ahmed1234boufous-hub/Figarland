'use strict';

const db = require('../../core/db');
const { commands } = require('./commands');
const components = require('./components');
const dashboard = require('./dashboard');
const service = require('./service');

/**
 * tickets — support tickets with panels, private channels, claims,
 * transcripts and inactivity auto-close.
 *
 * Component prefix: 'tk:' (tk:open / close / closeconfirm / closecancel /
 * claim / unclaim / reopen). Modal prefix: 'tkm:' (tkm:intake:<panelId>).
 */

module.exports = {
  key: 'tickets',
  name: 'Tickets & Support',
  emoji: '🎫',
  dashboardCommandName: 'ticket-dashboard',

  settingsSchema: [
    { key: 'logChannel', label: 'Transcript log channel', type: 'channel', desc: 'Closed tickets post their transcript embed + file here.' },
    { key: 'autoCloseHours', label: 'Auto-close hours', type: 'number', desc: 'Close open tickets after this many hours without activity (0 = never).' },
    { key: 'staffRoleIds', label: 'Support staff roles', type: 'roles', desc: 'Members with these roles can claim, close and manage all tickets.' },
  ],

  defaults: {
    enabled: true,
    settings: {
      logChannel: null,
      autoCloseHours: 48,
      staffRoleIds: [],
    },
    commands: {
      ticket: { cooldown: 3, responses: { success: { text: '', ephemeral: false } } },
    },
  },

  commands,

  dashboard,

  componentHandlers: { 'tk:': components.handleComponent },
  modalHandlers: { 'tkm:': components.handleModal },

  hooks: {
    /** Keep Ticket.lastActivityAt fresh for the auto-close job. */
    async messageCreate(ctx, message) {
      try {
        if (!message.guild || !message.channelId) return;
        if (message.author?.bot) return;
        let ticketId = service.cachedTicketChannel(message.channelId);
        if (ticketId === undefined) {
          const ticket = await db.ticket.findUnique({ where: { channelId: message.channelId } }).catch(() => null);
          ticketId = ticket ? ticket.id : null;
          service.cacheTicketChannel(message.channelId, ticketId);
        }
        if (!ticketId) return;
        await db.ticket.updateMany({ where: { id: ticketId, status: 'open' }, data: { lastActivityAt: new Date() } }).catch(() => {});
      } catch {
        /* activity tracking is best-effort */
      }
    },
  },

  schedulerJobs: [
    {
      name: 'tickets-autoclose',
      intervalMs: 3600000,
      run: (ctx) => service.runAutoClose(ctx),
    },
  ],
};
