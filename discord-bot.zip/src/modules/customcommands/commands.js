'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ApplicationCommandOptionType,
  PermissionFlagsBits,
} = require('discord.js');
const { respond, replyError } = require('../../core/responses');
const settings = require('../../core/settings');
const db = require('../../core/db');
const config = require('../../config');
const service = require('./service');

const STR = ApplicationCommandOptionType.String;
const INT = ApplicationCommandOptionType.Integer;
const CH = ApplicationCommandOptionType.Channel;
const SUB = ApplicationCommandOptionType.Subcommand;

const NAME_RE = /^[a-z0-9_-]{1,32}$/;
const MATCH_CHOICES = [
  { name: 'contains', value: 'contains' },
  { name: 'exact', value: 'exact' },
  { name: 'startsWith', value: 'startsWith' },
];

function canManage(interaction) {
  return Boolean(interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild));
}

function deleteSelectRow(customId, rows, labelFn, descFn) {
  if (!rows.length) return null;
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(customId)
      .setPlaceholder('Select an entry to delete…')
      .addOptions(rows.slice(0, 25).map((r) => ({ label: labelFn(r).slice(0, 100), description: descFn(r).slice(0, 100), value: String(r.id) }))),
  );
}

const commands = [
  // ── /custom ────────────────────────────────────────────────────────────────
  {
    name: 'custom',
    description: 'Create and manage this server’s own slash commands.',
    cooldown: 5,
    options: [
      {
        name: 'create',
        description: 'Create a new custom command',
        type: SUB,
        options: [
          { name: 'name', description: 'Command name (lowercase letters, numbers, - and _, max 32)', type: STR, required: true, maxLength: 32 },
          { name: 'response', description: 'Bot reply — supports {placeholders} and | random pools', type: STR, required: true, maxLength: 1000 },
        ],
      },
      {
        name: 'edit',
        description: 'Edit the response of a custom command',
        type: SUB,
        options: [
          { name: 'name', description: 'Existing command name', type: STR, required: true, maxLength: 32 },
          { name: 'response', description: 'New response text', type: STR, required: true, maxLength: 1000 },
        ],
      },
      {
        name: 'delete',
        description: 'Delete a custom command',
        type: SUB,
        options: [{ name: 'name', description: 'Command name to delete', type: STR, required: true, maxLength: 32 }],
      },
      { name: 'list', description: 'List all custom commands of this server', type: SUB, options: [] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand(true);
      const name = sub === 'list' ? '' : interaction.options.getString('name', true).trim().toLowerCase();

      if (sub === 'list') {
        const rows = await db.customCommand.findMany({ where: { guildId: interaction.guildId }, orderBy: { name: 'asc' } });
        const embed = new EmbedBuilder()
          .setTitle('⚡ Custom commands')
          .setColor(config.embedColor)
          .setDescription(
            rows.length
              ? rows.map((r) => `\`/${r.name}\` — ${r.uses} use(s) • ${r.enabled ? '🟢 enabled' : '🔴 disabled'}`).join('\n')
              : 'No custom commands yet. Create one with `/custom create`.',
          )
          .setFooter({ text: `${rows.length} command(s)` });
        const components = [];
        if (canManage(interaction) && rows.length) {
          const row = deleteSelectRow(
            'cc:customdel',
            rows,
            (r) => `/${r.name}`,
            (r) => `${r.uses} use(s)`,
          );
          if (row) components.push(row);
        }
        return respond(interaction, cmdCfg.responses.success, {}, rows.length ? `${rows.length} custom command(s).` : 'No custom commands yet.', {
          embeds: [embed],
          components,
          ephemeralDefault: true,
        });
      }

      if (sub === 'create') {
        const response = interaction.options.getString('response', true).trim();
        if (!NAME_RE.test(name)) {
          return replyError(interaction, 'Command names may only contain **lowercase letters, numbers, `-` and `_`** (max 32 characters).');
        }
        if (name === 'dashboard' || name.endsWith('-dashboard')) {
          return replyError(interaction, 'That name is reserved for dashboards.');
        }
        if (ctx.registry.getCommandByName(name)) {
          return replyError(interaction, `\`/${name}\` is already used by a built-in command. Pick another name.`);
        }
        const existing = await db.customCommand.findUnique({ where: { guildId_name: { guildId: interaction.guildId, name } } }).catch(() => null);
        if (existing) {
          return replyError(interaction, `A custom command \`/${name}\` already exists here. Edit it with \`/custom edit\`.`);
        }
        const row = await db.customCommand.create({
          data: {
            guildId: interaction.guildId,
            name,
            responseJson: settings.stringify({ text: response, ephemeral: false }),
            enabled: true,
            createdById: interaction.user.id,
          },
        });
        try {
          await interaction.guild.commands.create({ name, description: 'Custom server command' });
        } catch (err) {
          await db.customCommand.delete({ where: { id: row.id } }).catch(() => {});
          ctx.logger?.warn?.(`[custom] Discord refused /${name}: ${err?.message || err}`);
          return replyError(interaction, 'Discord refused to create that command (it may conflict with an existing one). Try a different name.');
        }
        await ctx.audit.log(interaction.guildId, interaction.user.id, 'custom.create', `customcommand:${name}`, null, { name, response });
        return respond(
          interaction,
          cmdCfg.responses.success,
          { name },
          `✅ Command \`/${name}\` is live — try it with \`/${name}\`.\nResponses support \`{placeholders}\` and \`|\` random pools. Edit with \`/custom edit\`, delete with \`/custom delete\`.`,
          { ephemeralDefault: true },
        );
      }

      if (sub === 'edit') {
        const response = interaction.options.getString('response', true).trim();
        const row = await db.customCommand.findUnique({ where: { guildId_name: { guildId: interaction.guildId, name } } }).catch(() => null);
        if (!row) return replyError(interaction, `No custom command \`/${name}\` exists in this server.`);
        const previous = service.parseResponseJson(row.responseJson);
        await db.customCommand.update({
          where: { id: row.id },
          data: { responseJson: settings.stringify({ text: response, ephemeral: previous.ephemeral }) },
        });
        await ctx.audit.log(interaction.guildId, interaction.user.id, 'custom.edit', `customcommand:${name}`, { response: previous.text }, { response });
        return respond(interaction, cmdCfg.responses.success, { name }, `✏️ Response of \`/${name}\` updated.`, { ephemeralDefault: true });
      }

      // delete
      const row = await db.customCommand.findUnique({ where: { guildId_name: { guildId: interaction.guildId, name } } }).catch(() => null);
      if (!row) return replyError(interaction, `No custom command \`/${name}\` exists in this server.`);
      await db.customCommand.delete({ where: { id: row.id } });
      const guildCommands = await interaction.guild.commands.fetch().catch(() => null);
      const match = guildCommands?.find((c) => c.name === row.name);
      if (match) await interaction.guild.commands.delete(match.id).catch(() => {});
      await ctx.audit.log(interaction.guildId, interaction.user.id, 'custom.delete', `customcommand:${name}`, row, null);
      return respond(interaction, cmdCfg.responses.success, { name }, `🗑️ Custom command \`/${name}\` deleted.`, { ephemeralDefault: true });
    },
  },

  // ── /autoresponder ─────────────────────────────────────────────────────────
  {
    name: 'autoresponder',
    description: 'Auto responders that reply to matching messages.',
    cooldown: 5,
    options: [
      {
        name: 'add',
        description: 'Add an auto responder',
        type: SUB,
        options: [
          { name: 'trigger', description: 'Text to watch for', type: STR, required: true, maxLength: 100 },
          { name: 'response', description: 'Bot reply — supports {placeholders} and | random pools', type: STR, required: true, maxLength: 1000 },
          {
            name: 'match_type',
            description: 'How the trigger matches a message',
            type: STR,
            required: false,
            choices: MATCH_CHOICES,
          },
        ],
      },
      {
        name: 'remove',
        description: 'Remove an auto responder by ID',
        type: SUB,
        options: [{ name: 'id', description: 'Responder ID (see /autoresponder list)', type: INT, required: true, minValue: 1 }],
      },
      { name: 'list', description: 'List all auto responders', type: SUB, options: [] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand(true);

      if (sub === 'list') {
        const rows = await db.autoResponder.findMany({ where: { guildId: interaction.guildId }, orderBy: { id: 'asc' } });
        const embed = new EmbedBuilder()
          .setTitle('🤖 Auto responders')
          .setColor(config.embedColor)
          .setDescription(
            rows.length
              ? rows
                  .map((r) => `\`#${r.id}\` \`${r.matchType}\` "${r.trigger.slice(0, 80)}" • ${r.enabled ? '🟢' : '🔴'} • ${r.cooldown}s`)
                  .join('\n')
              : 'No auto responders yet. Add one with `/autoresponder add`.',
          )
          .setFooter({ text: `${rows.length} responder(s)` });
        const components = [];
        if (canManage(interaction) && rows.length) {
          const row = deleteSelectRow(
            'cc:ardel',
            rows,
            (r) => `#${r.id} ${r.trigger}`,
            (r) => `${r.matchType} • ${r.cooldown}s cooldown`,
          );
          if (row) components.push(row);
        }
        return respond(interaction, cmdCfg.responses.success, {}, rows.length ? `${rows.length} auto responder(s).` : 'No auto responders yet.', {
          embeds: [embed],
          components,
          ephemeralDefault: true,
        });
      }

      if (sub === 'add') {
        const trigger = interaction.options.getString('trigger', true).trim();
        const response = interaction.options.getString('response', true).trim();
        const matchType = interaction.options.getString('match_type') || 'contains';
        if (!trigger) return replyError(interaction, 'The trigger cannot be empty.');
        const row = await db.autoResponder.create({
          data: {
            guildId: interaction.guildId,
            trigger,
            matchType,
            responseJson: settings.stringify({ text: response }),
            enabled: true,
            cooldown: 10,
          },
        });
        service.invalidateGuildCache(interaction.guildId);
        await ctx.audit.log(interaction.guildId, interaction.user.id, 'autoresponder.add', `autoresponder:${row.id}`, null, { trigger, matchType });
        const how = matchType === 'exact' ? 'exactly matches' : matchType === 'startsWith' ? 'starts with' : 'contains';
        return respond(
          interaction,
          cmdCfg.responses.success,
          { id: `${row.id}`, trigger },
          `✅ Auto responder **#${row.id}** added — I will reply when a message ${how} the trigger (10s cooldown per user/channel).`,
          { ephemeralDefault: true },
        );
      }

      // remove
      const id = interaction.options.getInteger('id', true);
      const row = await db.autoResponder.findUnique({ where: { id } }).catch(() => null);
      if (!row || row.guildId !== interaction.guildId) return replyError(interaction, `Auto responder **#${id}** does not exist in this server.`);
      await db.autoResponder.delete({ where: { id } });
      service.invalidateGuildCache(interaction.guildId);
      await ctx.audit.log(interaction.guildId, interaction.user.id, 'autoresponder.remove', `autoresponder:${id}`, row, null);
      return respond(interaction, cmdCfg.responses.success, { id: `${id}` }, `🗑️ Auto responder **#${id}** removed.`, { ephemeralDefault: true });
    },
  },

  // ── /trigger ───────────────────────────────────────────────────────────────
  {
    name: 'trigger',
    description: 'Event triggers that run actions (join events, keyword alerts).',
    cooldown: 5,
    options: [
      {
        name: 'create',
        description: 'Create a new trigger',
        type: SUB,
        options: [
          { name: 'name', description: 'Trigger name', type: STR, required: true, maxLength: 32 },
          {
            name: 'event',
            description: 'When the trigger fires',
            type: STR,
            required: true,
            choices: [
              { name: 'memberJoin', value: 'memberJoin' },
              { name: 'keyword', value: 'keyword' },
            ],
          },
          {
            name: 'actions',
            description: '|-separated actions: assignRole:<id> | removeRole:<id> | sendMessage:<text> | notifyStaff',
            type: STR,
            required: true,
            maxLength: 1500,
          },
          { name: 'keyword', description: 'Keyword to watch for (keyword event)', type: STR, required: false, maxLength: 100 },
          { name: 'channel', description: 'Only fire in this channel (keyword event)', type: CH, required: false },
        ],
      },
      {
        name: 'edit',
        description: 'Edit the actions of a trigger',
        type: SUB,
        options: [
          { name: 'name', description: 'Existing trigger name', type: STR, required: true, maxLength: 32 },
          {
            name: 'actions',
            description: '|-separated actions: assignRole:<id> | removeRole:<id> | sendMessage:<text> | notifyStaff',
            type: STR,
            required: true,
            maxLength: 1500,
          },
        ],
      },
      { name: 'list', description: 'List all triggers', type: SUB, options: [] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand(true);

      if (sub === 'list') {
        const rows = await db.trigger.findMany({ where: { guildId: interaction.guildId }, orderBy: { id: 'asc' } });
        const embed = new EmbedBuilder()
          .setTitle('🎯 Triggers')
          .setColor(config.embedColor)
          .setDescription(
            rows.length
              ? rows
                  .map((r) => {
                    const actions = settings.parse(r.actionsJson, []);
                    const summary = actions.map((a) => service.describeAction(a)).join(' | ') || '*(no actions)*';
                    return `\`#${r.id}\` **${r.name}** — ${r.event} • ${r.enabled ? '🟢' : '🔴'}\n└ ${summary.slice(0, 200)}`;
                  })
                  .join('\n')
              : 'No triggers yet. Create one with `/trigger create`.',
          )
          .setFooter({ text: `${rows.length} trigger(s)` });
        const components = [];
        if (canManage(interaction) && rows.length) {
          const row = deleteSelectRow(
            'cc:triggerdel',
            rows,
            (r) => `#${r.id} ${r.name}`,
            (r) => `${r.event}`,
          );
          if (row) components.push(row);
        }
        return respond(interaction, cmdCfg.responses.success, {}, rows.length ? `${rows.length} trigger(s).` : 'No triggers yet.', {
          embeds: [embed],
          components,
          ephemeralDefault: true,
        });
      }

      if (sub === 'create') {
        const name = interaction.options.getString('name', true).trim();
        const event = interaction.options.getString('event', true);
        const actionsRaw = interaction.options.getString('actions', true);
        const keyword = interaction.options.getString('keyword');
        const channel = interaction.options.getChannel('channel');

        if (event === 'keyword' && !(keyword && keyword.trim())) {
          return replyError(interaction, 'The **keyword** event needs a keyword — pass the `keyword` option.');
        }
        const duplicate = await db.trigger.findFirst({ where: { guildId: interaction.guildId, name } }).catch(() => null);
        if (duplicate) return replyError(interaction, `A trigger named **${name}** already exists. Edit it with \`/trigger edit\`.`);

        const { actions, errors } = service.parseActionsString(actionsRaw, interaction.guild);
        if (errors.length) {
          return replyError(interaction, `Could not parse the actions:\n${errors.join('\n')}`);
        }
        const row = await db.trigger.create({
          data: {
            guildId: interaction.guildId,
            name,
            event,
            conditionsJson: settings.stringify({
              keyword: event === 'keyword' ? keyword.trim() : null,
              channelId: channel ? channel.id : null,
            }),
            actionsJson: settings.stringify(actions),
            enabled: true,
          },
        });
        service.invalidateGuildCache(interaction.guildId);
        await ctx.audit.log(interaction.guildId, interaction.user.id, 'trigger.create', `trigger:${row.id}`, null, { name, event, actions });
        const summary = actions.map((a) => service.describeAction(a)).join('\n');
        return respond(
          interaction,
          cmdCfg.responses.success,
          { name },
          `✅ Trigger **${name}** created (\`${event}\`).\n**Actions**\n${summary}`,
          { ephemeralDefault: true },
        );
      }

      // edit
      const name = interaction.options.getString('name', true).trim();
      const actionsRaw = interaction.options.getString('actions', true);
      const row = await db.trigger.findFirst({ where: { guildId: interaction.guildId, name } }).catch(() => null);
      if (!row) return replyError(interaction, `No trigger named **${name}** exists in this server.`);
      const { actions, errors } = service.parseActionsString(actionsRaw, interaction.guild);
      if (errors.length) {
        return replyError(interaction, `Could not parse the actions:\n${errors.join('\n')}`);
      }
      const before = settings.parse(row.actionsJson, []);
      await db.trigger.update({ where: { id: row.id }, data: { actionsJson: settings.stringify(actions) } });
      service.invalidateGuildCache(interaction.guildId);
      await ctx.audit.log(interaction.guildId, interaction.user.id, 'trigger.edit', `trigger:${row.id}`, { actions: before }, { actions });
      const summary = actions.map((a) => service.describeAction(a)).join('\n');
      return respond(interaction, cmdCfg.responses.success, { name }, `✏️ Trigger **${name}** updated.\n**Actions**\n${summary}`, {
        ephemeralDefault: true,
      });
    },
  },
];

module.exports = { commands };
