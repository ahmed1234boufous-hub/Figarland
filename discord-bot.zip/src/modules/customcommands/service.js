'use strict';

const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../../core/db');
const settings = require('../../core/settings');
const placeholders = require('../../core/placeholders');
const config = require('../../config');
const { replySimple, replyError } = require('../../core/responses');

/**
 * customcommands/service.js — engine for per-guild custom commands,
 * auto responders and event triggers, plus the "cc:" component handler.
 */

const CACHE_TTL_MS = 30 * 1000;
const RESPONDER_DEFAULT_COOLDOWN_S = 10;
const TRIGGER_KEYWORD_COOLDOWN_MS = 30 * 1000;

// guildId → { at, responders, triggers }
const guildCache = new Map();
// `${guildId}:${channelId}:${userId}:${responderId}` → last reply timestamp
const responderCooldowns = new Map();
// `${guildId}:${userId}:${triggerId}` → last run timestamp
const triggerCooldowns = new Map();

// ─────────────────────────────── Parsing helpers ─────────────────────────────

function parseResponseJson(json) {
  const cfg = settings.parse(json, { text: '', ephemeral: false }) || {};
  return {
    text: typeof cfg.text === 'string' ? cfg.text : '',
    ephemeral: Boolean(cfg.ephemeral),
  };
}

/** Pick one random segment from a '|' separated pool. */
function pickSegment(text) {
  if (!text) return '';
  const pool = String(text).split('|').map((s) => s.trim()).filter(Boolean);
  if (!pool.length) return '';
  return pool[Math.floor(Math.random() * pool.length)];
}

function fill(ctx, template, data) {
  return placeholders.fill(template || '', data);
}

function matchContent(content, trigger, matchType) {
  const c = String(content || '').trim().toLowerCase();
  const t = String(trigger || '').trim().toLowerCase();
  if (!t) return false;
  if (matchType === 'exact') return c === t;
  if (matchType === 'startsWith') return c.startsWith(t);
  return c.includes(t); // contains (default)
}

function cooldownOk(map, key, ms) {
  const now = Date.now();
  const until = map.get(key) || 0;
  if (until > now) return false;
  map.set(key, now + ms);
  if (map.size > 8000) {
    for (const [k, v] of map) if (v < now) map.delete(k);
  }
  return true;
}

/**
 * Parse a '|'-separated actions string into trigger action objects.
 * Supported: assignRole:<roleId>, removeRole:<roleId>, sendMessage:<text>,
 * notifyStaff[:<note>].
 * @returns {{ actions: Array, errors: string[] }}
 */
function parseActionsString(raw, guild) {
  const errors = [];
  const actions = [];
  for (const part of String(raw || '').split('|')) {
    const seg = part.trim();
    if (!seg) continue;
    const idx = seg.indexOf(':');
    const type = (idx === -1 ? seg : seg.slice(0, idx)).trim().toLowerCase();
    const arg = idx === -1 ? '' : seg.slice(idx + 1).trim();

    if (type === 'assignrole' || type === 'removerole') {
      const roleId = arg.replace(/[<@&>\s]/g, '');
      if (!/^\d{5,25}$/.test(roleId)) {
        errors.push(`\`${seg}\` — needs a role ID (enable Developer Mode, right-click the role, Copy ID).`);
        continue;
      }
      const role = guild?.roles?.cache?.get(roleId);
      if (!role) {
        errors.push(`\`${seg}\` — role \`${roleId}\` was not found in this server.`);
        continue;
      }
      actions.push({ type: type === 'assignrole' ? 'assignRole' : 'removeRole', roleId });
    } else if (type === 'sendmessage') {
      if (!arg) {
        errors.push('`sendMessage` needs message text, e.g. `sendMessage:Welcome {user}!`.');
        continue;
      }
      actions.push({ type: 'sendMessage', text: arg.slice(0, 500) });
    } else if (type === 'notifystaff') {
      actions.push({ type: 'notifyStaff', text: arg ? arg.slice(0, 300) : '' });
    } else {
      errors.push(`\`${seg}\` — unknown action. Valid: \`assignRole:<roleId>\`, \`removeRole:<roleId>\`, \`sendMessage:<text>\`, \`notifyStaff\`.`);
    }
  }
  if (!actions.length && !errors.length) errors.push('At least one action is required.');
  return { actions, errors };
}

function describeAction(a) {
  if (a.type === 'assignRole') return `assignRole → <@&${a.roleId}>`;
  if (a.type === 'removeRole') return `removeRole → <@&${a.roleId}>`;
  if (a.type === 'sendMessage') return `sendMessage → "${String(a.text || '').slice(0, 60)}"`;
  if (a.type === 'notifyStaff') return 'notifyStaff';
  return a.type;
}

// ─────────────────────────────── Action execution ────────────────────────────

async function resolveRole(guild, roleId) {
  const cached = guild.roles.cache.get(roleId);
  if (cached) return cached;
  return guild.roles.fetch(roleId).catch(() => null);
}

/** Hierarchy-checked role assignment/removal. Returns false when skipped. */
async function safeApplyRole(guild, member, roleId, remove) {
  if (!member || !roleId) return false;
  const role = await resolveRole(guild, roleId);
  if (!role || role.managed) return false;
  const me = guild.members.me;
  if (!me || role.position >= me.roles.highest.position) return false;
  try {
    if (remove) {
      if (!member.roles.cache.has(role.id)) return false;
      await member.roles.remove(role.id, 'Trigger action');
    } else {
      if (member.roles.cache.has(role.id)) return false;
      await member.roles.add(role.id, 'Trigger action');
    }
    return true;
  } catch {
    return false;
  }
}

async function notifyStaff(ctx, guild, user, triggerName, note) {
  const modCfg = await ctx.settings.getModuleConfig(guild.id, 'customcommands').catch(() => null);
  const alertChannelId = modCfg?.settings?.alertChannel;
  const target = (alertChannelId && guild.channels.cache.get(alertChannelId)) || guild.systemChannel || null;
  if (!target || typeof target.send !== 'function') return;
  const embed = new EmbedBuilder()
    .setTitle('🔔 Staff alert')
    .setColor(config.warnColor)
    .setDescription(
      `${note ? `${note}\n` : ''}Trigger: **${triggerName || 'unknown'}**\nMember: <@${user?.id || 'unknown'}>`,
    )
    .setTimestamp();
  await target.send({ embeds: [embed] }).catch(() => {});
}

/**
 * Run a list of trigger actions.
 * targets: { member, user, channel } — channel is the send target for sendMessage.
 */
async function runActions(ctx, guild, targets, actions, triggerName) {
  const list = Array.isArray(actions) ? actions : [];
  for (const action of list) {
    try {
      if (!action || typeof action !== 'object') continue;
      if (action.type === 'assignRole') {
        await safeApplyRole(guild, targets.member, action.roleId, false);
      } else if (action.type === 'removeRole') {
        await safeApplyRole(guild, targets.member, action.roleId, true);
      } else if (action.type === 'sendMessage') {
        const channel = targets.channel;
        if (!channel || typeof channel.send !== 'function') continue;
        const text = fill(ctx, action.text, {
          user: targets.user,
          member: targets.member,
          guild,
          channel: targets.channel,
        });
        if (!text) continue;
        await channel.send({ content: text.slice(0, 2000) }).catch(() => {});
      } else if (action.type === 'notifyStaff') {
        await notifyStaff(ctx, guild, targets.user, triggerName, action.text || '');
      }
    } catch (err) {
      ctx.logger?.warn?.(`[trigger] action failed: ${err?.message || err}`);
    }
  }
}

// ─────────────────────────────── Per-guild caches ────────────────────────────

function invalidateGuildCache(guildId) {
  guildCache.delete(guildId);
}

async function getGuildCache(ctx, guildId) {
  const hit = guildCache.get(guildId);
  if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit;
  const [responders, triggers] = await Promise.all([
    db.autoResponder.findMany({ where: { guildId, enabled: true } }),
    db.trigger.findMany({ where: { guildId, event: 'keyword', enabled: true } }),
  ]);
  const entry = { at: Date.now(), responders, triggers };
  guildCache.set(guildId, entry);
  if (guildCache.size > 300) {
    const now = Date.now();
    for (const [k, v] of guildCache) if (now - v.at >= CACHE_TTL_MS) guildCache.delete(k);
  }
  return entry;
}

// ─────────────────────────────── Hooks ───────────────────────────────────────

/** messageCreate: auto responders + keyword triggers. */
async function handleMessageCreate(ctx, message) {
  if (!message.guild) return;
  if (!message.author || message.author.bot) return; // skip bots
  if (message.author.id === ctx.client.user?.id) return; // never respond to own messages
  const content = typeof message.content === 'string' ? message.content : '';
  if (!content.trim()) return;

  const cache = await getGuildCache(ctx, message.guild.id);
  const data = {
    user: message.author,
    member: message.member,
    guild: message.guild,
    channel: message.channel,
  };

  for (const row of cache.responders) {
    if (!matchContent(content, row.trigger, row.matchType)) continue;
    const text = fill(ctx, pickSegment(parseResponseJson(row.responseJson).text), data);
    if (!text) continue;
    const cdMs = Math.max(0, (parseInt(row.cooldown, 10) || RESPONDER_DEFAULT_COOLDOWN_S) * 1000);
    const key = `${message.guild.id}:${message.channel.id}:${message.author.id}:${row.id}`;
    if (!cooldownOk(responderCooldowns, key, cdMs)) continue;
    // eslint-disable-next-line no-await-in-loop
    await message.reply({ content: text.slice(0, 2000), allowedMentions: { repliedUser: false } }).catch(() => {});
    break; // at most one auto responder reply per message
  }

  for (const trigger of cache.triggers) {
    const conditions = settings.parse(trigger.conditionsJson, {}) || {};
    const keyword = conditions.keyword;
    if (!keyword) continue;
    if (conditions.channelId && message.channel.id !== conditions.channelId) continue;
    if (!content.toLowerCase().includes(String(keyword).toLowerCase())) continue;
    const key = `${message.guild.id}:${message.author.id}:${trigger.id}`;
    if (!cooldownOk(triggerCooldowns, key, TRIGGER_KEYWORD_COOLDOWN_MS)) continue;
    const actions = settings.parse(trigger.actionsJson, []);
    // eslint-disable-next-line no-await-in-loop
    await runActions(ctx, message.guild, data, actions, trigger.name);
    break;
  }
}

/** guildMemberAdd: memberJoin triggers. */
async function handleGuildMemberAdd(ctx, member) {
  if (!member?.guild) return;
  const rows = await db.trigger
    .findMany({ where: { guildId: member.guild.id, event: 'memberJoin', enabled: true } })
    .catch(() => []);
  if (!rows.length) return;
  const data = { user: member.user, member, guild: member.guild, channel: null };
  for (const trigger of rows) {
    const conditions = settings.parse(trigger.conditionsJson, {}) || {};
    const channel =
      (conditions.channelId && member.guild.channels.cache.get(conditions.channelId)) ||
      member.guild.systemChannel ||
      null;
    // eslint-disable-next-line no-await-in-loop
    await runActions(ctx, member.guild, { ...data, channel }, settings.parse(trigger.actionsJson, []), trigger.name);
  }
}

// ─────────────────────────────── Custom command runtime ──────────────────────

/** Called by src/events/interactionCreate.js for per-guild custom commands. */
async function executeCustom(ctx, interaction, row) {
  const cfg = parseResponseJson(row.responseJson);
  const segment = pickSegment(cfg.text) || 'Hello!';
  const filled = fill(ctx, segment, {
    user: interaction.user,
    member: interaction.member,
    guild: interaction.guild,
    channel: interaction.channel,
  });
  const payload = {
    content: (filled || 'Hello!').slice(0, 2000),
    flags: cfg.ephemeral ? 64 : 0,
  };
  await interaction.reply(payload).catch(() => {});
  db.customCommand
    .update({ where: { id: row.id }, data: { uses: { increment: 1 } } })
    .catch(() => {});
}

// ─────────────────────────────── cc: components ──────────────────────────────

async function handleComponent(ctx, interaction, rest) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    return replyError(interaction, 'You need the **Manage Server** permission to use this.');
  }
  const action = String(rest || '');
  const id = parseInt(interaction.values?.[0], 10);
  if (!Number.isFinite(id)) return replyError(interaction, 'Nothing was selected.');

  if (action === 'ardel') {
    const row = await db.autoResponder.findUnique({ where: { id } }).catch(() => null);
    if (!row || row.guildId !== interaction.guildId) return replyError(interaction, 'That auto responder no longer exists.');
    await db.autoResponder.delete({ where: { id } }).catch(() => {});
    invalidateGuildCache(interaction.guildId);
    await ctx.audit.log(interaction.guildId, interaction.user.id, 'autoresponder.remove', `autoresponder:${id}`, row, null);
    return replySimple(interaction, `🗑️ Auto responder **#${id}** removed.`, { ephemeral: true });
  }

  if (action === 'triggerdel') {
    const row = await db.trigger.findUnique({ where: { id } }).catch(() => null);
    if (!row || row.guildId !== interaction.guildId) return replyError(interaction, 'That trigger no longer exists.');
    await db.trigger.delete({ where: { id } }).catch(() => {});
    invalidateGuildCache(interaction.guildId);
    await ctx.audit.log(interaction.guildId, interaction.user.id, 'trigger.remove', `trigger:${id}`, row, null);
    return replySimple(interaction, `🗑️ Trigger **#${id}** (${row.name}) removed.`, { ephemeral: true });
  }

  if (action === 'customdel') {
    const row = await db.customCommand.findUnique({ where: { id } }).catch(() => null);
    if (!row || row.guildId !== interaction.guildId) return replyError(interaction, 'That custom command no longer exists.');
    await db.customCommand.delete({ where: { id } }).catch(() => {});
    const guildCommands = await interaction.guild.commands.fetch().catch(() => null);
    const match = guildCommands?.find((c) => c.name === row.name);
    if (match) await interaction.guild.commands.delete(match.id).catch(() => {});
    await ctx.audit.log(interaction.guildId, interaction.user.id, 'custom.delete', `customcommand:${row.name}`, row, null);
    return replySimple(interaction, `🗑️ Custom command \`/${row.name}\` deleted.`, { ephemeral: true });
  }

  return replySimple(interaction, 'Unknown action.', { ephemeral: true });
}

module.exports = {
  parseResponseJson,
  pickSegment,
  matchContent,
  parseActionsString,
  describeAction,
  runActions,
  getGuildCache,
  invalidateGuildCache,
  handleMessageCreate,
  handleGuildMemberAdd,
  executeCustom,
  handleComponent,
};
