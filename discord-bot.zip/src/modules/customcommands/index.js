'use strict';

const { commands } = require('./commands');
const dashboard = require('./dashboard');
const service = require('./service');

/**
 * customcommands — per-guild slash commands, auto responders and event triggers.
 * `executeCustom` is called by src/events/interactionCreate.js whenever a chat
 * input matches no built-in command but exists as a CustomCommand row.
 */

module.exports = {
  key: 'customcommands',
  name: 'Custom Commands & Auto Responders',
  emoji: '⚡',
  dashboardCommandName: 'customcmd-dashboard',

  settingsSchema: [
    { key: 'alertChannel', label: 'Staff alert channel', type: 'channel', desc: 'notifyStaff actions post here (fallback: system channel).' },
    { key: 'dashboardRoles', label: 'Dashboard access roles', type: 'roles', desc: 'Roles (besides administrators) allowed to open this dashboard.' },
  ],

  defaults: {
    enabled: true,
    settings: {
      alertChannel: null,
      dashboardRoles: [],
    },
    commands: {
      custom: { cooldown: 5, responses: { success: { text: '', ephemeral: true } } },
      autoresponder: { cooldown: 5, responses: { success: { text: '', ephemeral: true } } },
      trigger: { cooldown: 5, responses: { success: { text: '', ephemeral: true } } },
    },
  },

  commands,

  dashboard,

  componentHandlers: {
    'cc:': service.handleComponent,
  },

  hooks: {
    async messageCreate(ctx, message) {
      try {
        await service.handleMessageCreate(ctx, message);
      } catch (err) {
        ctx.logger?.error?.('[customcommands:messageCreate]', err?.message || err);
      }
    },
    async guildMemberAdd(ctx, member) {
      try {
        await service.handleGuildMemberAdd(ctx, member);
      } catch (err) {
        ctx.logger?.error?.('[customcommands:guildMemberAdd]', err?.message || err);
      }
    },
  },

  executeCustom: service.executeCustom,
};
