'use strict';

const db = require('../../core/db');

/**
 * customcommands/dashboard.js — summary lines for the shared dashboard framework.
 * (Custom commands are manageable via /custom.)
 */

module.exports = {
  async summaryLines(guild, modCfg) {
    const [customCount, responderCount, triggerCount] = await Promise.all([
      db.customCommand.count({ where: { guildId: guild.id } }),
      db.autoResponder.count({ where: { guildId: guild.id } }),
      db.trigger.count({ where: { guildId: guild.id } }),
    ]);
    return [
      ['Custom commands', `${customCount}`],
      ['Auto responders', `${responderCount}`],
      ['Triggers', `${triggerCount}`],
    ];
  },
};
