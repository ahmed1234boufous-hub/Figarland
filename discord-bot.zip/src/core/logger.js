'use strict';

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
let current = LEVELS[(process.env.LOG_LEVEL || 'info').toLowerCase()] || LEVELS.info;

function stamp() {
  return new Date().toISOString().slice(11, 19);
}

function log(level, args) {
  if (LEVELS[level] < current) return;
  const line = `[${stamp()}] [${level.toUpperCase()}]`;
  if (level === 'error') console.error(line, ...args);
  else if (level === 'warn') console.warn(line, ...args);
  else console.log(line, ...args);
}

module.exports = {
  setLevel(name) { current = LEVELS[name] || current; },
  debug: (...a) => log('debug', a),
  info: (...a) => log('info', a),
  warn: (...a) => log('warn', a),
  error: (...a) => log('error', a),
};
