'use strict';

const embeds = require('./embeds');
const placeholders = require('./placeholders');
const config = require('../config');
const logger = require('./logger');

/**
 * responses.js — per-command response templates.
 *
 * Every command has independent success / error / info response templates
 * (text + optional embed cfg + ephemeral flag) stored in its CommandConfig.
 * Text supports {variables} and falls back to a provided default.
 */

function buildPayload(kindCfg, vars, fallbackText) {
  const payload = {};
  const text = kindCfg?.text ? placeholders.fill(kindCfg.text, vars) : fallbackText || '';
  if (text) payload.content = text.slice(0, 2000);
  const embed = embeds.buildEmbed(kindCfg?.embed, vars);
  if (embed) payload.embeds = [embed];
  if (!payload.content && !payload.embeds) payload.content = fallbackText || 'Done.';
  return payload;
}

function isEphemeral(kindCfg, fallback = false) {
  return Boolean(kindCfg?.ephemeral ?? fallback);
}

/**
 * Reply (or follow up) to an interaction using the stored response template.
 * @param {Interaction} interaction
 * @param {object} kindCfg  e.g. cmdCfg.responses.success
 * @param {object} vars     placeholder variables
 * @param {string} fallback default text if no template is configured
 * @param {object} opts     { ephemeral, components, files, embeds(extra) }
 */
async function respond(interaction, kindCfg, vars, fallback, opts = {}) {
  const payload = buildPayload(kindCfg, vars, fallback);
  payload.flags = isEphemeral(kindCfg, opts.ephemeralDefault ?? false) ? 64 : 0;
  if (opts.components) payload.components = opts.components;
  if (opts.files) payload.files = opts.files;
  if (opts.embeds) payload.embeds = [...(payload.embeds || []), ...opts.embeds];
  try {
    if (interaction.deferred || interaction.replied) {
      return await interaction.editReply(payload).catch(() => interaction.followUp({ ...payload, flags: 0 }));
    }
    return await interaction.reply(payload);
  } catch (err) {
    logger.error('[respond]', err?.message || err);
    return null;
  }
}

/** Quick ephemeral error reply that does not depend on any config. */
async function replyError(interaction, text) {
  const payload = {
    embeds: [{ color: config.errorColor, description: `❌ ${text}` }],
    flags: 64,
  };
  try {
    if (interaction.deferred || interaction.replied) return await interaction.followUp({ ...payload, flags: 64 });
    return await interaction.reply(payload);
  } catch {
    return null;
  }
}

/** Quick plain reply (ephemeral by default for dashboard-ish flows). */
async function replySimple(interaction, text, { ephemeral = true, embed = null, components = null, files = null } = {}) {
  const payload = { flags: ephemeral ? 64 : 0 };
  if (embed) payload.embeds = [embed];
  else payload.content = text;
  if (components) payload.components = components;
  if (files) payload.files = files;
  try {
    if (interaction.deferred || interaction.replied) return await interaction.editReply(payload);
    return await interaction.reply(payload);
  } catch (err) {
    logger.error('[replySimple]', err?.message || err);
    return null;
  }
}

module.exports = { buildPayload, respond, replyError, replySimple };
