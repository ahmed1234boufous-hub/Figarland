'use strict';

/**
 * placeholders.js — dynamic variable substitution used across all modules.
 *
 * Standard: {user} {username} {displayname} {avatar} {userid} {server}
 *           {servericon} {membercount} {createdate} {joindate} {boostcount}
 *           {channel} {channelname}
 * Extra variables are passed via vars and override the standard ones, e.g.
 *   {level} {oldlevel} {xp} {requiredxp} {totalxp} {rank} {reason} {moderator}
 *   {target} {duration} {case} {amount} {currency} {prize} {winners}
 */

function fmtDate(date) {
  if (!date) return 'Unknown';
  const d = typeof date === 'number' ? new Date(date) : date;
  return `${d.toISOString().slice(0, 10)}`;
}

function avatarUrl(user) {
  return user?.displayAvatarURL ? user.displayAvatarURL({ size: 512, extension: 'png' }) : '';
}

/**
 * @param {string} template
 * @param {object} data { interaction?, member?, user?, guild?, channel?, extra? }
 * @returns {string}
 */
function fill(template, data = {}) {
  if (!template) return '';
  const user = data.user || data.interaction?.user || data.member?.user || null;
  const member = data.member || data.interaction?.member || null;
  const guild = data.guild || data.interaction?.guild || member?.guild || null;
  const channel = data.channel || data.interaction?.channel || null;
  const extra = data.extra || {};

  const map = {
    user: user ? `<@${user.id}>` : '',
    username: user?.username ?? '',
    displayname: member?.displayName ?? user?.globalName ?? user?.username ?? '',
    avatar: avatarUrl(user),
    userid: user?.id ?? '',
    server: guild?.name ?? '',
    servericon: guild?.iconURL ? guild.iconURL({ size: 256, extension: 'png' }) || '' : '',
    membercount: guild?.memberCount?.toString() ?? '',
    createdate: user ? fmtDate(user.createdAt) : '',
    joindate: member?.joinedTimestamp ? fmtDate(member.joinedTimestamp) : '',
    boostcount: guild?.premiumSubscriptionCount?.toString() ?? '0',
    channel: channel ? `<#${channel.id}>` : '',
    channelname: channel?.name ?? '',
  };
  Object.assign(map, extra);

  return template.replace(/\{(\w+)\}/g, (match, key) => {
    if (Object.prototype.hasOwnProperty.call(map, key)) {
      const v = map[key];
      return v === null || v === undefined ? '' : String(v);
    }
    return match; // leave unknown variables untouched
  });
}

/** All standard variables with sample data — used by /dashboard variables. */
function documentation() {
  return [
    ['{user}', 'Mentions the member'],
    ['{username}', 'Member username'],
    ['{displayname}', 'Member display name'],
    ['{avatar}', 'Member avatar URL'],
    ['{userid}', 'Member Discord ID'],
    ['{server}', 'Server name'],
    ['{servericon}', 'Server icon URL'],
    ['{membercount}', 'Current member count'],
    ['{createdate}', 'Account creation date'],
    ['{joindate}', 'Server join date'],
    ['{boostcount}', 'Server boost count'],
    ['{channel}', 'Mentions the channel'],
    ['{channelname}', 'Channel name'],
    ['{currency}', 'Economy currency name (economy)'],
    ['{level} {xp} {requiredxp} {totalxp} {rank}', 'Leveling variables (leveling)'],
    ['{oldlevel}', 'Previous level (level-up announcements)'],
    ['{reason} {moderator} {target} {duration} {case}', 'Moderation variables'],
    ['{amount}', 'Currency amounts (economy/pay)'],
    ['{prize} {winners}', 'Giveaway variables'],
  ];
}

module.exports = { fill, documentation };
