'use strict';

/**
 * In-memory cooldown store. Keyed per guild:user:command.
 * Sweep occasionally to keep memory bounded.
 */

const buckets = new Map();

function check(key, seconds) {
  if (!seconds || seconds <= 0) return { ok: true, remaining: 0 };
  const now = Date.now();
  const until = buckets.get(key) || 0;
  if (until > now) return { ok: false, remaining: Math.ceil((until - now) / 1000) };
  buckets.set(key, now + seconds * 1000);
  return { ok: true, remaining: 0 };
}

function sweep() {
  const now = Date.now();
  for (const [k, v] of buckets) if (v < now) buckets.delete(k);
}

setInterval(sweep, 10 * 60 * 1000).unref();

module.exports = { check };
