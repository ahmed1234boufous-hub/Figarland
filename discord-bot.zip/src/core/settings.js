'use strict';

/**
 * settings.js — per-guild, per-module, per-command configuration service.
 *
 * Storage model (see prisma/schema.prisma):
 *   ModuleConfig  → one row per (guild, module)    : { enabled, settingsJson }
 *   CommandConfig → one row per (guild, module, cmd): { enabled, configJson }
 *
 * Defaults come from each module's `defaults` block (see registry.getModule).
 * SQLite has no JSON type, so JSON is stored in string columns and parsed here.
 */

const db = require('./db');
const registry = require('./registry');

function parse(json, fallback) {
  if (json === null || json === undefined) return fallback;
  try {
    const v = JSON.parse(json);
    return v === null || v === undefined ? fallback : v;
  } catch {
    return fallback;
  }
}

function stringify(value) {
  return JSON.stringify(value ?? {});
}

/** Shallow-merge `patch` into `base` (arrays are replaced, not merged). */
function mergePatch(base, patch) {
  const out = { ...base };
  for (const [k, v] of Object.entries(patch || {})) {
    if (v === undefined) continue;
    if (v !== null && typeof v === 'object' && !Array.isArray(v) && typeof out[k] === 'object' && out[k] !== null && !Array.isArray(out[k])) {
      out[k] = mergePatch(out[k], v);
    } else {
      out[k] = v;
    }
  }
  return out;
}

// ───────────────────────────── Module-level config ───────────────────────────

function moduleDefaults(moduleKey) {
  const def = registry.getModule(moduleKey);
  return {
    enabled: def?.defaults?.enabled ?? true,
    settings: def?.defaults?.settings ?? {},
  };
}

async function getModuleConfig(guildId, moduleKey) {
  const def = moduleDefaults(moduleKey);
  const row = await db.moduleConfig.findUnique({ where: { guildId_moduleKey: { guildId, moduleKey } } });
  if (!row) return { enabled: def.enabled, settings: def.settings, _exists: false };
  return {
    enabled: row.enabled,
    settings: mergePatch(def.settings, parse(row.settingsJson, {})),
    _exists: true,
  };
}

async function setModuleConfig(guildId, moduleKey, patch) {
  const current = await getModuleConfig(guildId, moduleKey);
  const nextEnabled = typeof patch.enabled === 'boolean' ? patch.enabled : current.enabled;
  const nextSettings = patch.settings ? mergePatch(current.settings, patch.settings) : current.settings;

  await db.moduleConfig.upsert({
    where: { guildId_moduleKey: { guildId, moduleKey } },
    create: { guildId, moduleKey, enabled: nextEnabled, settingsJson: stringify(nextSettings) },
    update: { enabled: nextEnabled, settingsJson: stringify(nextSettings) },
  });
  return { enabled: nextEnabled, settings: nextSettings };
}

async function setModuleSetting(guildId, moduleKey, key, value) {
  return setModuleConfig(guildId, moduleKey, { settings: { [key]: value } });
}

// ───────────────────────────── Command-level config ──────────────────────────

function commandDefaults(moduleKey, commandKey) {
  const def = registry.getCommand(moduleKey, commandKey);
  return {
    enabled: true,
    cooldown: def?.cooldown ?? 0,
    allowedRoles: [],
    blockedRoles: [],
    allowedChannels: [],
    blockedChannels: [],
    requirePerms: def?.requiredPerms ? [...def.requiredPerms] : [],
    settings: def?.defaults?.settings ?? {},
    responses: {
      success: { text: def?.defaults?.responses?.success?.text ?? '', ephemeral: def?.defaults?.responses?.success?.ephemeral ?? false, embed: null },
      error: { text: def?.defaults?.responses?.error?.text ?? '', ephemeral: true, embed: null },
      info: { text: def?.defaults?.responses?.info?.text ?? '', ephemeral: true, embed: null },
    },
  };
}

async function getCommandConfig(guildId, moduleKey, commandKey) {
  const base = commandDefaults(moduleKey, commandKey);
  const row = await db.commandConfig.findUnique({
    where: { guildId_moduleKey_commandKey: { guildId, moduleKey, commandKey } },
  });
  if (!row) return { ...base, _exists: false };
  const stored = parse(row.configJson, {});
  return { ...mergePatch(base, stored), enabled: row.enabled, _exists: true };
}

async function setCommandConfig(guildId, moduleKey, commandKey, patch, enabled) {
  const current = await getCommandConfig(guildId, moduleKey, commandKey);
  const merged = mergePatch(current, patch);
  const nextEnabled = typeof enabled === 'boolean' ? enabled : current.enabled;
  // Never persist derived/underscore keys.
  const { _exists, ...clean } = merged;
  await db.commandConfig.upsert({
    where: { guildId_moduleKey_commandKey: { guildId, moduleKey, commandKey } },
    create: { guildId, moduleKey, commandKey, enabled: nextEnabled, configJson: stringify(clean) },
    update: { enabled: nextEnabled, configJson: stringify(clean) },
  });
  return { ...merged, enabled: nextEnabled };
}

module.exports = {
  parse,
  stringify,
  mergePatch,
  getModuleConfig,
  setModuleConfig,
  setModuleSetting,
  getCommandConfig,
  setCommandConfig,
};
