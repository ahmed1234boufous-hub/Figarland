'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits,
  MessageFlags,
} = require('discord.js');
const settings = require('./settings');
const permissions = require('./permissions');
const responses = require('./responses');
const audit = require('./audit');
const config = require('../config');

/**
 * dashboards.js — shared dashboard framework.
 *
 * Every module gets an interactive, ephemeral control panel. All views are
 * stateless: each customId fully describes the target view, so panels survive
 * bot restarts. customId scheme:
 *   dash:<moduleKey>:<action>[:<payload>]
 * Modals:
 *   dashm:<moduleKey>:<action>:<payload>
 * Module-specific extra actions are prefixed "x:" and delegated to the module.
 */

const PERMS = PermissionFlagsBits;

function cid(moduleKey, action, payload = '') {
  return `dash:${moduleKey}:${action}${payload ? `:${payload}` : ''}`;
}

function dashCid(moduleKey, action, payload = '') {
  return `dashm:${moduleKey}:${action}${payload ? `:${payload}` : ''}`;
}

function edit(interaction, payload) {
  const p = { ...payload, flags: MessageFlags.Ephemeral };
  if (interaction.deferred || interaction.replied) return interaction.editReply(p);
  return interaction.reply(p);
}

function btn(label, style, customId, disabled = false) {
  return new ButtonBuilder().setLabel(label).setStyle(style).setCustomId(customId).setDisabled(disabled);
}

function trunc(s, n = 80) {
  if (!s) return '';
  return s.length > n ? `${s.slice(0, n - 1)}…` : s;
}

function listMentions(ids, guild, kind = 'role') {
  if (!ids?.length) return 'None';
  return ids
    .slice(0, 10)
    .map((id) => (kind === 'role' ? `<@&${id}>` : `<#${id}>`))
    .join(' ') + (ids.length > 10 ? ` *(+${ids.length - 10})*` : '');
}

// ─────────────────────────────── View builders ───────────────────────────────

async function overviewView(ctx, moduleKey) {
  const def = ctx.registry.getModule(moduleKey);
  const modCfg = await settings.getModuleConfig(ctx.currentGuildId, moduleKey);
  const guild = ctx.client.guilds.cache.get(ctx.currentGuildId);

  const enabledCount = [];
  for (const cmd of def.commands) {
    // eslint-disable-next no-await-in-loop
    const cc = await settings.getCommandConfig(guild.id, moduleKey, cmd.name);
    if (cc.enabled) enabledCount.push(cmd.name);
  }

  const embed = new EmbedBuilder()
    .setTitle(`${def.emoji || '🧩'} ${def.name} — Dashboard`)
    .setColor(modCfg.enabled ? config.embedColor : config.errorColor)
    .setDescription(
      `${modCfg.enabled ? '🟢 Module is **enabled**.' : '🔴 Module is **disabled** — none of its commands respond.'}\n` +
        `**${enabledCount.length}/${def.commands.length}** commands enabled.\n` +
        `Use the buttons below to configure commands, permissions and behavior.`,
    )
    .setFooter({ text: 'Ephemeral panel — only you can see this' });

  const extraLines = def.dashboard?.summaryLines ? await def.dashboard.summaryLines(guild, modCfg, ctx) : [];
  for (const line of extraLines.slice(0, 3)) embed.addFields({ name: line[0], value: trunc(line[1], 1024), inline: false });

  const dashRoles = modCfg.settings?.dashboardRoles || [];
  embed.addFields({
    name: 'Dashboard access',
    value: `Administrators ${dashRoles.length ? `+ ${dashRoles.length} role(s)` : ''}`,
    inline: true,
  });

  const row1 = new ActionRowBuilder().addComponents(
    btn(modCfg.enabled ? 'Module: ON' : 'Module: OFF', modCfg.enabled ? ButtonStyle.Success : ButtonStyle.Danger, cid(moduleKey, 'moduletoggle')),
    btn('Commands', ButtonStyle.Primary, cid(moduleKey, 'cmds', '0')),
    btn('Advanced', ButtonStyle.Secondary, cid(moduleKey, 'advanced')),
    btn('History', ButtonStyle.Secondary, cid(moduleKey, 'hist', '0')),
    btn('Refresh', ButtonStyle.Secondary, cid(moduleKey, 'overview')),
  );

  const components = [row1];
  const extraButtons = def.dashboard?.extraOverviewButtons ? await def.dashboard.extraOverviewButtons(guild, modCfg, ctx) : [];
  if (extraButtons.length) {
    const row2 = new ActionRowBuilder().addComponents(
      extraButtons.slice(0, 5).map((b) =>
        btn(b.label, b.style || ButtonStyle.Secondary, b.action.startsWith('x:') ? cid(moduleKey, b.action) : cid(moduleKey, b.action, b.payload || '')),
      ),
    );
    components.push(row2);
  }
  return { embeds: [embed], components, flags: MessageFlags.Ephemeral };
}

async function commandsView(ctx, moduleKey, page = 0) {
  const guild = ctx.client.guilds.cache.get(ctx.currentGuildId);
  const def = ctx.registry.getModule(moduleKey);
  const perPage = 20;
  const rows = [];
  const all = [];
  for (const cmd of def.commands) {
    // eslint-disable-next no-await-in-loop
    const cc = await settings.getCommandConfig(guild.id, moduleKey, cmd.name);
    all.push({ cmd, cc });
    rows.push(`${cc.enabled ? '🟢' : '🔴'} \`/${cmd.name}\` — ${cc.enabled ? 'ON' : 'OFF'}${cc.cooldown ? ` • ${cc.cooldown}s cooldown` : ''}`);
  }
  const pages = Math.max(1, Math.ceil(all.length / perPage));
  page = Math.min(Math.max(0, page), pages - 1);
  const slice = rows.slice(page * perPage, page * perPage + perPage);

  const embed = new EmbedBuilder()
    .setTitle(`${def.emoji || '🧩'} ${def.name} — Commands`)
    .setColor(config.embedColor)
    .setDescription(slice.join('\n') || 'No commands in this module.')
    .setFooter({ text: `Page ${page + 1}/${pages} • Select a command below to edit it` });

  const options = all.slice(page * perPage, page * perPage + perPage).map(({ cmd, cc }) => ({
    label: `/${cmd.name}`.slice(0, 100),
    description: `${cc.enabled ? 'Enabled' : 'Disabled'} • cooldown ${cc.cooldown || 0}s`.slice(0, 100),
    value: `cmd:${cmd.name}`,
  }));

  const components = [
    new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder().setCustomId(cid(moduleKey, 'cmdsel')).setPlaceholder('Select a command to configure…').addOptions(options),
    ),
  ];
  const nav = [btn('Overview', ButtonStyle.Secondary, cid(moduleKey, 'overview'))];
  if (pages > 1) {
    if (page > 0) nav.push(btn('◀ Prev', ButtonStyle.Secondary, cid(moduleKey, 'cmds', String(page - 1))));
    if (page < pages - 1) nav.push(btn('Next ▶', ButtonStyle.Secondary, cid(moduleKey, 'cmds', String(page + 1))));
  }
  components.push(new ActionRowBuilder().addComponents(nav));
  return { embeds: [embed], components, flags: MessageFlags.Ephemeral };
}

async function commandEditorView(ctx, moduleKey, commandKey) {
  const guild = ctx.client.guilds.cache.get(ctx.currentGuildId);
  const def = ctx.registry.getModule(moduleKey);
  const cmdDef = def.commands.find((c) => c.name === commandKey);
  if (!cmdDef) return { content: 'Unknown command.', flags: MessageFlags.Ephemeral };
  const cc = await settings.getCommandConfig(guild.id, moduleKey, commandKey);

  const embed = new EmbedBuilder()
    .setTitle(`⚙️ \`/${commandKey}\` — Command editor`)
    .setColor(cc.enabled ? config.embedColor : config.errorColor)
    .addFields(
      { name: 'Status', value: cc.enabled ? '🟢 Enabled' : '🔴 Disabled', inline: true },
      { name: 'Cooldown', value: cc.cooldown ? `${cc.cooldown}s` : 'None', inline: true },
      { name: 'Required perms', value: cmdDef.requiredPerms?.join(', ') || 'None', inline: true },
      { name: 'Allowed roles', value: listMentions(cc.allowedRoles, guild, 'role'), inline: true },
      { name: 'Blocked roles', value: listMentions(cc.blockedRoles, guild, 'role'), inline: true },
      { name: 'Channel limits', value: cc.allowedChannels.length ? `Only: ${listMentions(cc.allowedChannels, guild, 'channel')}` : `Blocked: ${listMentions(cc.blockedChannels, guild, 'channel')}`, inline: true },
    );

  const resp = cc.responses?.success;
  let respValue = resp?.text ? trunc(placeholdersFree(resp.text), 200) : '*(default response)*';
  if (resp?.embed) respValue += `\n**Embed:** ${trunc(resp.embed.title || resp.embed.description || '(custom embed)', 120)}`;
  embed.addFields({ name: 'Success response', value: respValue });

  const row1 = new ActionRowBuilder().addComponents(
    btn(cc.enabled ? 'Enabled ✓' : 'Disabled ✗', cc.enabled ? ButtonStyle.Success : ButtonStyle.Danger, cid(moduleKey, 'toggle', commandKey)),
    btn('Cooldown', ButtonStyle.Secondary, cid(moduleKey, 'cooldownm', commandKey)),
    btn('Response text', ButtonStyle.Secondary, cid(moduleKey, 'respm', `success:${commandKey}`)),
    btn('Embed studio', ButtonStyle.Primary, cid(moduleKey, 'embedm', `success:${commandKey}`)),
  );
  const row2 = new ActionRowBuilder().addComponents(
    btn('Permissions', ButtonStyle.Secondary, cid(moduleKey, 'perms', commandKey)),
    btn('◀ Back to commands', ButtonStyle.Secondary, cid(moduleKey, 'cmds', '0')),
  );

  const components = [row1, row2];
  const extras = def.dashboard?.extraCommandButtons ? await def.dashboard.extraCommandButtons(commandKey, cc) : [];
  if (extras.length) {
    components.push(
      new ActionRowBuilder().addComponents(
        extras.slice(0, 5).map((b) => btn(b.label, b.style || ButtonStyle.Secondary, cid(moduleKey, b.action.startsWith('x:') ? b.action : `x:${b.action}`, b.payload || commandKey))),
      ),
    );
  }
  return { embeds: [embed], components, flags: MessageFlags.Ephemeral };
}

function placeholdersFree(text) {
  return text; // kept for clarity; variables render raw in previews
}

async function permissionsView(ctx, moduleKey, commandKey) {
  const guild = ctx.client.guilds.cache.get(ctx.currentGuildId);
  const cc = await settings.getCommandConfig(guild.id, moduleKey, commandKey);

  const embed = new EmbedBuilder()
    .setTitle(`🔐 \`/${commandKey}\` — Permissions`)
    .setColor(config.embedColor)
    .setDescription(
      `**Allowed roles:** ${listMentions(cc.allowedRoles, guild)}\n` +
        `**Blocked roles:** ${listMentions(cc.blockedRoles, guild)}\n` +
        `**Allowed channels:** ${listMentions(cc.allowedChannels, guild, 'channel')}\n` +
        `**Blocked channels:** ${listMentions(cc.blockedChannels, guild, 'channel')}\n\n` +
        `Pick roles/channels below — submitting an empty selection clears the list. Administrators always bypass role limits.`,
    );

  const components = [
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder()
        .setCustomId(cid(moduleKey, 'sel', `allowedRoles:${commandKey}`))
        .setPlaceholder('Allowed roles (empty selection = everyone)')
        .setMinValues(0)
        .setMaxValues(25),
    ),
    new ActionRowBuilder().addComponents(
      new RoleSelectMenuBuilder()
        .setCustomId(cid(moduleKey, 'sel', `blockedRoles:${commandKey}`))
        .setPlaceholder('Blocked roles (deny these roles)')
        .setMinValues(0)
        .setMaxValues(25),
    ),
    new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId(cid(moduleKey, 'sel', `allowedChannels:${commandKey}`))
        .setPlaceholder('Allowed channels (empty selection = all channels)')
        .setMinValues(0)
        .setMaxValues(25)
        .setChannelTypes(ChannelType.GuildText),
    ),
    new ActionRowBuilder().addComponents(
      new ChannelSelectMenuBuilder()
        .setCustomId(cid(moduleKey, 'sel', `blockedChannels:${commandKey}`))
        .setPlaceholder('Blocked channels')
        .setMinValues(0)
        .setMaxValues(25)
        .setChannelTypes(ChannelType.GuildText),
    ),
    new ActionRowBuilder().addComponents(
      btn('◀ Back to editor', ButtonStyle.Secondary, cid(moduleKey, 'cmd', commandKey)),
    ),
  ];
  return { embeds: [embed], components, flags: MessageFlags.Ephemeral };
}

async function advancedView(ctx, moduleKey) {
  const guild = ctx.client.guilds.cache.get(ctx.currentGuildId);
  const def = ctx.registry.getModule(moduleKey);
  const modCfg = await settings.getModuleConfig(guild.id, moduleKey);
  const schema = def.settingsSchema || [];

  const embed = new EmbedBuilder()
    .setTitle(`${def.emoji || '🧩'} ${def.name} — Advanced settings`)
    .setColor(config.embedColor)
    .setDescription(schema.length ? 'Module-specific behavior. Click a setting to change it.' : 'This module has no extra settings.');

  const rows = [];
  const buttons = [];
  const selects = [];

  for (const s of schema) {
    const value = modCfg.settings[s.key];
    let shown = '*(empty)*';
    if (s.type === 'channel') shown = value ? `<#${value}>` : '*(none)*';
    else if (s.type === 'role') shown = value ? `<@&${value}>` : '*(none)*';
    else if (s.type === 'roles') shown = Array.isArray(value) && value.length ? listMentions(value, guild) : '*(none)*';
    else if (s.type === 'boolean') shown = value ? 'ON' : 'OFF';
    else shown = trunc(String(value ?? ''), 60) || '*(empty)*';
    embed.addFields({ name: `${s.label}`, value: `${shown}\n${s.desc ? trunc(s.desc, 120) : ''}`.trim(), inline: false });

    if (s.type === 'boolean') {
      buttons.push(btn(`${s.label}: ${value ? 'ON' : 'OFF'}`, value ? ButtonStyle.Success : ButtonStyle.Secondary, cid(moduleKey, 'advbool', s.key)));
    } else if (s.type === 'channel') {
      selects.push(
        new ActionRowBuilder().addComponents(
          new ChannelSelectMenuBuilder()
            .setCustomId(cid(moduleKey, 'chsel', s.key))
            .setPlaceholder(`Set ${s.label}…`)
            .setMinValues(0)
            .setMaxValues(1)
            .setChannelTypes(ChannelType.GuildText),
        ),
      );
    } else if (s.type === 'role' || s.type === 'roles') {
      selects.push(
        new ActionRowBuilder().addComponents(
          new RoleSelectMenuBuilder()
            .setCustomId(cid(moduleKey, 'chsel', s.key))
            .setPlaceholder(`Set ${s.label}…`)
            .setMinValues(0)
            .setMaxValues(s.type === 'roles' ? 25 : 1),
        ),
      );
    } else {
      buttons.push(btn(`Edit: ${s.label}`, ButtonStyle.Secondary, cid(moduleKey, 'advset', s.key)));
    }
  }

  for (let i = 0; i < buttons.length && rows.length < 4; i += 5) {
    rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + 5)));
  }
  for (const s of selects) {
    if (rows.length >= 5) {
      embed.setFooter({ text: 'Some settings exceed the Discord component limit — use the module commands to edit them.' });
      break;
    }
    rows.push(s);
  }
  rows.push(new ActionRowBuilder().addComponents(btn('◀ Overview', ButtonStyle.Secondary, cid(moduleKey, 'overview'))));
  if (rows.length > 5) rows.splice(5); // Discord hard limit: 5 rows
  return { embeds: [embed], components: rows, flags: MessageFlags.Ephemeral };
}

async function historyView(ctx, moduleKey, page = 0) {
  const guild = ctx.client.guilds.cache.get(ctx.currentGuildId);
  const def = ctx.registry.getModule(moduleKey);
  // Module dashboards show entries for their own module only.
  const all = await audit.recent(guild.id, 50);
  const filtered =
    moduleKey === 'core'
      ? all
      : all.filter((e) => {
          const t = e.target || '';
          return t === `module:${moduleKey}` || t.startsWith(`command:${moduleKey}:`) || t.startsWith(`${moduleKey}:`);
        });
  const perPage = 10;
  const pages = Math.max(1, Math.ceil(filtered.length / perPage));
  page = Math.min(Math.max(0, page), pages - 1);
  const slice = filtered.slice(page * perPage, page * perPage + perPage);

  const embed = new EmbedBuilder()
    .setTitle('🕓 Configuration history')
    .setColor(config.embedColor)
    .setDescription(
      slice
        .map(
          (e, i) =>
            `**${page * perPage + i + 1}.** \`${e.createdAt.toISOString().slice(0, 16).replace('T', ' ')}\` <@${e.actorId || '?'}> — ${e.action} • \`${e.target}\``,
        )
        .join('\n') || 'No configuration changes recorded yet.',
    )
    .setFooter({ text: `Page ${page + 1}/${pages} • Select an entry to revert it` });

  const components = [];
  if (slice.length) {
    components.push(
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(cid(moduleKey, 'revertsel'))
          .setPlaceholder('Revert a change…')
          .addOptions(
            slice.map((e, i) => ({
              label: `${e.action} #${e.id}`.slice(0, 100),
              description: `${e.target} • ${e.createdAt.toISOString().slice(0, 16).replace('T', ' ')}`.slice(0, 100),
              value: String(e.id),
            })),
          ),
      ),
    );
  }
  const nav = [btn('◀ Overview', ButtonStyle.Secondary, cid(moduleKey, 'overview'))];
  if (pages > 1) {
    if (page > 0) nav.push(btn('◀ Prev', ButtonStyle.Secondary, cid(moduleKey, 'hist', String(page - 1))));
    if (page < pages - 1) nav.push(btn('Next ▶', ButtonStyle.Secondary, cid(moduleKey, 'hist', String(page + 1))));
  }
  components.push(new ActionRowBuilder().addComponents(nav));
  return { embeds: [embed], components, flags: MessageFlags.Ephemeral };
}

// ─────────────────────────────── Entry points ────────────────────────────────

/** Open a module dashboard from its /<module>-dashboard command. */
async function open(interaction, ctx, moduleKey) {
  const modCfg = await settings.getModuleConfig(interaction.guildId, moduleKey);
  if (!permissions.canUseDashboard(interaction.member, modCfg)) {
    return responses.replyError(interaction, 'You do not have permission to open this dashboard. Administrators can grant access via **Advanced → Dashboard roles**.');
  }
  ctx.currentGuildId = interaction.guildId;
  const view = await overviewView(ctx, moduleKey);
  return interaction.reply(view);
}

async function guard(interaction, moduleKey) {
  const modCfg = await settings.getModuleConfig(interaction.guildId, moduleKey);
  if (!permissions.canUseDashboard(interaction.member, modCfg)) {
    await responses.replyError(interaction, 'You do not have permission to use this dashboard.');
    return null;
  }
  return modCfg;
}

/** Route a dash:* component interaction. */
async function routeComponent(interaction, ctx) {
  const [, moduleKey, action, ...rest] = interaction.customId.split(':');
  const payload = rest.join(':');
  const modCfg = await guard(interaction, moduleKey);
  if (!modCfg) return;

  ctx.currentGuildId = interaction.guildId;

  switch (action) {
    case 'overview':
      return edit(interaction, await overviewView(ctx, moduleKey));
    case 'moduletoggle': {
      const before = { enabled: modCfg.enabled, settings: modCfg.settings };
      const next = await settings.setModuleConfig(interaction.guildId, moduleKey, { enabled: !modCfg.enabled });
      await audit.log(interaction.guildId, interaction.user.id, 'config.module.enabled', `module:${moduleKey}`, before, next);
      return edit(interaction, await overviewView(ctx, moduleKey));
    }
    case 'cmds':
      return edit(interaction, await commandsView(ctx, moduleKey, parseInt(payload || '0', 10) || 0));
    case 'cmdsel': {
      const value = interaction.values?.[0];
      if (!value?.startsWith('cmd:')) return;
      return edit(interaction, await commandEditorView(ctx, moduleKey, value.slice(4)));
    }
    case 'cmd':
      return edit(interaction, await commandEditorView(ctx, moduleKey, payload));
    case 'toggle': {
      const cc = await settings.getCommandConfig(interaction.guildId, moduleKey, payload);
      const before = { ...cc };
      const next = await settings.setCommandConfig(interaction.guildId, moduleKey, payload, {}, !cc.enabled);
      await audit.log(interaction.guildId, interaction.user.id, 'config.command.enabled', `command:${moduleKey}:${payload}`, before, next);
      return edit(interaction, await commandEditorView(ctx, moduleKey, payload));
    }
    case 'cooldownm': {
      const { ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
      const modal = new ModalBuilder().setCustomId(dashCid(moduleKey, 'cooldown', payload)).setTitle(`Cooldown for /${payload}`);
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('seconds').setLabel('Cooldown in seconds (0 = none)').setStyle(TextInputStyle.Short).setRequired(true).setValue('3'),
        ),
      );
      return interaction.showModal(modal);
    }
    case 'respm': {
      const [kind, commandKey] = payload.split(':');
      const cc = await settings.getCommandConfig(interaction.guildId, moduleKey, commandKey);
      const { ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
      const modal = new ModalBuilder().setCustomId(dashCid(moduleKey, 'resp', `${kind}:${commandKey}`)).setTitle(`/${commandKey} — ${kind} response`);
      const r = cc.responses?.[kind] || {};
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('text').setLabel('Message text ({variables} allowed)').setStyle(TextInputStyle.Paragraph).setRequired(false).setValue(r.text || '').setMaxLength(2000),
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('ephemeral').setLabel('Ephemeral? (yes/no)').setStyle(TextInputStyle.Short).setRequired(false).setValue(r.ephemeral ? 'yes' : 'no').setMaxLength(3),
        ),
      );
      return interaction.showModal(modal);
    }
    case 'embedm': {
      const [kind, commandKey] = payload.split(':');
      const cc = await settings.getCommandConfig(interaction.guildId, moduleKey, commandKey);
      const e = cc.responses?.[kind]?.embed || {};
      const { ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
      const modal = new ModalBuilder().setCustomId(dashCid(moduleKey, 'embed', `${kind}:${commandKey}`)).setTitle(`/${commandKey} — embed studio`);
      modal.addComponents(
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('title').setLabel('Title').setStyle(TextInputStyle.Short).setRequired(false).setValue(e.title || '').setMaxLength(250)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('description').setLabel('Description ({variables} allowed)').setStyle(TextInputStyle.Paragraph).setRequired(false).setValue(e.description || '').setMaxLength(4000)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('color').setLabel('Hex color (e.g. 5865F2)').setStyle(TextInputStyle.Short).setRequired(false).setValue(typeof e.color === 'number' ? e.color.toString(16) : e.color || '').setMaxLength(7)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('footer').setLabel('Footer text').setStyle(TextInputStyle.Short).setRequired(false).setValue(e.footer?.text || '').setMaxLength(250)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('image').setLabel('Image URL').setStyle(TextInputStyle.Short).setRequired(false).setValue(e.image?.url || '').setMaxLength(500)),
      );
      return interaction.showModal(modal);
    }
    case 'embedclear': {
      const [kind, commandKey] = payload.split(':');
      const cc = await settings.getCommandConfig(interaction.guildId, moduleKey, commandKey);
      const before = { ...cc };
      const patch = { responses: { [kind]: { ...(cc.responses?.[kind] || {}), embed: null } } };
      const next = await settings.setCommandConfig(interaction.guildId, moduleKey, commandKey, patch);
      await audit.log(interaction.guildId, interaction.user.id, 'config.command.embed.clear', `command:${moduleKey}:${commandKey}`, before, next);
      return edit(interaction, await commandEditorView(ctx, moduleKey, commandKey));
    }
    case 'perms':
      return edit(interaction, await permissionsView(ctx, moduleKey, payload));
    case 'sel': {
      const [what, commandKey] = payload.split(':');
      const cc = await settings.getCommandConfig(interaction.guildId, moduleKey, commandKey);
      const before = { ...cc };
      const next = await settings.setCommandConfig(interaction.guildId, moduleKey, commandKey, { [what]: interaction.values || [] });
      await audit.log(interaction.guildId, interaction.user.id, 'config.command.permissions', `command:${moduleKey}:${commandKey}`, before, next);
      return edit(interaction, await permissionsView(ctx, moduleKey, commandKey));
    }
    case 'advanced':
      return edit(interaction, await advancedView(ctx, moduleKey));
    case 'advset': {
      const def = ctx.registry.getModule(moduleKey);
      const schemaEntry = (def.settingsSchema || []).find((s) => s.key === payload);
      if (!schemaEntry) return;
      const { ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
      const modal = new ModalBuilder().setCustomId(dashCid(moduleKey, 'adv', payload)).setTitle(`Set ${schemaEntry.label}`.slice(0, 45));
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('value')
            .setLabel(schemaEntry.label.slice(0, 45))
            .setStyle(schemaEntry.type === 'textarea' ? TextInputStyle.Paragraph : TextInputStyle.Short)
            .setRequired(false)
            .setValue(String(modCfg.settings[payload] ?? '')),
        ),
      );
      return interaction.showModal(modal);
    }
    case 'advbool': {
      const before = { enabled: modCfg.enabled, settings: modCfg.settings };
      const next = await settings.setModuleSetting(interaction.guildId, moduleKey, payload, !modCfg.settings[payload]);
      await audit.log(interaction.guildId, interaction.user.id, 'config.module.setting', `module:${moduleKey}`, before, next);
      return edit(interaction, await advancedView(ctx, moduleKey));
    }
    case 'chsel': {
      const value = interaction.values?.[0] ?? null;
      const before = { enabled: modCfg.enabled, settings: modCfg.settings };
      const next = await settings.setModuleSetting(interaction.guildId, moduleKey, payload, value);
      await audit.log(interaction.guildId, interaction.user.id, 'config.module.setting', `module:${moduleKey}`, before, next);
      return edit(interaction, await advancedView(ctx, moduleKey));
    }
    case 'hist':
      return edit(interaction, await historyView(ctx, moduleKey, parseInt(payload || '0', 10) || 0));
    case 'revertsel': {
      const id = parseInt(interaction.values?.[0] || '0', 10);
      const entry = (await audit.recent(interaction.guildId, 50)).find((e) => e.id === id);
      if (!entry) return responses.replyError(interaction, 'That history entry no longer exists.');
      const result = await audit.revert(interaction.guildId, entry);
      if (!result.ok) return responses.replyError(interaction, result.reason);
      await audit.log(interaction.guildId, interaction.user.id, 'config.revert', entry.target, entry.afterJson ? settings.parse(entry.afterJson) : null, entry.beforeJson ? settings.parse(entry.beforeJson) : null);
      return responses.replySimple(interaction, `✅ Reverted \`${entry.target}\` to its previous state.`, { ephemeral: true });
    }
    default:
      if (action === 'x') {
        // customId shape: dash:<moduleKey>:x:<xAction>[:<xPayload>]
        const [xAction, ...restParts] = payload.split(':');
        const def = ctx.registry.getModule(moduleKey);
        if (def?.dashboard?.handle) {
          return def.dashboard.handle({ interaction, ctx, action: xAction, payload: restParts.join(':'), modCfg, helpers: { edit, overviewView: () => overviewView(ctx, moduleKey), commandEditorView: (k) => commandEditorView(ctx, moduleKey, k), btn, cid } });
        }
      }
      return responses.replyError(interaction, 'Unknown dashboard action.');
  }
}

/** Route a dashm:* modal submit. */
async function handleModal(interaction, ctx) {
  const [, moduleKey, action, ...rest] = interaction.customId.split(':');
  const payload = rest.join(':');
  const modCfg = await guard(interaction, moduleKey);
  if (!modCfg) return;
  ctx.currentGuildId = interaction.guildId;

  const field = (id) => interaction.fields?.getTextInputValue(id) ?? '';

  switch (action) {
    case 'cooldown': {
      const seconds = Math.max(0, Math.min(3600, parseInt(field('seconds'), 10) || 0));
      const cc = await settings.getCommandConfig(interaction.guildId, moduleKey, payload);
      const before = { ...cc };
      const next = await settings.setCommandConfig(interaction.guildId, moduleKey, payload, { cooldown: seconds });
      await audit.log(interaction.guildId, interaction.user.id, 'config.command.cooldown', `command:${moduleKey}:${payload}`, before, next);
      return edit(interaction, await commandEditorView(ctx, moduleKey, payload));
    }
    case 'resp': {
      const [kind, commandKey] = payload.split(':');
      const cc = await settings.getCommandConfig(interaction.guildId, moduleKey, commandKey);
      const before = { ...cc };
      const text = field('text');
      const ephemeral = /^(yes|true|on|1)$/i.test(field('ephemeral').trim());
      const patch = { responses: { [kind]: { ...(cc.responses?.[kind] || {}), text, ephemeral } } };
      const next = await settings.setCommandConfig(interaction.guildId, moduleKey, commandKey, patch);
      await audit.log(interaction.guildId, interaction.user.id, 'config.command.response', `command:${moduleKey}:${commandKey}`, before, next);
      return edit(interaction, await commandEditorView(ctx, moduleKey, commandKey));
    }
    case 'embed': {
      const [kind, commandKey] = payload.split(':');
      const embedCfg = {
        enabled: true,
        title: field('title') || undefined,
        description: field('description') || undefined,
        color: field('color') || undefined,
        footer: field('footer') ? { text: field('footer') } : undefined,
        image: field('image') ? { url: field('image') } : undefined,
      };
      const errors = require('./embeds').validateEmbedCfg(embedCfg);
      if (errors.length) return responses.replyError(interaction, `Embed validation failed:\n• ${errors.join('\n• ')}`);
      const cc = await settings.getCommandConfig(interaction.guildId, moduleKey, commandKey);
      const before = { ...cc };
      const patch = { responses: { [kind]: { ...(cc.responses?.[kind] || {}), embed: embedCfg } } };
      const next = await settings.setCommandConfig(interaction.guildId, moduleKey, commandKey, patch);
      await audit.log(interaction.guildId, interaction.user.id, 'config.command.embed', `command:${moduleKey}:${commandKey}`, before, next);
      return edit(interaction, await commandEditorView(ctx, moduleKey, commandKey));
    }
    case 'adv': {
      const def = ctx.registry.getModule(moduleKey);
      const entry = (def.settingsSchema || []).find((s) => s.key === payload);
      if (!entry) return;
      let value = field('value');
      if (entry.type === 'number') value = parseInt(value, 10) || 0;
      const before = { enabled: modCfg.enabled, settings: modCfg.settings };
      const next = await settings.setModuleSetting(interaction.guildId, moduleKey, payload, value);
      await audit.log(interaction.guildId, interaction.user.id, 'config.module.setting', `module:${moduleKey}`, before, next);
      return edit(interaction, await advancedView(ctx, moduleKey));
    }
    default:
      if (action === 'x') {
        const [xAction, ...restParts] = payload.split(':');
        const def = ctx.registry.getModule(moduleKey);
        if (def?.dashboard?.handleModal) {
          return def.dashboard.handleModal({ interaction, ctx, action: xAction, payload: restParts.join(':'), modCfg, helpers: { edit, btn, cid } });
        }
      }
      return responses.replyError(interaction, 'Unknown dashboard form.');
  }
}

module.exports = {
  open,
  routeComponent,
  handleModal,
  overviewView,
  commandsView,
  commandEditorView,
  permissionsView,
  advancedView,
  historyView,
  edit,
  btn,
  cid,
  dashCid,
  trunc,
  listMentions,
  PERMS,
};
