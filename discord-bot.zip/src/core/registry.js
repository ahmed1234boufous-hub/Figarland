'use strict';

/**
 * registry.js — module & command registry.
 *
 * A module definition looks like:
 * {
 *   key: 'moderation',
 *   name: 'Moderation',
 *   emoji: '🛡️',
 *   dashboardCommandName: 'moderation-dashboard',
 *   defaults: { enabled: true, settings: {...} },
 *   commands: [ { name, description, options?, requiredPerms?, cooldown?, defaults?, run } ],
 *   dashboard: { summaryLines?, extraOverviewButtons?, extraCommandButtons?, handle? },
 *   componentHandlers: { 'gw:': fn },
 *   modalHandlers:      { 'gwm:': fn },
 *   hooks: { messageCreate: fn, guildMemberAdd: fn, ... },
 *   schedulerJobs: [ { name, intervalMs, run } ],
 * }
 */

const modules = new Map(); // moduleKey → module def
const commandsByName = new Map(); // slash command name → { moduleKey, ...cmd }
const componentHandlers = []; // [{ prefix, moduleKey, handler }]
const modalHandlers = []; // [{ prefix, moduleKey, handler }]

function registerModule(def) {
  if (modules.has(def.key)) throw new Error(`Module "${def.key}" registered twice`);
  def.commands = def.commands || [];
  for (const cmd of def.commands) {
    cmd.moduleKey = def.key;
    if (commandsByName.has(cmd.name)) {
      throw new Error(`Slash command name collision: /${cmd.name} (${def.key})`);
    }
    commandsByName.set(cmd.name, cmd);
  }
  for (const [prefix, handler] of Object.entries(def.componentHandlers || {})) {
    componentHandlers.push({ prefix, moduleKey: def.key, handler });
  }
  for (const [prefix, handler] of Object.entries(def.modalHandlers || {})) {
    modalHandlers.push({ prefix, moduleKey: def.key, handler });
  }
  modules.set(def.key, def);
  return def;
}

function getModule(key) {
  return modules.get(key);
}

function getModules() {
  return [...modules.values()];
}

function getCommand(moduleKey, commandKey) {
  const mod = modules.get(moduleKey);
  return mod?.commands.find((c) => c.name === commandKey) || null;
}

function getCommandByName(name) {
  return commandsByName.get(name) || null;
}

function findComponentHandler(customId) {
  return componentHandlers.find((h) => customId.startsWith(h.prefix)) || null;
}

function findModalHandler(customId) {
  return modalHandlers.find((h) => customId.startsWith(h.prefix)) || null;
}

/** Invoke a module hook (messageCreate, guildMemberAdd, ...). Never throws. */
async function invokeHook(hookName, ctx, ...args) {
  for (const mod of modules.values()) {
    const fn = mod.hooks?.[hookName];
    if (!fn) continue;
    try {
      // eslint-disable-next no-await-in-loop
      const result = await fn(ctx, ...args);
      if (result === false) return false; // hook may veto further processing
    } catch (err) {
      require('./logger').error(`[hook:${mod.key}.${hookName}]`, err?.message || err);
    }
  }
  return true;
}

module.exports = {
  registerModule,
  getModule,
  getModules,
  getCommand,
  getCommandByName,
  findComponentHandler,
  findModalHandler,
  invokeHook,
};
