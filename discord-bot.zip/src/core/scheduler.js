'use strict';

const logger = require('./logger');

/**
 * scheduler.js — lightweight interval scheduler for background jobs
 * (giveaway ends, poll ends, reminders, ticket auto-close, birthday posts…).
 * Jobs come from module definitions: { name, intervalMs, run(ctx) }.
 */

const jobs = [];

function register(def) {
  if (!def || !def.name || typeof def.run !== 'function') return;
  if (jobs.some((j) => j.name === def.name)) return;
  jobs.push({ ...def, timer: null });
}

function start(ctx) {
  for (const job of jobs) {
    if (job.timer) continue;
    job.timer = setInterval(async () => {
      try {
        await job.run(ctx);
      } catch (err) {
        logger.error(`[job:${job.name}]`, err?.message || err);
      }
    }, job.intervalMs);
    job.timer.unref();
    logger.debug(`[scheduler] started job ${job.name} every ${Math.round(job.intervalMs / 1000)}s`);
  }
  logger.info(`[scheduler] ${jobs.length} background job(s) active`);
}

module.exports = { register, start };
