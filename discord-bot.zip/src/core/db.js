'use strict';

const { PrismaClient } = require('@prisma/client');
const config = require('../config');
const logger = require('./logger');

const prisma = new PrismaClient({
  datasources: { db: { url: config.databaseUrl } },
});

prisma.$on('error', (e) => logger.error('[prisma]', e.message));

module.exports = prisma;
