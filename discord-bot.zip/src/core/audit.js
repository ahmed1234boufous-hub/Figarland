'use strict';

const db = require('./db');
const settings = require('./settings');

/**
 * audit.js — configuration change history powering /dashboard history + revert.
 * target format: "module:<moduleKey>" | "command:<moduleKey>:<commandKey>"
 */

async function log(guildId, actorId, action, target, before, after) {
  try {
    await db.auditLog.create({
      data: {
        guildId,
        actorId: actorId || null,
        action,
        target: target || null,
        beforeJson: before === undefined || before === null ? null : JSON.stringify(before),
        afterJson: after === undefined || after === null ? null : JSON.stringify(after),
      },
    });
  } catch (err) {
    require('./logger').error('[audit]', err?.message || err);
  }
}

async function recent(guildId, limit = 15) {
  return db.auditLog.findMany({
    where: { guildId },
    orderBy: { createdAt: 'desc' },
    take: limit,
  });
}

/** Re-apply the "before" snapshot of an audit entry. */
async function revert(guildId, auditEntry) {
  if (!auditEntry.beforeJson) return { ok: false, reason: 'No previous value recorded for this change.' };
  const before = settings.parse(auditEntry.beforeJson, null);
  if (!before) return { ok: false, reason: 'Previous value could not be parsed.' };

  const parts = (auditEntry.target || '').split(':');
  if (parts[0] === 'module' && parts[1]) {
    await db.moduleConfig.upsert({
      where: { guildId_moduleKey: { guildId, moduleKey: parts[1] } },
      create: { guildId, moduleKey: parts[1], enabled: before.enabled ?? true, settingsJson: settings.stringify(before.settings ?? {}) },
      update: { enabled: before.enabled ?? true, settingsJson: settings.stringify(before.settings ?? {}) },
    });
    return { ok: true };
  }
  if (parts[0] === 'command' && parts[1] && parts[2]) {
    const { _exists, ...clean } = before;
    await db.commandConfig.upsert({
      where: { guildId_moduleKey_commandKey: { guildId, moduleKey: parts[1], commandKey: parts[2] } },
      create: { guildId, moduleKey: parts[1], commandKey: parts[2], enabled: before.enabled ?? true, configJson: settings.stringify(clean) },
      update: { enabled: before.enabled ?? true, configJson: settings.stringify(clean) },
    });
    return { ok: true };
  }
  return { ok: false, reason: 'This entry type cannot be reverted.' };
}

module.exports = { log, recent, revert };
