'use strict';

const { EmbedBuilder } = require('discord.js');
const placeholders = require('./placeholders');
const config = require('../config');

/**
 * embeds.js — Universal Embed Studio engine.
 *
 * An embed configuration ("embed cfg") is a plain JSON object:
 * {
 *   enabled: true,
 *   author:  { name, url, iconURL },
 *   title, url, description,
 *   color: '5865F2' | 5620994,
 *   thumbnail: { url },
 *   image:    { url },
 *   fields:   [ { name, value, inline } ],
 *   footer:   { text, iconURL },
 *   timestamp: true | false
 * }
 * All text fields support dynamic {variables}. Discord's native limits are
 * enforced by validateEmbedCfg(); the dashboard surfaces the errors.
 */

const LIMITS = {
  title: 256,
  description: 4096,
  fieldName: 256,
  fieldValue: 1024,
  fields: 25,
  footer: 2048,
  authorName: 256,
  total: 6000,
};

function normalizeColor(color) {
  if (color === undefined || color === null || color === '') return undefined;
  if (typeof color === 'number') return color;
  const hex = String(color).replace('#', '').trim();
  if (/^[0-9a-fA-F]{6}$/.test(hex)) return parseInt(hex, 16);
  return undefined;
}

function totalLength(cfg) {
  let n = 0;
  n += (cfg.title || '').length;
  n += (cfg.description || '').length;
  n += (cfg.author?.name || '').length;
  n += (cfg.footer?.text || '').length;
  for (const f of cfg.fields || []) n += (f.name || '').length + (f.value || '').length;
  return n;
}

/**
 * Validate an embed cfg against Discord's current limits.
 * @returns {string[]} list of human-readable problems (empty = valid)
 */
function validateEmbedCfg(cfg) {
  const errors = [];
  if (!cfg || typeof cfg !== 'object') return ['Embed configuration is not an object.'];
  if (cfg.title && cfg.title.length > LIMITS.title) errors.push(`Title exceeds ${LIMITS.title} characters.`);
  if (cfg.description && cfg.description.length > LIMITS.description) errors.push(`Description exceeds ${LIMITS.description} characters.`);
  const fields = cfg.fields || [];
  if (fields.length > LIMITS.fields) errors.push(`Embeds support at most ${LIMITS.fields} fields.`);
  for (const [i, f] of fields.entries()) {
    if (!f.name) errors.push(`Field ${i + 1}: name is required.`);
    if (f.name && f.name.length > LIMITS.fieldName) errors.push(`Field ${i + 1}: name exceeds ${LIMITS.fieldName} characters.`);
    if (!f.value) errors.push(`Field ${i + 1}: value is required.`);
    if (f.value && f.value.length > LIMITS.fieldValue) errors.push(`Field ${i + 1}: value exceeds ${LIMITS.fieldValue} characters.`);
  }
  if (cfg.footer?.text && cfg.footer.text.length > LIMITS.footer) errors.push(`Footer exceeds ${LIMITS.footer} characters.`);
  if (cfg.author?.name && cfg.author.name.length > LIMITS.authorName) errors.push(`Author name exceeds ${LIMITS.authorName} characters.`);
  for (const [key, url] of Object.entries({
    'author icon': cfg.author?.iconURL,
    'title URL': cfg.url,
    thumbnail: cfg.thumbnail?.url,
    image: cfg.image?.url,
    'footer icon': cfg.footer?.iconURL,
  })) {
    if (url && !/^https?:\/\//i.test(url)) errors.push(`${key} must be a valid http(s) URL.`);
  }
  if (totalLength(cfg) > LIMITS.total) errors.push(`Total embed text exceeds ${LIMITS.total} characters.`);
  return errors;
}

/**
 * Build a discord.js EmbedBuilder from an embed cfg, filling {variables}.
 * Returns null when the cfg is missing or explicitly disabled.
 */
function buildEmbed(cfg, data = {}, defaults = {}) {
  if (!cfg || cfg.enabled === false) return null;
  const hasAny =
    cfg.author?.name || cfg.title || cfg.description || (cfg.fields || []).length || cfg.footer?.text || cfg.image?.url || cfg.thumbnail?.url;
  if (!hasAny) return null;

  const embed = new EmbedBuilder();
  const color = normalizeColor(cfg.color) ?? defaults.color ?? config.embedColor;

  if (cfg.author?.name) {
    embed.setAuthor({
      name: placeholders.fill(cfg.author.name, data).slice(0, LIMITS.authorName),
      ...(cfg.author.url ? { url: cfg.author.url } : {}),
      ...(cfg.author.iconURL ? { iconURL: cfg.author.iconURL } : {}),
    });
  }
  if (cfg.title) embed.setTitle(placeholders.fill(cfg.title, data).slice(0, LIMITS.title));
  if (cfg.url && /^https?:\/\//i.test(cfg.url)) embed.setURL(cfg.url);
  if (cfg.description) embed.setDescription(placeholders.fill(cfg.description, data).slice(0, LIMITS.description));
  embed.setColor(color);
  if (cfg.thumbnail?.url && /^https?:\/\//i.test(cfg.thumbnail.url)) embed.setThumbnail(cfg.thumbnail.url);
  if (cfg.image?.url && /^https?:\/\//i.test(cfg.image.url)) embed.setImage(cfg.image.url);
  if ((cfg.fields || []).length) {
    embed.addFields(
      cfg.fields.slice(0, LIMITS.fields).map((f) => ({
        name: placeholders.fill(f.name || '\u200b', data).slice(0, LIMITS.fieldName) || '\u200b',
        value: placeholders.fill(f.value || '\u200b', data).slice(0, LIMITS.fieldValue) || '\u200b',
        inline: Boolean(f.inline),
      })),
    );
  }
  if (cfg.footer?.text) {
    embed.setFooter({
      text: placeholders.fill(cfg.footer.text, data).slice(0, LIMITS.footer),
      ...(cfg.footer.iconURL ? { iconURL: cfg.footer.iconURL } : {}),
    });
  } else if (defaults.footerText) {
    embed.setFooter({ text: placeholders.fill(defaults.footerText, data).slice(0, LIMITS.footer) });
  }
  if (cfg.timestamp) embed.setTimestamp(new Date());
  return embed;
}

/** Build several embeds from an array of cfgs (multi-embed messages). */
function buildEmbeds(cfgs, data, defaults) {
  return (cfgs || []).map((c) => buildEmbed(c, data, defaults)).filter(Boolean);
}

module.exports = { buildEmbed, buildEmbeds, validateEmbedCfg, normalizeColor, LIMITS };
