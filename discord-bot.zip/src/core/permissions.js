'use strict';

const { PermissionFlagsBits } = require('discord.js');

function memberHas(member, permName) {
  if (!member || !member.permissions) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  const flag = PermissionFlagsBits[permName];
  return flag ? member.permissions.has(flag) : false;
}

function highestRolePosition(member) {
  if (!member) return -1;
  return member.roles?.highest?.position ?? -1;
}

/**
 * Executor must outrank the target (and target must not be the owner).
 * Administrators / owner always pass the outrank check.
 */
function checkTargetHierarchy(interaction, targetMember) {
  const guild = interaction.guild;
  if (!targetMember) return { ok: true };
  if (targetMember.id === guild.ownerId) {
    const isOwner = interaction.user.id === guild.ownerId;
    return isOwner ? { ok: true } : { ok: false, reason: 'The server owner cannot be targeted.' };
  }
  const executor = interaction.member;
  if (executor.id === guild.ownerId) return { ok: true };
  if (executor.permissions?.has(PermissionFlagsBits.Administrator) && highestRolePosition(executor) > highestRolePosition(targetMember)) {
    return { ok: true };
  }
  if (highestRolePosition(executor) <= highestRolePosition(targetMember)) {
    return { ok: false, reason: 'Your highest role must be **above** the target’s highest role.' };
  }
  return { ok: true };
}

/** Bot must be able to act on the target and have the required permissions. */
function checkBotHierarchy(guild, targetMember) {
  if (!targetMember) return { ok: true };
  const me = guild.members.me;
  if (targetMember.id === guild.ownerId) return { ok: false, reason: 'I cannot act on the server owner.' };
  if (highestRolePosition(me) <= highestRolePosition(targetMember)) {
    return { ok: false, reason: 'My highest role must be **above** the target’s highest role.' };
  }
  return { ok: true };
}

function botHas(guild, ...permNames) {
  const me = guild?.members?.me;
  if (!me) return false;
  if (me.permissions.has(PermissionFlagsBits.Administrator)) return true;
  return permNames.every((p) => {
    const flag = PermissionFlagsBits[p];
    return flag ? me.permissions.has(flag) : false;
  });
}

/**
 * Full access check for a slash command against its per-command config.
 * Order: disabled → channel blocks → channel allows → role blocks → role allows → required perms.
 */
function checkCommandAccess(interaction, cmdDef, cmdCfg) {
  const guild = interaction.guild;
  const channel = interaction.channel;
  const member = interaction.member;

  if (cmdCfg.enabled === false) return { ok: false, reason: 'This command is currently **disabled** in this server.' };

  if (guild && channel) {
    if (cmdCfg.blockedChannels?.includes(channel.id)) return { ok: false, reason: 'This command cannot be used in this channel.' };
    if (cmdCfg.allowedChannels?.length && !cmdCfg.allowedChannels.includes(channel.id)) {
      return { ok: false, reason: 'This command is restricted to specific channels.' };
    }
  }

  const roleIds = member?.roles?.cache ? [...member.roles.cache.keys()] : [];
  if (cmdCfg.blockedRoles?.length && cmdCfg.blockedRoles.some((r) => roleIds.includes(r))) {
    return { ok: false, reason: 'You are not allowed to use this command.' };
  }
  const hasAllowedRole = cmdCfg.allowedRoles?.length && cmdCfg.allowedRoles.some((r) => roleIds.includes(r));
  const isAdmin = member?.permissions?.has(PermissionFlagsBits.Administrator);
  if (cmdCfg.allowedRoles?.length && !hasAllowedRole && !isAdmin) {
    return { ok: false, reason: 'You need one of the allowed roles to use this command.' };
  }

  if (cmdDef.requiredPerms?.length) {
    const missing = cmdDef.requiredPerms.filter((p) => !memberHas(member, p));
    if (missing.length) return { ok: false, reason: `You need the **${missing.join(', ')}** permission for this command.` };
  }
  return { ok: true };
}

/** Dashboard access: administrators or roles listed in module settings.dashboardRoles. */
function canUseDashboard(member, moduleCfg) {
  if (!member || !member.permissions) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  const roles = moduleCfg?.settings?.dashboardRoles || [];
  return member.roles.cache.some((r) => roles.includes(r.id));
}

module.exports = {
  memberHas,
  highestRolePosition,
  checkTargetHierarchy,
  checkBotHierarchy,
  botHas,
  checkCommandAccess,
  canUseDashboard,
};
