'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  RoleSelectMenuBuilder,
  PermissionFlagsBits,
  MessageFlags,
} = require('discord.js');
const settings = require('./settings');
const permissions = require('./permissions');
const responses = require('./responses');
const dashboards = require('./dashboards');
const audit = require('./audit');
const placeholders = require('./placeholders');
const embeds = require('./embeds');
const db = require('./db');
const config = require('../config');

/**
 * globalDashboard.js — the cross-module /dashboard command (spec §2).
 * It does NOT replace module dashboards: detailed editing stays inside
 * /<module>-dashboard. Subcommands: module, command, embeds, images,
 * permissions, variables, backup, restore, history, search.
 */

const stagedRestores = new Map(); // `${guildId}:${userId}` → payload

function moduleChoices() {
  return require('./registry')
    .getModules()
    .filter((m) => m.key !== 'core')
    .map((m) => ({ name: `${m.name}`, value: m.key }));
}

function indexView() {
  const mods = require('./registry').getModules().filter((m) => m.key !== 'core');
  const embed = new EmbedBuilder()
    .setTitle('🏠 Bot Dashboard — index')
    .setColor(config.embedColor)
    .setDescription(
      'Every module has its own dedicated dashboard with per-command editors, embeds, permissions and advanced settings.\n\n' +
        mods.map((m) => `${m.emoji || '•'} **${m.name}** — \`/${m.dashboardCommandName}\``).join('\n') +
        '\n\nSelect a module below, or use the subcommands: `module` `command` `embeds` `permissions` `variables` `backup` `restore` `history` `search`.',
    )
    .setFooter({ text: 'Configuration is stored per server • changes are audited' });

  const row = new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('dashg:modsel')
      .setPlaceholder('Open a module dashboard…')
      .addOptions(mods.slice(0, 25).map((m) => ({ label: m.name.slice(0, 100), description: `/${m.dashboardCommandName}`.slice(0, 100), value: m.key, emoji: m.emoji || undefined }))),
  );
  return { embeds: [embed], components: [row], flags: MessageFlags.Ephemeral };
}

const commands = [
  {
    name: 'dashboard',
    description: 'Open the main dashboard index and cross-module administration.',
    requiredPerms: ['ManageGuild'],
    cooldown: 3,
    options: [
      {
        name: 'home',
        description: 'Open the main dashboard index',
        type: 1,
        options: [],
      },
      { name: 'module', description: 'Open a selected module dashboard', type: 1, options: [{ name: 'name', description: 'Module', type: 3, required: true, choices: moduleChoices() }] },
      {
        name: 'command',
        description: 'Search for and open a command configuration page',
        type: 1,
        options: [
          { name: 'name', description: 'Module', type: 3, required: true, choices: moduleChoices() },
          { name: 'command', description: 'Command name (without slash)', type: 3, required: true },
        ],
      },
      {
        name: 'embeds',
        description: 'Browse embed configurations across modules',
        type: 1,
        options: [{ name: 'name', description: 'Module', type: 3, required: true, choices: moduleChoices() }],
      },
      { name: 'images', description: 'Image assets and templates (engine not installed in this build)', type: 1 },
      { name: 'permissions', description: 'Global permissions overview and dashboard access roles', type: 1 },
      { name: 'variables', description: 'View supported dynamic placeholders', type: 1 },
      { name: 'backup', description: 'Export this server’s bot configuration as JSON', type: 1 },
      {
        name: 'restore',
        description: 'Restore a previously exported configuration (attach the JSON backup)',
        type: 1,
        options: [{ name: 'file', description: 'The .json backup produced by /dashboard backup', type: 11, required: true }],
      },
      { name: 'history', description: 'Review configuration changes and revert them', type: 1 },
      { name: 'search', description: 'Search settings, commands and configuration values', type: 1, options: [{ name: 'query', description: 'Text to search for', type: 3, required: true }] },
    ],
    async run(ctx, interaction, cmdCfg) {
      const sub = interaction.options.getSubcommand(false);
      if (!sub || sub === 'home') return interaction.reply(indexView());

      if (sub === 'module') {
        const key = interaction.options.getString('name', true);
        const modCfg = await settings.getModuleConfig(interaction.guildId, key);
        if (!permissions.canUseDashboard(interaction.member, modCfg)) return responses.replyError(interaction, 'You do not have permission for that module dashboard.');
        ctx.currentGuildId = interaction.guildId;
        return interaction.reply(await dashboards.overviewView(ctx, key));
      }

      if (sub === 'command') {
        const key = interaction.options.getString('name', true);
        const commandName = interaction.options.getString('command', true).replace(/^\//, '');
        const modCfg = await settings.getModuleConfig(interaction.guildId, key);
        if (!permissions.canUseDashboard(interaction.member, modCfg)) return responses.replyError(interaction, 'You do not have permission for that module dashboard.');
        ctx.currentGuildId = interaction.guildId;
        const def = ctx.registry.getModule(key);
        if (!def) return responses.replyError(interaction, 'Unknown module.');
        if (commandName && def.commands.some((c) => c.name === commandName)) return interaction.reply(await dashboards.commandEditorView(ctx, key, commandName));
        return interaction.reply(await dashboards.commandsView(ctx, key, 0));
      }

      if (sub === 'embeds') {
        const key = interaction.options.getString('name', true);
        const modCfg = await settings.getModuleConfig(interaction.guildId, key);
        if (!permissions.canUseDashboard(interaction.member, modCfg)) return responses.replyError(interaction, 'You do not have permission for that module dashboard.');
        const def = ctx.registry.getModule(key);
        const withEmbeds = [];
        for (const cmd of def.commands) {
          // eslint-disable-next-line no-await-in-loop
          const cc = await settings.getCommandConfig(interaction.guildId, key, cmd.name);
          for (const [kind, r] of Object.entries(cc.responses || {})) {
            if (r?.embed) withEmbeds.push({ cmd: cmd.name, kind });
          }
        }
        const embed = new EmbedBuilder()
          .setTitle(`🎨 Embed configurations — ${def.name}`)
          .setColor(config.embedColor)
          .setDescription(withEmbeds.length ? 'Select one to preview. Editing stays inside the module dashboard (Commands → Embed studio).' : 'No custom embeds configured in this module yet.\nOpen the module dashboard → select a command → **Embed studio**.')
          .setFooter({ text: `${withEmbeds.length} custom embed(s)` });
        const components = [];
        if (withEmbeds.length) {
          components.push(
            new ActionRowBuilder().addComponents(
              new StringSelectMenuBuilder()
                .setCustomId(`dashg:embedsel:${key}`)
                .setPlaceholder('Preview an embed…')
                .addOptions(withEmbeds.slice(0, 25).map((e) => ({ label: `/${e.cmd} — ${e.kind}`.slice(0, 100), value: `${e.cmd}:${e.kind}` }))),
            ),
          );
        }
        return interaction.reply({ embeds: [embed], components, flags: MessageFlags.Ephemeral });
      }

      if (sub === 'images') {
        return responses.replySimple(
          interaction,
          '🖼️ **Images & assets**\nThe dynamic image engine (welcome cards, rank cards, asset library) is not installed in this build. Text + embed pipelines are fully active; the rendering hook is isolated so @napi-rs/canvas can be added later (see README → “Adding the image engine”).',
          { ephemeral: true },
        );
      }

      if (sub === 'permissions') {
        const coreCfg = await settings.getModuleConfig(interaction.guildId, 'core');
        const roles = coreCfg.settings.dashboardRoles || [];
        const embed = new EmbedBuilder()
          .setTitle('🔐 Global permissions overview')
          .setColor(config.embedColor)
          .setDescription(
            '**Dashboard access:** Administrators ' + (roles.length ? `+ ${roles.map((r) => `<@&${r}>`).join(' ')}` : '') + '\n\n' +
              'Per-command permissions (allowed/blocked roles, channel limits, required Discord permissions) are configured inside each module dashboard:\n' +
              ctx.registry.getModules().filter((m) => m.key !== 'core').map((m) => `${m.emoji || '•'} \`/${m.dashboardCommandName}\` → Commands → Permissions`).join('\n'),
          );
        const row = new ActionRowBuilder().addComponents(
          new RoleSelectMenuBuilder().setCustomId('dashg:dashroles').setPlaceholder('Additional dashboard access roles…').setMinValues(0).setMaxValues(10),
        );
        return interaction.reply({ embeds: [embed], components: [row], flags: MessageFlags.Ephemeral });
      }

      if (sub === 'variables') {
        const embed = new EmbedBuilder()
          .setTitle('🧬 Dynamic variables')
          .setColor(config.embedColor)
          .setDescription(placeholders.documentation().map(([k, v]) => `\`${k}\` — ${v}`).join('\n'))
          .setFooter({ text: 'Variables work in response templates, welcome/leveling texts and embed studio fields' });
        return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
      }

      if (sub === 'backup') {
        const [modules, commands_] = await Promise.all([
          db.moduleConfig.findMany({ where: { guildId: interaction.guildId } }),
          db.commandConfig.findMany({ where: { guildId: interaction.guildId } }),
        ]);
        const payload = {
          _type: 'modular-discord-bot-backup',
          _version: 1,
          _exportedAt: new Date().toISOString(),
          guildId: interaction.guildId,
          moduleConfigs: modules,
          commandConfigs: commands_,
        };
        const file = { attachment: Buffer.from(JSON.stringify(payload, null, 2), 'utf8'), name: `dashboard-backup-${interaction.guildId}.json` };
        return interaction.reply({
          content: `💾 Backup ready — **${modules.length}** module config(s), **${commands_.length}** command config(s). Store this file safely; it contains no secrets or member data.`,
          files: [file],
          flags: MessageFlags.Ephemeral,
        });
      }

      if (sub === 'restore') {
        const attachment = interaction.options.getAttachment('file', true);
        if (!attachment.name.endsWith('.json')) return responses.replyError(interaction, 'The backup must be a .json file produced by `/dashboard backup`.');
        const res = await fetch(attachment.url).then((r) => r.text()).catch(() => null);
        if (!res) return responses.replyError(interaction, 'I could not download that file.');
        let payload;
        try {
          payload = JSON.parse(res);
        } catch {
          return responses.replyError(interaction, 'That file is not valid JSON.');
        }
        if (payload._type !== 'modular-discord-bot-backup' || !Array.isArray(payload.moduleConfigs) || !Array.isArray(payload.commandConfigs)) {
          return responses.replyError(interaction, 'That file is not a valid bot configuration backup.');
        }
        const token = `${interaction.guildId}:${interaction.user.id}`;
        stagedRestores.set(token, payload);
        setTimeout(() => stagedRestores.delete(token), 5 * 60 * 1000).unref();
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`dashg:restoreconfirm:${token}`).setLabel('Yes — restore configuration').setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId(`dashg:restorecancel:${token}`).setLabel('Cancel').setStyle(ButtonStyle.Secondary),
        );
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setTitle('⚠️ Confirm configuration restore')
              .setColor(config.warnColor)
              .setDescription(
                `This will overwrite this server’s bot configuration with the backup:\n• **${payload.moduleConfigs.length}** module configs\n• **${payload.commandConfigs.length}** command configs\n\nThe current state is recorded in the audit history and can be compared via \`/dashboard history\`.`,
              ),
          ],
          components: [row],
          flags: MessageFlags.Ephemeral,
        });
      }

      if (sub === 'history') {
        ctx.currentGuildId = interaction.guildId;
        return interaction.reply(await dashboards.historyView(ctx, 'core', 0));
      }

      if (sub === 'search') {
        const query = interaction.options.getString('query', true).toLowerCase();
        const [modules, commandConfigs] = await Promise.all([
          db.moduleConfig.findMany({ where: { guildId: interaction.guildId } }),
          db.commandConfig.findMany({ where: { guildId: interaction.guildId } }),
        ]);
        const hits = [];
        for (const m of modules) {
          if (m.moduleKey.includes(query) || (m.settingsJson || '').toLowerCase().includes(query)) hits.push(`📦 module \`${m.moduleKey}\``);
        }
        for (const c of commandConfigs) {
          if (c.commandKey.includes(query) || (c.configJson || '').toLowerCase().includes(query)) hits.push(`⚙️ command \`/${c.commandKey}\` (${c.moduleKey}) — ${c.enabled ? 'ON' : 'OFF'}`);
        }
        const embed = new EmbedBuilder()
          .setTitle(`🔎 Search: “${query}”`)
          .setColor(config.embedColor)
          .setDescription(hits.slice(0, 25).join('\n') || 'No matches found in this server’s configuration.')
          .setFooter({ text: `${hits.length} match(es)` });
        return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
      }
    },
  },
];

async function handleComponent(ctx, interaction, rest) {
  const [action, ...payloadParts] = rest.split(':');
  const payload = payloadParts.join(':');

  if (action === 'modsel') {
    const key = interaction.values?.[0];
    const modCfg = await settings.getModuleConfig(interaction.guildId, key);
    if (!permissions.canUseDashboard(interaction.member, modCfg)) return responses.replyError(interaction, 'You do not have permission for that module dashboard.');
    ctx.currentGuildId = interaction.guildId;
    return dashboards.edit(interaction, await dashboards.overviewView(ctx, key));
  }
  if (action === 'embedsel') {
    const [moduleKey, commandKey, kind] = payload.split(':');
    const modCfg = await settings.getModuleConfig(interaction.guildId, moduleKey);
    if (!permissions.canUseDashboard(interaction.member, modCfg)) return responses.replyError(interaction, 'No permission.');
    const cc = await settings.getCommandConfig(interaction.guildId, moduleKey, commandKey);
    const built = embeds.buildEmbed(cc.responses?.[kind]?.embed, {
      user: interaction.user,
      member: interaction.member,
      guild: interaction.guild,
      extra: { sample: 'sample' },
    });
    return interaction.reply({
      embeds: built ? [built] : [{ color: config.embedColor, description: 'That embed config is empty.' }],
      flags: MessageFlags.Ephemeral,
    });
  }
  if (action === 'dashroles') {
    const coreCfg = await settings.getModuleConfig(interaction.guildId, 'core');
    const before = { enabled: coreCfg.enabled, settings: coreCfg.settings };
    const next = await settings.setModuleSetting(interaction.guildId, 'core', 'dashboardRoles', interaction.values || []);
    await audit.log(interaction.guildId, interaction.user.id, 'config.dashboard.roles', 'module:core', before, next);
    return dashboards.edit(interaction, {
      embeds: [
        new EmbedBuilder()
          .setTitle('🔐 Dashboard access updated')
          .setColor(config.successColor)
          .setDescription(`Administrators ${(interaction.values || []).length ? `+ ${interaction.values.map((r) => `<@&${r}>`).join(' ')}` : 'only'} can open module dashboards.`),
      ],
      components: [],
      flags: MessageFlags.Ephemeral,
    });
  }
  if (action === 'restoreconfirm') {
    const backup = stagedRestores.get(payload);
    if (!backup) return responses.replyError(interaction, 'The staged restore expired — run `/dashboard restore` again.');
    stagedRestores.delete(payload);
    let applied = 0;
    for (const m of backup.moduleConfigs || []) {
      // eslint-disable-next-line no-await-in-loop
      await db.moduleConfig.upsert({
        where: { guildId_moduleKey: { guildId: interaction.guildId, moduleKey: m.moduleKey } },
        create: { guildId: interaction.guildId, moduleKey: m.moduleKey, enabled: m.enabled ?? true, settingsJson: m.settingsJson || '{}' },
        update: { enabled: m.enabled ?? true, settingsJson: m.settingsJson || '{}' },
      });
      applied += 1;
    }
    for (const c of backup.commandConfigs || []) {
      // eslint-disable-next-line no-await-in-loop
      await db.commandConfig.upsert({
        where: { guildId_moduleKey_commandKey: { guildId: interaction.guildId, moduleKey: c.moduleKey, commandKey: c.commandKey } },
        create: { guildId: interaction.guildId, moduleKey: c.moduleKey, commandKey: c.commandKey, enabled: c.enabled ?? true, configJson: c.configJson || '{}' },
        update: { enabled: c.enabled ?? true, configJson: c.configJson || '{}' },
      });
      applied += 1;
    }
    await audit.log(interaction.guildId, interaction.user.id, 'config.restore', 'guild', null, { applied });
    return responses.replySimple(interaction, `✅ Restored **${applied}** configuration record(s).`, { ephemeral: true });
  }
  if (action === 'restorecancel') {
    stagedRestores.delete(payload);
    return responses.replySimple(interaction, 'Restore cancelled.', { ephemeral: true });
  }
}

module.exports = {
  key: 'core',
  name: 'Dashboard',
  emoji: '🏠',
  defaults: { enabled: true, settings: { dashboardRoles: [] }, commands: {} },
  settingsSchema: [
    { key: 'dashboardRoles', label: 'Dashboard access roles', type: 'roles', desc: 'Roles (besides administrators) allowed to open dashboards.' },
  ],
  commands,
  componentHandlers: { 'dashg:': handleComponent },
};
