'use strict';

const { PermissionFlagsBits } = require('discord.js');

/**
 * commandPayload.js — single source of truth for the bot's global slash
 * command payloads. Consumed by:
 *   - scripts/deploy-commands.js (optional manual deploy from a terminal)
 *   - src/events/ready.js       (automatic registration on every boot)
 *
 * The ready-event registration means browser-only hosts (Railway via GitHub
 * drag & drop) never need `npm run deploy` — commands exist as soon as the
 * process starts.
 */

function buildPayload(cmd) {
  const payload = {
    name: cmd.name,
    description: cmd.description.slice(0, 100),
    options: cmd.options || [],
    dm_permission: false,
  };
  if (cmd.requiredPerms?.length) {
    const flag = PermissionFlagsBits[cmd.requiredPerms[0]];
    if (flag !== undefined) payload.default_member_permissions = flag.toString();
  }
  return payload;
}

function buildGlobalPayloads(registry) {
  const all = [];
  // Module commands
  for (const mod of registry.getModules()) {
    if (mod.key === 'core') continue;
    for (const cmd of mod.commands) all.push(buildPayload(cmd));
  }
  // Global /dashboard (from the core pseudo-module)
  const core = registry.getModule('core');
  if (core) for (const cmd of core.commands) all.push(buildPayload(cmd));
  return all;
}

module.exports = { buildPayload, buildGlobalPayloads };
