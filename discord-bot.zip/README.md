# Modular Discord Bot

A modular, highly configurable Discord bot with **a dedicated dashboard for every module**, **per-command customization** (permissions, cooldowns, response templates, embeds), a **universal embed studio**, dynamic placeholders, audit history with revert, and configuration backup/restore — everything manageable from inside Discord.

Built with **discord.js v14**, **Node.js (CommonJS)** and **Prisma** (SQLite by default, PostgreSQL auto-detected). 14 modules, ~80 slash commands, plus 14 per-guild `/…-dashboard` commands.

**No terminal?** You can deploy the whole bot from your browser only — the bot registers its own slash commands and creates its own database on startup. See §2, Path A.

---

## 1. Modules

| Module | Dashboard | Highlights |
| --- | --- | --- |
| 🛡️ Moderation | `/moderation-dashboard` | ban, softban, unban, kick, timeout/untimeout, warn, warnings, clearwarnings, purge (with filters), slowmode, lock/unlock, nick, role, case, cases, modstats — numbered cases, mod-log channel, DM-on-action |
| ☢️ Anti-Nuke & Anti-Raid | `/security-dashboard` | per-event thresholds (channel/role deletes, bans, kicks, webhooks) with actions alert/quarantine/timeout/kick/ban, whitelist, join-spike detection, lockdown, min account age |
| 🤖 Auto Moderation | `/automod-dashboard` | 9 rule types (spam, mention spam, invites, links, caps, blocked words, repeated chars, emoji spam, custom regex), per-rule actions, escalation, exemptions, `/automod test` |
| 👋 Welcome & Goodbye | `/welcome-dashboard` | templates with variables, embed or text style, DM greeting, autoroles, preview/test, disable-without-deleting, reset |
| 🎫 Tickets & Support | `/ticket-dashboard` | multiple panels with intake forms (modal), claim/transfer/priority, transcripts (.txt), log channel, inactivity auto-close, stats |
| 📈 Leveling & XP | `/leveling-dashboard` | message + voice XP, configurable curve/cooldown, level-role rewards (stack or replace), announcements, `/rank` card, `/leaderboard` (xp/economy/rep/invites) |
| 🎉 Giveaways | `/giveaway-dashboard` | entry requirements (role, level, account age), multiple winners, pause/resume, reroll, auto-draw, winner DMs |
| 🎭 Reaction Roles | `/roles-dashboard` | button panels and select-menu panels, toggle behavior, single-choice groups, style/emoji/label per option, hierarchy checks |
| 📜 Logging | `/logging-dashboard` | 10 event categories, shared or per-event channels, themed embeds, ignored channels/roles, `/logs test` |
| 💰 Economy | `/economy-dashboard` | wallet/bank, daily/weekly streaks, work, pay, shop with role rewards and stock, inventory, coinflip/rob/crime (individually disableable), full transaction log |
| 💡 Suggestions & Community | `/suggestion-dashboard` | suggestion workflow (pending/approved/denied/considered), polls with live vote buttons, reputation, starboard |
| 🧰 Utility & Information | `/utility-dashboard` | userinfo, serverinfo, avatar, banner, roleinfo, channelinfo, botinfo, membercount, inviteinfo, ping, AFK, reminders, `/embed`, `/say` |
| ⚡ Custom Commands & Auto Responders | `/customcmd-dashboard` | user-created slash commands (registered per guild, survive restarts), keyword autoresponders (exact/starts-with/contains), event triggers with actions |
| 🎪 Community Extras | `/community-dashboard` | birthdays, invite tracking, counting channel, sticky messages, temporary voice channels, forms, applications, events with RSVP, modmail, tags |
| 🏠 Global | `/dashboard` | index, module/command navigation, embed browser, permissions overview, variables reference, backup/restore, history, search |

> Music is intentionally omitted (the specification marks it optional; audio providers have separate ToS/copyright requirements).

## 2. Quick start

Two ways to run the bot. Both need a Discord *application* first — do that once:

### 2.0 Discord side (browser only, ~5 minutes)

1. Go to <https://discord.com/developers/applications> → **New Application** → give it a name → **Create**.
2. **Bot** tab → **Reset Token** → **Copy** the token → save it somewhere private (**DISCORD_TOKEN**).
3. Same **Bot** tab → scroll to **Privileged Gateway Intents** → enable **Server Members Intent** and **Message Content Intent** → Save.
4. **General Information** tab → copy the **Application ID** (**CLIENT_ID**).

Never share the token. If it leaks, hit **Reset Token** again.

---

### Path A — deploy from your browser, no terminal (GitHub + Railway)

Everything below happens in web pages — no command line anywhere.

**Step 1 — put the code on GitHub (drag & drop)**

1. Unzip `discord-bot.zip` on your computer (double-click, or right-click → Extract — no terminal needed).
2. Create a free GitHub account if you don't have one, then open <https://github.com/new>.
3. Repository name: anything (e.g. `my-discord-bot`), set to **Private** → **Create repository**.
4. On the new empty repo page, click the **uploading an existing file** link.
5. Drag the **contents** of the unzipped `discord-bot` folder into the page — the `src`, `scripts`, `prisma` folders **and** the loose files (`package.json`, `package-lock.json`, `railway.json`, `README.md`, `.env.example`, `.gitignore`, `.nvmrc`). GitHub caps one drop at 100 files and this project has ~98, so if the browser complains, drop in two batches (e.g. first the `src` + `scripts` + `prisma` folders, then the loose files).
6. Click **Commit changes**. Never upload a real `.env` file or your token to GitHub.

> Don't worry about `node_modules` — Railway installs it for you during the build.

**Step 2 — deploy on Railway**

1. Open <https://railway.com> → **Login with GitHub** → authorize (create the free account if needed).
2. **New Project** → **Deploy from GitHub repo** → pick your repo → **Deploy now**. Railway reads the included `railway.json` and knows exactly how to build and start the bot — no configuration.
3. While it builds, add the database: in the same project click **+ New** → **Database** → **Add PostgreSQL**. Railway creates it and injects `DATABASE_URL` into your bot service **automatically** — the bot detects Postgres and switches itself over on the next boot.
4. Add your secrets: click the bot service → **Variables** tab → add:
   - `DISCORD_TOKEN` = the token from §2.0
   - `CLIENT_ID` = the Application ID from §2.0
5. Saving variables triggers a redeploy (or use **Deployments → Redeploy**). Watch the **Logs** — success looks like:

   ```
   [prepare-db] ✅ Database is ready.
   Database connection OK
   Logged in as MyBot#1234 — serving 1 guild(s)
   Registered 79 global slash command(s) — they may take up to a minute to appear everywhere.
   ```

**Step 3 — invite the bot to your server**

Paste this into your browser (replace `YOUR_CLIENT_ID`), choose your server, authorize:

```
https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&scope=bot+applications.commands&permissions=1100484045911
```

Slash commands appear on their own — startup registration means there is no `deploy` step on Railway. Per-guild `/…-dashboard` commands appear the moment the bot joins.

**Costs, honestly:** Railway's trial gives a few dollars of credit (no card needed to try). To keep the bot + its Postgres online 24/7 past the trial you'll need the Hobby plan (~US$5/month, includes usage credit); a bot of this size typically consumes a few dollars per month of usage. Any other Node host works too (§8).

---

### Path B — run it on your own computer (needs a terminal)

Requirements: **Node.js 18+** (20+ recommended), npm.

```bash
unzip discord-bot.zip && cd discord-bot
npm install                 # also generates the Prisma client automatically

# 1. Configure
cp .env.example .env        # then edit .env — see §2.0 + below

# 2. Create the database (SQLite file at prisma/data/bot.db)
npm run setup

# 3. Start — slash commands register automatically on boot
npm start
```

`npm run deploy` is now **optional** (auto-registration covers it); keep it for instant per-guild testing: `npm run deploy -- --guild YOUR_SERVER_ID`.

### `.env`

```ini
DISCORD_TOKEN=…      # Discord Developer Portal → your app → Bot → Reset Token
CLIENT_ID=…          # Developer Portal → General Information → Application ID
DATABASE_URL="file:./data/bot.db"   # SQLite default; Postgres URLs auto-detected
AUTO_REGISTER_COMMANDS=true         # register slash commands on every boot
EMBED_COLOR=5865F2                  # optional
LOG_LEVEL=info                      # optional
```

## 3. Discord Developer Portal setup

1. Create the application at <https://discord.com/developers/applications>, add a **Bot**.
2. Enable **Privileged Gateway Intents**: `Server Members Intent` (joins/leaves, autoroles, welcome) and `Message Content Intent` (XP, automod, autoresponders, counting, sticky).
3. Invite the bot with the `bot` + `applications.commands` scopes:

```
https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&scope=bot+applications.commands&permissions=1100484045911
```

The permission integer covers: view/send messages, embed links, attach files, read history, add reactions, manage messages/channels/roles/nicknames/webhooks/invites, kick/ban, moderate members (timeouts), and voice permissions for temporary voice channels. You can trim it to the modules you actually use.

## 4. How the dashboards work

Open any `/…-dashboard` (administrators by default; grant extra roles via `/dashboard permissions` → role picker). All panels are **ephemeral** — only you see them — and are **stateless** (they survive bot restarts).

- **Overview** — module toggle, enabled-command count, module-specific status, History, Advanced, module extras.
- **Commands** — every command of the module with on/off state; select one to open its editor.
- **Command editor** — independent settings for that one command:
  - *Toggle* — enable/disable just this command.
  - *Cooldown* — per user, in seconds (modal).
  - *Response text* — success template with `{variables}` + ephemeral switch (modal).
  - *Embed studio* — title, description, hex color, footer, image for the response (modal, validated against Discord limits). Clear with a button.
  - *Permissions* — allowed roles, blocked roles, allowed channels, blocked channels via native role/channel pickers (empty selection = unrestricted). Discord permission requirements (e.g. Ban Members) still apply and are shown.
- **Advanced** — module-specific settings (channels, templates, toggles) defined by each module's schema; edits are audit-logged.
- **History** — last configuration changes (who/what/when/before→after) with **one-click revert**.

Changing `/ban` never touches `/kick` — every command has its own row in the database.

### Global `/dashboard` subcommands

`home` · `module` · `command` · `embeds` (browse custom embeds across modules, preview) · `permissions` (dashboard access roles) · `variables` (placeholder reference) · `backup` (JSON export of all configs) · `restore` (attach a backup, confirm, apply) · `history` (all modules, revert) · `search` (find values in configs) · `images` (informational — see §9).

## 5. Dynamic variables

Usable in every response template, welcome/goodbye text, leveling announcements, tags and custom commands:

`{user}` `{username}` `{displayname}` `{avatar}` `{userid}` `{server}` `{servericon}` `{membercount}` `{createdate}` `{joindate}` `{boostcount}` `{channel}` `{channelname}` — plus per-context extras: `{level} {oldlevel} {xp} {requiredxp} {totalxp} {rank}` (leveling), `{reason} {moderator} {target} {duration} {case}` (moderation), `{amount} {currency}` (economy), `{prize} {winners}` (giveaways). Full list: `/dashboard variables`. Unknown variables are left untouched.

## 6. Custom slash commands

`/custom create name:<lowercase-name> response:<text>` creates a **real slash command in your guild** — supports `{variables}` and `|`-separated random pools. It is registered instantly and re-synced on every startup. Reserved names (built-ins, `-dashboard`) are rejected. `/autoresponder` adds keyword triggers for normal chat; `/trigger` automates `memberJoin`/keyword → assignRole/removeRole/sendMessage/notifyStaff.

## 7. Permissions model

Per command (in the module dashboard): allowed roles ⊕ blocked roles ⊕ allowed channels ⊕ blocked channels, plus the command's built-in Discord permission requirement. Administrators always bypass role restrictions. Moderation actions additionally enforce **role hierarchy** for the executor *and* the bot, and the server owner cannot be targeted. Dangerous operations (anti-nuke disable, lockdown, config restore, warning clears) check elevated permissions; dashboard panels re-verify access on every click.

## 8. Hosting & the database question

The bot is a single persistent Node process — perfect for Railway, a VPS, or any always-on Node host. Do **not** run the Gateway bot as a serverless function.

**Yes, it needs a database** — every setting, case, level, coin and ticket lives there. But it takes care of itself: on every boot `scripts/prepare-db.js` (wired up in `railway.json`, or run manually as `npm run setup`) reads `DATABASE_URL`, switches the Prisma provider automatically (`postgres…` → PostgreSQL, anything else → SQLite), and creates/syncs all tables. You never run a migration command.

On Railway pick one of the three options from §2 Path A step 3:

| Option | Setup | Survives redeploys? | Notes |
| --- | --- | --- | --- |
| **PostgreSQL** (recommended) | `+ New → Database → PostgreSQL`, nothing else | ✅ Yes | `DATABASE_URL` auto-injected; managed, backups easy |
| SQLite + Volume | Bot service → **Settings → Volumes** → attach, mount path `/data`; add variable `DATABASE_URL=file:/data/bot.db` | ✅ Yes | Cheapest; single file; less convenient backups |
| Default (no setup) | nothing | ❌ **No** | Container disk is wiped on each deploy — all settings/levels/economy reset. Fine for a quick test only |

Other hosts: set `DATABASE_URL` to any Postgres connection string (Railway, Neon, Supabase…) or a `file:` path on persistent disk. The included `railway.json` sets the start command to `node scripts/prepare-db.js && node src/index.js`; elsewhere use the same two commands (systemd/Docker/pm2, logs to stdout). `npx prisma studio` gives you a DB web UI. Changing command definitions no longer needs a manual deploy — registration happens on every startup unless `AUTO_REGISTER_COMMANDS=false`.

## 9. Adding the image engine later

This build deliberately ships **text + embed pipelines only**. The rendering hook is isolated:

- Welcome/goodbye: `src/modules/welcome/index.js → render()` — attach a generated buffer via `payload.files`.
- Leveling rank/level-up: `src/modules/leveling/commands.js → /rank` and the level-up announcement in `src/modules/leveling/service.js`.
- Suggested renderer: `@napi-rs/canvas` (backgrounds, circular avatar masks, text layers, progress bars), stored templates in ModuleConfig, uploads under a `storage/` folder with object storage in production.
- `/welcome image`, `/welcome background`, `/dashboard images` already exist and explain the extension point.

## 10. Platform constraints (honest notes)

- Embed layout is fixed by Discord: the embed studio covers author/title/description/color/thumbnail/image/fields/footer/timestamp within Discord's limits (validated before saving). Custom fonts/layered graphics belong in a generated image (§9).
- Command-name renames and aliases are limited by Discord's application-command rules; per-guild custom commands are the supported aliasing mechanism.
- Invite attribution is approximate: vanity URLs, paused/infinite invites and race conditions can misattribute; the command output says so.
- Dashboard cooldown edits are clamped to 0–3600 s; longer gates (daily/weekly/work) use their own timestamps in the database.
- Anti-nuke cannot restore deleted channels/roles; it detects, acts and alerts. Keep a server template/backup for disaster recovery.
- Message content only arrives with the privileged intent enabled — otherwise automod/XP/autoresponders silently skip (joins/leaves/moderation still work).

## 11. Project structure

```
discord-bot/
├── prisma/schema.prisma        # 30+ models (configs, cases, tickets, economy, …)
├── railway.json                # Railway build/start config (auto db setup + boot)
├── scripts/
│   ├── prepare-db.js           # auto provider switch + table sync (npm run setup)
│   ├── deploy-commands.js      # optional manual slash-command registration
│   └── validate.js             # offline contract + DB check (npm run validate)
└── src/
    ├── index.js                # client, intents, event wiring, boot
    ├── config.js               # env + DB URL resolution
    ├── modules.js              # shared module loader
    ├── core/                   # framework (no Discord login needed to test)
    │   ├── registry.js         #   module/command/component/hook registry
    │   ├── settings.js         #   per guild/module/command config service
    │   ├── dashboards.js       #   shared dashboard views + router
    │   ├── globalDashboard.js  #   /dashboard command
    │   ├── embeds.js           #   embed studio builder + limit validation
    │   ├── responses.js        #   per-command response templates
    │   ├── placeholders.js, permissions.js, cooldown.js, audit.js,
    │   ├── scheduler.js, db.js, logger.js
    ├── events/                 # ready, interactionCreate router, hook bridges
    └── modules/<key>/          # one folder per module:
        index.js                #   contract, defaults, settingsSchema, glue
        commands.js             #   slash command definitions
        service.js              #   business logic / DB access
        dashboard.js            #   dashboard summary lines + extras
```

## 12. Troubleshooting

| Symptom | Fix |
| --- | --- |
| `Used disallowed intents` | Enable both privileged intents in the Developer Portal (§2.0). |
| Commands don't appear | They register automatically on startup — check the logs for `Registered 79 global slash command(s)`; propagation can take up to ~1 h the very first time. Make sure `AUTO_REGISTER_COMMANDS` isn't `false`. |
| Railway: restart loop | Variables missing — set `DISCORD_TOKEN` and `CLIENT_ID` (§2 Path A step 2). Check the logs; the restart policy retries automatically. |
| Railway: data resets after every deploy | You're on the default ephemeral SQLite — add PostgreSQL or a volume (§8 table). |
| Dashboard says no permission | You need Administrator or a role added in `/dashboard permissions`. |
| XP/automod not reacting | Message Content intent off, or channel/role ignored in module settings. |
| `Unable to open the database file` | Run `npm run setup`; keep `DATABASE_URL` on the `file:./data/bot.db` default (or an absolute path). |
| Module seems dead | Check the module toggle in its dashboard → Overview. |

— Built from the “Discord Bot — Commands & Dashboard Specification” blueprint. All settings are stored per server; every configuration change is audited and revertible.
