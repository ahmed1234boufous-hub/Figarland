'use strict';

/**
 * validate.js — offline sanity check (no Discord connection needed):
 *   1. requires every module file (catches syntax/load errors)
 *   2. verifies module contracts (commands, dashboards, handlers)
 *   3. validates slash option definitions against Discord's rules
 *   4. prints a registry summary
 */

const { ApplicationCommandOptionType } = require('discord.js');
const { loadAll } = require('../src/modules');

const OPTION_LIMITS = { name: 32, description: 100 };
const NAME_RE = /^[\p{L}\p{N}_-]+$/u;

function checkOptions(cmd, errors) {
  const walk = (opts, depth, path) => {
    if (!opts) return;
    if (depth === 1 && opts.length > 25) errors.push(`${path}: more than 25 options`);
    for (const opt of opts) {
      if (!opt.name || opt.name.length > OPTION_LIMITS.name || !NAME_RE.test(opt.name)) errors.push(`${path}.${opt.name}: invalid option name`);
      if (!opt.description || opt.description.length > OPTION_LIMITS.description) errors.push(`${path}.${opt.name}: invalid description`);
      if (opt.choices && opt.choices.length > 25) errors.push(`${path}.${opt.name}: more than 25 choices`);
      if ([ApplicationCommandOptionType.Subcommand, ApplicationCommandOptionType.SubcommandGroup].includes(opt.type)) walk(opt.options, depth + 1, `${path}.${opt.name}`);
    }
  };
  walk(cmd.options, 1, `/${cmd.name}`);
}

async function main() {
  let registry;
  try {
    registry = loadAll();
  } catch (err) {
    console.error('❌ Module loading failed:', err.message);
    process.exit(1);
  }

  let errors = 0;
  const mods = registry.getModules();
  console.log(`\nRegistry summary — ${mods.length} modules:\n`);

  for (const mod of mods) {
    const issues = [];
    if (!mod.key || !mod.name) issues.push('missing key/name');
    if (mod.key !== 'core' && !mod.dashboardCommandName) issues.push('missing dashboardCommandName');
    if (!Array.isArray(mod.commands)) issues.push('commands is not an array');
    for (const cmd of mod.commands || []) {
      if (!cmd.name || typeof cmd.run !== 'function') issues.push(`command "${cmd.name || '?'}" missing name or run()`);
      if (!cmd.description) issues.push(`/${cmd.name}: missing description`);
      checkOptions(cmd, issues);
    }
    for (const issue of issues) {
      console.error(`  ❌ [${mod.key}] ${issue}`);
      errors += 1;
    }
    console.log(`  ${issues.length ? '⚠️ ' : '✅'} ${mod.emoji || '•'} ${mod.name.padEnd(22)} ${String(mod.commands?.length || 0).padStart(2)} command(s)  dashboard: ${mod.dashboardCommandName || '(global only)'}`);
  }

  // Try a real DB roundtrip
  try {
    const db = require('../src/core/db');
    await db.$queryRaw`SELECT 1`;
    const count = await db.moduleConfig.count();
    console.log(`\n✅ Database reachable (${count} module config row(s) stored)`);
    await db.$disconnect();
  } catch (err) {
    console.error(`\n❌ Database check failed: ${err.message}`);
    errors += 1;
  }

  if (errors) {
    console.error(`\n❌ Validation failed with ${errors} issue(s)`);
    process.exit(1);
  }
  console.log('\n✅ All modules valid. Run `npm run deploy` to register commands, then `npm start`.');
}

main();
