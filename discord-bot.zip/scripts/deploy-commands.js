'use strict';

/**
 * deploy-commands.js — OPTIONAL manual slash-command registration.
 *
 * The bot now registers all global commands automatically on every startup
 * (see src/events/ready.js), so this script is only needed if you set
 * AUTO_REGISTER_COMMANDS=false, or want instant per-guild testing.
 *
 * Usage:
 *   node scripts/deploy-commands.js              # global registration (may take up to 1h to propagate)
 *   node scripts/deploy-commands.js --guild ID   # ALSO register module dashboards to one guild instantly
 *   node scripts/deploy-commands.js --clean      # remove all global commands for this application
 */

const { REST, Routes } = require('discord.js');
const config = require('../src/config');
const { loadAll } = require('../src/modules');
const { buildGlobalPayloads } = require('../src/core/commandPayload');

const args = process.argv.slice(2);
const guildIdx = args.indexOf('--guild');
const testGuildId = guildIdx !== -1 ? args[guildIdx + 1] : null;
const clean = args.includes('--clean');

async function main() {
  if (!config.token || !config.clientId) {
    console.error('Missing DISCORD_TOKEN or CLIENT_ID in .env');
    process.exit(1);
  }

  const registry = loadAll();
  const rest = new REST({ version: '10' }).setToken(config.token);

  if (clean) {
    console.log('Removing all global commands…');
    await rest.put(Routes.applicationCommands(config.clientId), { body: [] });
    console.log('Done.');
    return;
  }

  const all = buildGlobalPayloads(registry);

  console.log(`Deploying ${all.length} global slash command(s)…`);
  await rest.put(Routes.applicationCommands(config.clientId), { body: all });
  console.log(`✅ Registered ${all.length} global command(s). Global commands can take up to an hour to appear everywhere.`);

  if (testGuildId) {
    const dashDefs = registry
      .getModules()
      .filter((m) => m.key !== 'core' && m.dashboardCommandName)
      .map((m) => ({ name: m.dashboardCommandName, description: `Open the ${m.name} dashboard`.slice(0, 100), dm_permission: false }));
    await rest.put(Routes.applicationGuildCommands(config.clientId, testGuildId), { body: dashDefs });
    console.log(`✅ Registered ${dashDefs.length} dashboard command(s) to guild ${testGuildId} (available instantly).`);
  }

  const total = all.length + registry.getModules().filter((m) => m.key !== 'core' && m.dashboardCommandName).length;
  console.log(`\nNote: per-guild dashboard commands auto-register on bot startup for every server the bot joins.`);
  console.log(`Total unique slash commands per server: ~${total} (within Discord's 100 global + 100 guild limits).`);
}

main().catch((err) => {
  console.error('Deployment failed:', err?.message || err);
  process.exit(1);
});
